#!/usr/bin/env python3
"""wxdash - modern kiosk weather dashboard for a WeatherFlow Tempest station.

Python 3.11 standard library only. Reads the WeatherFlow token and station
IDs from the WeatherFlow PiConsole ini file, polls the WeatherFlow REST API
server-side, and serves a static dashboard plus /api/data (clean JSON).

The API token is only ever used inside this process: it is never written to
the JSON, the logs, error messages, or any HTTP response.
"""
import argparse
import configparser
import json
import logging
import math
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from zoneinfo import ZoneInfo

import queue

import astro
import live

HERE = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(HERE, "static")
DEFAULT_INI = "/home/kitchen/wfpiconsole/wfpiconsole.ini"
THEMES = ("classic", "industrial")      # classic = static/index.html, industrial = static/industrial/
DEFAULT_THEME = "classic"
API = os.environ.get("WXDASH_API_BASE", "https://swd.weatherflow.com/swd/rest")  # override only for testing


def _read_version():
    """Installed version comes from the VERSION file next to server.py (written by publish.sh)."""
    try:
        with open(os.path.join(HERE, "VERSION"), encoding="utf-8") as fh:
            v = fh.read().strip()
        return v or "0.0.0"
    except OSError:
        return "0.0.0"


VERSION = _read_version()

OBS_INTERVAL = 60          # station observations
FORECAST_INTERVAL = 600    # better_forecast
DEVICE_INTERVAL = 600      # 24h device history (hi/lo, trends)
STATS_INTERVAL = 1800      # month / year totals
STALE_AFTER = 300          # seconds without a fresh observation => stale

log = logging.getLogger("wxdash")

CARDINALS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
             "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]


# --------------------------------------------------------------------------
# Unit helpers. WeatherFlow REST observations are always SI:
# degC, m/s, mb, mm, km.
# --------------------------------------------------------------------------
class Units:
    def __init__(self, temp="f", wind="mph", pressure="mb", precip="in", distance="mi"):
        self.temp = "c" if str(temp).lower().startswith("c") else "f"
        w = str(wind).lower()
        self.wind = w if w in ("mph", "kph", "mps", "kts", "bft") else "mph"
        if self.wind == "bft":
            self.wind = "mph"
        p = str(pressure).lower()
        self.pressure = "inhg" if p == "inhg" else ("hpa" if p == "hpa" else "mb")
        self.precip = "mm" if str(precip).lower() in ("mm", "cm") else "in"
        self.distance = "km" if str(distance).lower() == "km" else "mi"

    def t(self, c):
        if c is None:
            return None
        return c if self.temp == "c" else c * 9 / 5 + 32

    def dt(self, c):  # temperature difference
        if c is None:
            return None
        return c if self.temp == "c" else c * 9 / 5

    def w(self, ms):
        if ms is None:
            return None
        return {"mph": ms * 2.23694, "kph": ms * 3.6, "mps": ms, "kts": ms * 1.94384}[self.wind]

    def p(self, mb):
        if mb is None:
            return None
        return mb * 0.0295300 if self.pressure == "inhg" else mb

    def r(self, mm):
        if mm is None:
            return None
        return mm if self.precip == "mm" else mm / 25.4

    def d(self, km):
        if km is None:
            return None
        return km if self.distance == "km" else km * 0.621371

    def labels(self):
        return {
            "temp": "°F" if self.temp == "f" else "°C",
            "wind": {"mph": "mph", "kph": "km/h", "mps": "m/s", "kts": "kts"}[self.wind],
            "pressure": {"mb": "mb", "hpa": "hPa", "inhg": "inHg"}[self.pressure],
            "precip": self.precip,
            "rate": "in/hr" if self.precip == "in" else "mm/hr",
            "distance": self.distance,
        }

    def forecast_params(self):
        return {
            "units_temp": self.temp,
            "units_wind": self.wind,
            "units_pressure": self.pressure,
            "units_precip": self.precip,
            "units_distance": self.distance,
        }


STRIKE_HOURS = 24          # hourly lightning buckets returned in /api/data
ACTIVE_STRIKE_SECS = 1800  # a strike this recent marks lightning as "active"


def strike_buckets(events, now, hours=STRIKE_HOURS):
    """Bucket (epoch, count, distance) events into hourly totals.

    Returns `hours` dicts, oldest first; the last one is the current (partial)
    clock hour. `distance` must already be in display units (or None)."""
    cur = int(now // 3600) * 3600
    start = cur - (hours - 1) * 3600
    out = [{"time": start + i * 3600, "count": 0, "min_distance": None} for i in range(hours)]
    for ts, cnt, dist in events:
        if not cnt or ts is None or ts < start or ts >= cur + 3600:
            continue
        b = out[int((ts - start) // 3600)]
        b["count"] += int(cnt)
        if dist:
            b["min_distance"] = dist if b["min_distance"] is None else min(b["min_distance"], dist)
    for b in out:
        b["min_distance"] = rnd(b["min_distance"], 0)
    return out


def dew_point(t_c, rh):
    """Magnus-formula dew point (degC)."""
    if t_c is None or not rh:
        return None
    g = math.log(rh / 100.0) + 17.625 * t_c / (243.04 + t_c)
    return 243.04 * g / (17.625 - g)


def rnd(v, n=1):
    return None if v is None else round(v, n)


def cardinal(deg):
    if deg is None:
        return None
    return CARDINALS[int((deg % 360) / 22.5 + 0.5) % 16]


# --------------------------------------------------------------------------
# Configuration (PiConsole ini)
# --------------------------------------------------------------------------
class ConfigError(Exception):
    pass


def load_config(path):
    """Parse the PiConsole ini. Key names follow peted-davis/WeatherFlow_PiConsole
    lib/config.py: [Keys] WeatherFlow, [Station] StationID / TempestID /
    Latitude / Longitude / Timezone / Name / Elevation, [Units], [Display],
    [FeelsLike]."""
    if not os.path.isfile(path):
        raise ConfigError(f"PiConsole config not found at {path}")
    cp = configparser.ConfigParser(interpolation=None)
    try:
        with open(path, encoding="utf-8") as fh:
            cp.read_file(fh)
    except (configparser.Error, OSError, UnicodeDecodeError) as exc:
        raise ConfigError(f"PiConsole config at {path} could not be parsed ({type(exc).__name__})")
    if not cp.has_section("Keys") or not cp.has_section("Station"):
        raise ConfigError("PiConsole config is missing the [Keys] or [Station] section")
    token = cp.get("Keys", "WeatherFlow", fallback="").strip()
    station = cp.get("Station", "StationID", fallback="").strip()
    device = cp.get("Station", "TempestID", fallback="").strip()
    if not token:
        raise ConfigError("No WeatherFlow token in [Keys] WeatherFlow")
    if not station.isdigit():
        raise ConfigError("[Station] StationID is missing or not a number")
    if device and not device.isdigit():
        device = ""

    def fnum(section, key, default):
        try:
            return float(cp.get(section, key, fallback=str(default)) or default)
        except ValueError:
            return default

    units = Units(
        cp.get("Units", "Temp", fallback="f"),
        cp.get("Units", "Wind", fallback="mph"),
        cp.get("Units", "Pressure", fallback="mb"),
        cp.get("Units", "Precip", fallback="in"),
        cp.get("Units", "Distance", fallback="mi"),
    )
    tzname = cp.get("Station", "Timezone", fallback="America/Los_Angeles") or "America/Los_Angeles"
    try:
        ZoneInfo(tzname)
    except Exception:
        tzname = "America/Los_Angeles"
    cutoffs = []
    if cp.has_section("FeelsLike"):
        for k in ("ExtremelyCold", "FreezingCold", "VeryCold", "Cold", "Mild", "Warm", "Hot", "VeryHot"):
            try:
                cutoffs.append(float(cp.get("FeelsLike", k)))
            except (ValueError, configparser.Error):
                cutoffs = []
                break
    return {
        "token": token,
        "station_id": station,
        "device_id": device,
        "name": cp.get("Station", "Name", fallback="") or "Weather Station",
        "lat": fnum("Station", "Latitude", 39.52386),
        "lon": fnum("Station", "Longitude", -122.19795),
        "elevation": fnum("Station", "Elevation", 0.0),
        "tz": tzname,
        "units": units,
        "time_format": "24" if "24" in cp.get("Display", "TimeFormat", fallback="12 hr") else "12",
        "feels_cutoffs": cutoffs,
        # PiConsole [System] toggles (lib/config.py defaults both to 0)
        "nc_rain": cp.get("System", "nc_rain", fallback="0").strip() == "1",
        "stats_endpoint": cp.get("System", "stats_endpoint", fallback="0").strip() == "1",
    }


# --------------------------------------------------------------------------
# WeatherFlow client
# --------------------------------------------------------------------------
class ApiError(Exception):
    pass


def fetch_json(path, params, token, timeout=15):
    q = dict(params)
    q["token"] = token
    url = f"{API}/{path}?{urllib.parse.urlencode(q)}"
    req = urllib.request.Request(url, headers={"User-Agent": f"wxdash/{VERSION}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        msg = {401: "API token rejected (401) - check [Keys] WeatherFlow in the PiConsole ini",
               403: "access denied (403) - check the station ID and token",
               404: "not found (404) - check the station/device IDs",
               429: "rate limited (429)"}.get(exc.code, f"HTTP error {exc.code}")
        raise ApiError(msg) from None
    except urllib.error.URLError as exc:
        raise ApiError(f"unreachable ({scrub(str(exc.reason), token)})") from None
    except (TimeoutError, OSError) as exc:
        raise ApiError(f"request failed ({type(exc).__name__})") from None
    except ValueError:
        raise ApiError("invalid JSON response") from None
    status = data.get("status") if isinstance(data, dict) else None
    if isinstance(status, dict) and status.get("status_code") not in (0, None):
        raise ApiError(f"API error: {scrub(str(status.get('status_message')), token)}")
    return data


def scrub(text, token):
    if token and text:
        text = text.replace(token, "***")
    return text


# --------------------------------------------------------------------------
# Derived values (logic mirrors PiConsole lib/derived_variables.py)
# --------------------------------------------------------------------------
FEELS_TEXT = ["Feeling extremely cold", "Feeling freezing cold", "Feeling very cold",
              "Feeling cold", "Feeling mild", "Feeling warm", "Feeling hot",
              "Feeling very hot", "Feeling extremely hot"]
DEFAULT_CUTOFFS_C = [-5, 0, 5, 10, 15, 20, 25, 30]


def comfort_text(feels_c, cutoffs, units):
    if feels_c is None:
        return None
    import bisect
    if cutoffs and len(cutoffs) == 8:
        if units.temp == "f":
            return FEELS_TEXT[bisect.bisect(cutoffs, feels_c * 9 / 5 + 32)]
        return FEELS_TEXT[bisect.bisect(cutoffs, feels_c)]
    return FEELS_TEXT[bisect.bisect(DEFAULT_CUTOFFS_C, feels_c)]


def pressure_trend_text(trend, slp):
    if trend is None:
        return None, None
    if trend > 2 / 3:
        txt = "Rising rapidly"
    elif trend >= 1 / 3:
        txt = "Rising"
    elif trend <= -2 / 3:
        txt = "Falling rapidly"
    elif trend <= -1 / 3:
        txt = "Falling"
    else:
        txt = "Steady"
    if slp is None:
        return txt, None
    if slp >= 1023:
        tend = "Becoming cloudy and warmer" if txt == "Falling rapidly" else "Fair conditions likely"
    elif slp > 1009:
        tend = "Rainy conditions likely" if txt == "Falling rapidly" else "Conditions unchanged"
    else:
        if txt == "Falling rapidly":
            tend = "Stormy conditions likely"
        elif txt == "Falling":
            tend = "Rainy conditions likely"
        else:
            tend = "Becoming clearer and cooler"
    return txt, tend


def rain_rate_text(rate_mm_hr):
    if rate_mm_hr is None:
        return None
    if rate_mm_hr == 0:
        return "Currently Dry"
    for lim, txt in ((0.25, "Very Light Rain"), (1.0, "Light Rain"), (4.0, "Moderate Rain"),
                     (16.0, "Heavy Rain"), (50.0, "Very Heavy Rain")):
        if rate_mm_hr < lim:
            return txt
    return "Extreme Rain"


BEAUFORT = [(0.5, "Calm"), (1.6, "Light air"), (3.4, "Light breeze"), (5.5, "Gentle breeze"),
            (8.0, "Moderate breeze"), (10.8, "Fresh breeze"), (13.9, "Strong breeze"),
            (17.2, "Near gale"), (20.8, "Gale"), (24.5, "Strong gale"), (28.5, "Storm"),
            (32.7, "Violent storm")]


def beaufort(ms):
    if ms is None:
        return None, None
    for i, (lim, txt) in enumerate(BEAUFORT):
        if ms < lim:
            return i, txt
    return 12, "Hurricane force"


ZAMBRETTI = {
    "falling": ["Settled fine", "Fine weather", "Fine, becoming less settled",
                "Fairly fine, showery later", "Showery, becoming more unsettled",
                "Unsettled, rain later", "Rain at times, worse later",
                "Rain at times, becoming very unsettled", "Very unsettled, rain"],
    "steady": ["Settled fine", "Fine weather", "Fine, possibly showers",
               "Fairly fine, showers likely", "Showery, bright intervals",
               "Changeable, some rain", "Unsettled, rain at times",
               "Rain at frequent intervals", "Very unsettled, rain", "Stormy, much rain"],
    "rising": ["Settled fine", "Fine weather", "Becoming fine", "Fairly fine, improving",
               "Fairly fine, possibly showers early", "Showery early, improving",
               "Changeable, mending", "Rather unsettled, clearing later",
               "Unsettled, probably improving", "Unsettled, short fine intervals",
               "Very unsettled, finer at times", "Stormy, possibly improving",
               "Stormy, much rain"],
}


def zambretti(slp, trend, month, lat):
    """Barometric outlook (Negretti & Zambra 'Zambretti' method).
    Used in place of PiConsole's Sager Weathercaster, which needs 6 hours of
    stored wind/pressure history and a large lookup table."""
    if slp is None or trend is None:
        return None
    summer = (4 <= month <= 9) if lat >= 0 else not (4 <= month <= 9)
    if trend <= -1 / 3:
        key, z = "falling", 127 - 0.12 * slp
        if not summer:
            z += 1
        base = 1
    elif trend >= 1 / 3:
        key, z = "rising", 185 - 0.16 * slp
        if summer:
            z -= 1
        base = 20
    else:
        key, z = "steady", 144 - 0.13 * slp
        base = 10
    table = ZAMBRETTI[key]
    idx = int(round(z)) - base
    idx = max(0, min(len(table) - 1, idx))
    return {"outlook": table[idx], "trend": key, "method": "Zambretti"}


# --------------------------------------------------------------------------
# Forecast helpers
# --------------------------------------------------------------------------
def fmt_hour(ts, tz, h24=False):
    dt = datetime.fromtimestamp(ts, tz)
    if h24:
        return dt.strftime("%H:%M")
    return dt.strftime("%I %p").lstrip("0")


def until_text(conditions, hourly, now_ts, tz, h24=False):
    """'Clear until 11 PM today' style text, as on the PiConsole forecast panel."""
    if not conditions or not hourly:
        return conditions
    today = datetime.fromtimestamp(now_ts, tz).date()
    for h in hourly:
        t = h.get("time")
        if t is None or t < now_ts:
            continue
        if h.get("conditions") and h["conditions"] != conditions:
            d = datetime.fromtimestamp(t, tz).date()
            when = "today" if d == today else ("tomorrow" if d == today + timedelta(days=1)
                                              else datetime.fromtimestamp(t, tz).strftime("%A"))
            return f"{conditions} until {fmt_hour(t, tz, h24)} {when}"
    return f"{conditions} for the next day"


def accum_window(kind, now, tz):
    """time_start / time_end for PiConsole's month() / year() bucket=e requests.

    Mirrors lib/request_api/weatherflow_api.py exactly: start = local midnight on
    the 1st of the month (or Jan 1); end = (local midnight today - 1 day) - 1 s,
    or start + 1 when today is the 1st (Jan 1)."""
    local = datetime.fromtimestamp(now, tz)
    if kind == "month":
        start = datetime(local.year, local.month, 1, tzinfo=tz)
        first = local.day == 1
    else:
        start = datetime(local.year, 1, 1, tzinfo=tz)
        first = local.timetuple().tm_yday == 1
    ts = int(start.timestamp())
    if first:
        return ts, ts + 1
    midnight = datetime(local.year, local.month, local.day, tzinfo=tz)
    return ts, int((midnight - timedelta(days=1)).timestamp()) - 1


# --------------------------------------------------------------------------
# Data store / poller
# --------------------------------------------------------------------------
class Store:
    def __init__(self, ini_path):
        self.ini_path = ini_path
        self.lock = threading.Lock()
        self.cfg = None
        self.config_error = None
        self.raw = {"obs": None, "forecast": None, "device": None, "stats": None,
                    "month": None, "year": None}
        self.fetched = {"obs": 0, "forecast": 0, "device": 0, "stats": 0, "month": 0, "year": 0}
        self.accum_day = None       # local date the month/year windows were fetched for
        self.errors = {}
        self.last_good = None       # last successfully built payload
        self.last_good_time = 0
        self.stats_base = None      # month/year rain totals minus today's rain at fetch time
        self.live = live.LiveState()  # WebSocket feed (rapid_wind / obs_st / evt_strike)
        self.broker = None          # SSE broker, set by main()

    # ---- polling ---------------------------------------------------------
    def reload_config(self):
        try:
            cfg = load_config(self.ini_path)
            with self.lock:
                if self.cfg is None or self.cfg["token"] != cfg["token"] \
                        or self.cfg["station_id"] != cfg["station_id"]:
                    log.info("config loaded: station %s, device %s",
                             cfg["station_id"], cfg["device_id"] or "-")
                self.cfg = cfg
                self.config_error = None
        except ConfigError as exc:
            with self.lock:
                if self.config_error != str(exc):
                    log.error("config error: %s", exc)
                self.cfg = None
                self.config_error = str(exc)

    def poll_once(self):
        self.reload_config()
        cfg = self.cfg
        if cfg is None:
            return
        now = time.time()
        tok = cfg["token"]
        jobs = [("obs", OBS_INTERVAL, lambda: fetch_json(f"observations/station/{cfg['station_id']}", {}, tok))]
        params = {"station_id": cfg["station_id"]}
        params.update(cfg["units"].forecast_params())
        jobs.append(("forecast", FORECAST_INTERVAL, lambda: fetch_json("better_forecast", params, tok)))
        if cfg["device_id"]:
            end = int(now)
            start = end - 86400 - 1800
            jobs.append(("device", DEVICE_INTERVAL, lambda: fetch_json(
                f"observations/device/{cfg['device_id']}",
                {"bucket": "a", "time_start": start, "time_end": end}, tok)))
        # Month / year rain totals, fetched exactly as PiConsole does
        # (lib/request_api/weatherflow_api.py month()/year()/statistics()).
        tz = ZoneInfo(cfg["tz"])
        today = datetime.fromtimestamp(now, tz).date()
        if self.accum_day != today:          # new local day: refetch the windows
            self.accum_day = today
            with self.lock:
                for k in ("stats", "month", "year"):
                    self.fetched[k] = 0
                    self.raw[k] = None
                self.stats_base = None
        if cfg["stats_endpoint"] or not cfg["device_id"]:
            jobs.append(("stats", STATS_INTERVAL, lambda: fetch_json(f"stats/station/{cfg['station_id']}", {}, tok)))
        else:
            for key in ("month", "year"):
                ts, te = accum_window(key, now, tz)
                if te < ts:
                    # 2nd of the month: PiConsole's window (1st .. day before
                    # yesterday) is empty, so its total would be blank; use 0
                    # + today's rain instead of an inverted request.
                    with self.lock:
                        self.raw[key] = {"obs": []}
                    continue
                jobs.append((key, STATS_INTERVAL, lambda ts=ts, te=te: fetch_json(
                    f"observations/device/{cfg['device_id']}",
                    {"bucket": "e", "time_start": ts, "time_end": te}, tok)))
        updated = False
        for key, interval, fn in jobs:
            retry = interval if not self.errors.get(key) else min(interval, 120)
            if now - self.fetched[key] < retry:
                continue
            try:
                data = fn()
                with self.lock:
                    self.raw[key] = data
                    self.errors.pop(key, None)
                    self.fetched[key] = now
                    if key in ("stats", "month", "year"):
                        self.stats_base = None
                updated = True
            except ApiError as exc:
                msg = scrub(str(exc), tok)
                with self.lock:
                    self.errors[key] = msg
                    self.fetched[key] = now
                log.warning("%s: %s", SOURCE_LABELS.get(key, key), msg)
            except Exception as exc:  # never let the poller die
                with self.lock:
                    self.errors[key] = f"unexpected {type(exc).__name__}"
                    self.fetched[key] = now
                log.exception("%s failed", key)
        if updated and self.broker:
            self.broker.publish("data", self.payload())

    def run(self):
        while True:
            try:
                self.poll_once()
            except Exception:
                log.exception("poll loop error")
            time.sleep(10)

    # ---- payload ---------------------------------------------------------
    def payload(self):
        with self.lock:
            cfg = self.cfg
            raw = dict(self.raw)
            errors = dict(self.errors)
            cerr = self.config_error
        now = time.time()
        if cfg is None:
            out = self.last_good if self.last_good else empty_payload()
            out = json.loads(json.dumps(out))
            out.update({"status": "error", "stale": True, "error": cerr or "Not configured",
                        "server_time": now})
            return out
        try:
            data = build_payload(cfg, raw, now, self)
        except Exception as exc:
            log.exception("build failed")
            data = None
            errors["build"] = f"could not process data ({type(exc).__name__})"
        if data and data.get("obs_time"):
            age = now - data["obs_time"]
            data["stale"] = age > STALE_AFTER
            data["status"] = "stale" if data["stale"] else "ok"
            data["error"] = summarize_errors(errors)
            if data["stale"] and not data["error"]:
                data["error"] = f"No new observations for {int(age // 60)} min"
            with self.lock:
                self.last_good = data
                self.last_good_time = now
            return data
        # nothing usable yet
        out = json.loads(json.dumps(self.last_good)) if self.last_good else empty_payload()
        msg = summarize_errors(errors) or "Waiting for first observation…"
        out.update({"status": "error" if errors else "loading", "stale": True,
                    "error": msg, "server_time": now})
        return out


SOURCE_LABELS = {"obs": "observations", "forecast": "forecast", "device": "24h history",
                 "stats": "rain totals", "month": "month rain totals", "year": "year rain totals",
                 "build": "processing"}


def summarize_errors(errors):
    if not errors:
        return None
    msgs = list(dict.fromkeys(errors.values()))
    if len(msgs) == 1 and len(errors) > 1:
        return f"WeatherFlow {msgs[0]}"
    return "; ".join(f"WeatherFlow {SOURCE_LABELS.get(k, k)}: {v}" for k, v in errors.items())


def empty_payload():
    return {
        "version": VERSION, "mock": False, "status": "error", "stale": True, "error": None,
        "station": {"name": "Weather Station", "tz": "America/Los_Angeles", "time_format": "12"},
        "units": Units().labels(), "obs_time": None,
        "temp": {}, "wind": {}, "pressure": {}, "rain": {}, "humidity": {}, "lightning": {},
        "solar": {}, "forecast": {"now": {}, "today": {}, "hourly": [], "daily": []},
        "astro": {}, "sager": None, "live": {"ws": "off"},
    }


def astro_block(lat, lon, tz, now):
    sr, ss = astro.sun_times(now, lat, lon, tz)
    mr, ms = astro.moon_times(now, lat, lon, tz)
    mp = astro.moon_phase(now)
    nn = astro.next_phase(now, False)
    nf = astro.next_phase(now, True)
    is_day = astro.sun_altitude(now, lat, lon) > -0.833
    return {
        "sunrise": sr, "sunset": ss, "is_day": is_day,
        "sun_altitude": rnd(astro.sun_altitude(now, lat, lon), 1),
        "moon": {
            "phase": round(mp["phase"], 4), "illumination": round(mp["illumination"] * 100),
            "name": mp["name"], "waxing": mp["waxing"], "rise": mr, "set": ms,
            "next_new": nn, "next_full": nf,
        },
    }


def build_payload(cfg, raw, now, store):
    u = cfg["units"]
    tz = ZoneInfo(cfg["tz"])
    h24 = cfg["time_format"] == "24"
    obs_resp = raw.get("obs") or {}
    obs_list = obs_resp.get("obs") or []
    ob = obs_list[0] if obs_list else {}
    fc = raw.get("forecast") or {}
    cc = fc.get("current_conditions") or {}
    fcf = fc.get("forecast") or {}

    obs_time = ob.get("timestamp")
    temp_c = ob.get("air_temperature")
    rh = ob.get("relative_humidity")
    feels_c = ob.get("feels_like", temp_c)
    dew_c = ob.get("dew_point")
    slp = ob.get("sea_level_pressure")
    stp = ob.get("barometric_pressure") or ob.get("station_pressure")
    wind_avg = ob.get("wind_avg")
    wind_gust = ob.get("wind_gust")
    wind_dir = ob.get("wind_direction")
    nc = cfg.get("nc_rain", False)
    sfx = "_final" if nc else ""         # PiConsole nc_rain = NearCast-checked rain
    minute_mm = ob.get("precip" + sfx)
    today_mm = ob.get("precip_accum_local_day" + sfx, cc.get("precip_accum_local_day" + sfx))
    yday_mm = ob.get("precip_accum_local_yesterday" + sfx, cc.get("precip_accum_local_yesterday" + sfx))
    uv, solar_rad = ob.get("uv"), ob.get("solar_radiation")

    # ---- live WebSocket overlay: newer obs_st and the 3-second rapid_wind ---
    lv = store.live.snapshot() if store is not None else {}
    rest_obs_time = obs_time
    lrow = lv.get("obs")
    if lrow and len(lrow) > 12 and lrow[0] and (obs_time is None or lrow[0] > obs_time):
        fac = (slp / stp) if (slp and stp) else None
        obs_time = lrow[0]
        if lrow[7] is not None:
            temp_c = lrow[7]
        if lrow[8] is not None:
            rh = lrow[8]
        if lrow[7] is not None and lrow[8]:
            dew_c = dew_point(temp_c, rh)
        if lrow[6] and fac:
            stp, slp = lrow[6], lrow[6] * fac
        if lrow[2] is not None:
            wind_avg, wind_gust, wind_dir = lrow[2], lrow[3], lrow[4]
        uv, solar_rad = lrow[10], lrow[11]
        # obs_st: 12 minute rain / 18 local-day rain; 19 / 20 are the NC versions
        i_min, i_day = (19, 20) if nc else (12, 18)
        if len(lrow) > i_min:
            minute_mm = lrow[i_min]
        if len(lrow) > i_day and lrow[i_day] is not None:
            today_mm = lrow[i_day]
    rapid = lv.get("rapid")
    if rapid and now - rapid[0] < live.RAPID_FRESH and rapid[1] is not None:
        wind_avg = rapid[1]
        if rapid[1] > 0 and rapid[2] is not None:
            wind_dir = rapid[2]

    # ---- 24h device history ---------------------------------------------
    t_hi = t_lo = p_hi = p_lo = None
    diff24 = t_trend = p_trend = None
    avg_wind = max_gust = None
    strikes_today = None
    strike_hours = None
    count_30m = nearest_30m = None
    dev_ev, last_row_ts = None, None
    day_start, _ = astro.local_day_bounds(now, tz)
    dev = raw.get("device") or {}
    rows = [r for r in (dev.get("obs") or []) if isinstance(r, list) and len(r) > 15 and r[0]]
    slp_factor = (slp / stp) if (slp and stp) else None
    if rows:
        rows.sort(key=lambda r: r[0])
        temps = [(r[0], r[7]) for r in rows if r[7] is not None]
        if obs_time and temp_c is not None:
            temps.append((obs_time, temp_c))
        today_t = [x for x in temps if x[0] >= day_start]
        if today_t:
            hi = max(today_t, key=lambda x: x[1])
            lo = min(today_t, key=lambda x: x[1])
            t_hi, t_lo = {"value": hi[1], "time": hi[0]}, {"value": lo[1], "time": lo[0]}
        if temps and temp_c is not None and obs_time:
            target = obs_time - 86400
            near = min(temps, key=lambda x: abs(x[0] - target))
            if abs(near[0] - target) < 1800:
                diff24 = temp_c - near[1]
            target = obs_time - 3 * 3600
            near = min(temps, key=lambda x: abs(x[0] - target))
            if abs(near[0] - target) < 1800 and obs_time - near[0] > 1800:
                t_trend = (temp_c - near[1]) / ((obs_time - near[0]) / 3600)
        if slp_factor:
            press = [(r[0], r[6] * slp_factor) for r in rows if r[6]]
            if obs_time and slp:
                press.append((obs_time, slp))
            today_p = [x for x in press if x[0] >= day_start]
            if today_p:
                hi = max(today_p, key=lambda x: x[1])
                lo = min(today_p, key=lambda x: x[1])
                p_hi, p_lo = {"value": hi[1], "time": hi[0]}, {"value": lo[1], "time": lo[0]}
            if press and obs_time and slp:
                target = obs_time - 3 * 3600
                near = min(press, key=lambda x: abs(x[0] - target))
                if abs(near[0] - target) < 1800 and obs_time - near[0] > 1800:
                    p_trend = (slp - near[1]) / ((obs_time - near[0]) / 3600)
        today_rows = [r for r in rows if r[0] >= day_start]
        winds = [r[2] for r in today_rows if r[2] is not None]
        gusts = [r[3] for r in today_rows if r[3] is not None]
        if winds:
            avg_wind = sum(winds) / len(winds)
        if gusts:
            max_gust = max(gusts + ([wind_gust] if wind_gust is not None else []))
        st = [r[15] for r in today_rows if r[15] is not None]
        if st:
            strikes_today = sum(st)
        dev_ev = [(r[0], r[15], u.d(r[14]) if len(r) > 14 else None) for r in rows if r[15]]
        last_row_ts = rows[-1][0]
    if p_trend is None and cc.get("pressure_trend"):
        pass  # text-only fallback handled below

    # ---- month / year rain -----------------------------------------------
    # Same method as PiConsole lib/derived_variables.py rain_accum() and
    # strike_count(). Default (stats_endpoint = 0): sum column 28 (29 with
    # nc_rain) of the bucket=e daily rows from the month()/year() windows, which
    # end before today, then add today's accumulation. Column 24 = strikes.
    # stats_endpoint = 1: stats_month/stats_year[-1][28|29] (already includes
    # today, so today's rain is removed from the base and re-added live).
    month_mm = year_mm = month_strikes = None
    stats_mode = bool(cfg.get("stats_endpoint") or not cfg.get("device_id"))
    local = datetime.fromtimestamp(now, tz)
    i_rain = 29 if nc else 28
    try:
        if store.stats_base is None:
            base = {}
            if stats_mode:
                stats = raw.get("stats") or {}
                sm = stats.get("stats_month") or []
                sy = stats.get("stats_year") or []
                if sm or sy:
                    base_today = today_mm or 0
                    if sm and str(sm[-1][0]) == local.strftime("%Y-%m-01") and sm[-1][i_rain] is not None:
                        base["month"] = sm[-1][i_rain] - base_today
                        base["month_strikes"] = sm[-1][24]
                    if sy and str(sy[-1][0]) == local.strftime("%Y-01-01") and sy[-1][i_rain] is not None:
                        base["year"] = sy[-1][i_rain] - base_today
            else:
                for key, first in (("month", local.day == 1),
                                   ("year", local.timetuple().tm_yday == 1)):
                    if first:                     # PiConsole: total = today's rain
                        base[key] = 0.0
                        if key == "month":
                            base["month_strikes"] = 0
                        continue
                    resp = raw.get(key)
                    rows = (resp or {}).get("obs") if isinstance(resp, dict) else None
                    if not isinstance(rows, list):
                        continue
                    rows = [r for r in rows if isinstance(r, list)]
                    vals = [r[i_rain] for r in rows if len(r) > i_rain and r[i_rain] is not None]
                    base[key] = float(sum(vals))
                    if key == "month":
                        base["month_strikes"] = sum(r[24] for r in rows
                                                    if len(r) > 24 and r[24] is not None)
            if base:
                base["date"] = local.date().isoformat()
                store.stats_base = base
        b = store.stats_base or {}
        if b.get("date") == local.date().isoformat():
            if today_mm is not None:              # PiConsole needs today's rain
                if "month" in b:
                    month_mm = max(0.0, b["month"] + today_mm)
                if "year" in b:
                    year_mm = max(0.0, b["year"] + today_mm)
            month_strikes = b.get("month_strikes")
        elif b:
            store.stats_base = None  # day rolled over; refetch next cycle
            for k in ("stats", "month", "year"):
                store.fetched[k] = 0
    except (IndexError, TypeError, ValueError, KeyError):
        pass

    # ---- wind -------------------------------------------------------------
    calm = wind_avg is not None and wind_avg < 0.45
    bft, bft_txt = beaufort(wind_avg)

    # ---- pressure ---------------------------------------------------------
    trend_txt, tendency = pressure_trend_text(p_trend, slp)
    if trend_txt is None and cc.get("pressure_trend"):
        trend_txt = str(cc["pressure_trend"]).capitalize()

    # ---- forecast ---------------------------------------------------------
    hourly_raw = fcf.get("hourly") or []
    daily_raw = fcf.get("daily") or []
    hourly = []
    for h in hourly_raw:
        if h.get("time") is None or h["time"] < now - 3600:
            continue
        hourly.append({
            "time": h["time"], "temp": h.get("air_temperature"), "icon": h.get("icon"),
            "conditions": h.get("conditions"), "precip": h.get("precip_probability"),
            "wind": h.get("wind_avg"), "wind_dir": h.get("wind_direction_cardinal"),
        })
        if len(hourly) >= 12:
            break
    daily = []
    for d in daily_raw[:6]:
        daily.append({
            "time": d.get("day_start_local"), "high": d.get("air_temp_high"),
            "low": d.get("air_temp_low"), "icon": d.get("icon"),
            "conditions": d.get("conditions"), "precip": d.get("precip_probability"),
            "sunrise": d.get("sunrise"), "sunset": d.get("sunset"),
        })
    today_fc = daily[0] if daily else {}
    now_h = hourly[0] if hourly else {}
    conditions = cc.get("conditions") or now_h.get("conditions")
    fc_now = {
        "conditions": conditions, "icon": cc.get("icon") or now_h.get("icon"),
        "temp": now_h.get("temp"), "until": until_text(conditions, hourly_raw, now, tz, h24),
        "wind": now_h.get("wind"), "wind_dir": now_h.get("wind_dir"),
        "precip": now_h.get("precip"),
    }

    a = astro_block(cfg["lat"], cfg["lon"], tz, now)
    if today_fc.get("sunrise"):
        a["sunrise"], a["sunset"] = today_fc["sunrise"], today_fc.get("sunset") or a["sunset"]

    rate_mm = minute_mm * 60 if minute_mm is not None else None
    last_strike = ob.get("lightning_strike_last_epoch", cc.get("lightning_strike_last_epoch"))
    last_dist = ob.get("lightning_strike_last_distance", cc.get("lightning_strike_last_distance"))
    count_1h = ob.get("lightning_strike_count_last_1hr", cc.get("lightning_strike_count_last_1hr"))
    count_3h = ob.get("lightning_strike_count_last_3hr", cc.get("lightning_strike_count_last_3hr"))
    # live evt_strike messages fill the gap until REST / device history catch up
    ws_strikes = lv.get("strikes") or []
    if ws_strikes:
        newest = max(ws_strikes, key=lambda x: x[0])
        if not last_strike or newest[0] > last_strike:
            last_strike, last_dist = newest[0], newest[1]
        after_rest = [x for x in ws_strikes if x[0] > (rest_obs_time or 0)]
        if after_rest:
            count_1h = (count_1h or 0) + sum(1 for x in after_rest if x[0] >= now - 3600)
            count_3h = (count_3h or 0) + sum(1 for x in after_rest if x[0] >= now - 3 * 3600)
        if month_strikes is not None and stats_mode:
            month_strikes += sum(1 for x in ws_strikes if x[0] > store.fetched.get("stats", 0))
    if dev_ev is not None:
        extra = [(x[0], 1, u.d(x[1])) for x in ws_strikes if x[0] > last_row_ts]
        ev = dev_ev + extra
        if strikes_today is not None or extra:
            strikes_today = (strikes_today or 0) + sum(1 for x in extra if x[0] >= day_start)
        strike_hours = strike_buckets(ev, now)
    else:
        ev = [(x[0], 1, u.d(x[1])) for x in ws_strikes]
    if month_strikes is not None and not stats_mode:
        # PiConsole strike_count(): month window ends before today, add today's count
        month_strikes += strikes_today or 0
    recent = [e for e in ev if e[0] >= now - ACTIVE_STRIKE_SECS]
    if dev_ev is not None or ws_strikes:
        count_30m = sum(int(e[1]) for e in recent)
    dists = [e[2] for e in recent if e[2]]
    nearest_30m = rnd(min(dists), 0) if dists else None

    return {
        "version": VERSION, "mock": False, "server_time": now, "obs_time": obs_time,
        "station": {
            "name": cfg["name"] or obs_resp.get("public_name") or obs_resp.get("station_name"),
            "id": cfg["station_id"], "device": cfg["device_id"], "lat": cfg["lat"],
            "lon": cfg["lon"], "tz": cfg["tz"], "time_format": cfg["time_format"],
        },
        "units": u.labels(),
        "temp": {
            "now": rnd(u.t(temp_c)), "feels": rnd(u.t(feels_c)), "dew": rnd(u.t(dew_c)),
            "comfort": comfort_text(feels_c, cfg["feels_cutoffs"], u),
            "trend": rnd(u.dt(t_trend)), "diff24": rnd(u.dt(diff24)),
            "high": {"value": rnd(u.t(t_hi["value"])), "time": t_hi["time"]} if t_hi else None,
            "low": {"value": rnd(u.t(t_lo["value"])), "time": t_lo["time"]} if t_lo else None,
        },
        "humidity": {"now": rnd(rh, 0), "dew": rnd(u.t(dew_c))},
        "wind": {
            "speed": rnd(u.w(wind_avg)), "gust": rnd(u.w(wind_gust)), "dir": wind_dir,
            "cardinal": "Calm" if calm else cardinal(wind_dir), "calm": calm,
            "dir_cardinal": cardinal(wind_dir),
            "avg_today": rnd(u.w(avg_wind)), "gust_max": rnd(u.w(max_gust)),
            "beaufort": bft, "description": bft_txt,
        },
        "pressure": {
            "slp": rnd(u.p(slp), 1 if u.pressure != "inhg" else 2),
            "slp_mb": rnd(slp, 1), "trend": rnd(u.p(p_trend), 1 if u.pressure != "inhg" else 3),
            "trend_text": trend_txt, "tendency": tendency,
            "high": {"value": rnd(u.p(p_hi["value"]), 1), "time": p_hi["time"]} if p_hi else None,
            "low": {"value": rnd(u.p(p_lo["value"]), 1), "time": p_lo["time"]} if p_lo else None,
        },
        "rain": {
            "today": rnd(u.r(today_mm), 2), "yesterday": rnd(u.r(yday_mm), 2),
            "month": rnd(u.r(month_mm), 2), "year": rnd(u.r(year_mm), 2),
            "rate": rnd(u.r(rate_mm), 2), "rate_text": rain_rate_text(rate_mm),
        },
        "lightning": {
            "last_epoch": last_strike, "last_distance": rnd(u.d(last_dist), 0),
            "count_1h": count_1h, "count_3h": count_3h,
            "count_today": strikes_today, "count_month": month_strikes,
            "count_30m": count_30m, "nearest_30m": nearest_30m,
            "active": bool(last_strike and now - last_strike < ACTIVE_STRIKE_SECS),
            "hourly": strike_hours,
        },
        "solar": {"uv": rnd(uv), "radiation": solar_rad},
        "live": {"ws": lv.get("ws", "off"), "since": lv.get("since"),
                 "rapid_age": rnd(now - rapid[0], 0) if rapid else None},
        "forecast": {"now": fc_now, "today": {
            "high": today_fc.get("high"), "low": today_fc.get("low"),
            "precip": today_fc.get("precip"), "conditions": today_fc.get("conditions"),
            "icon": today_fc.get("icon")}, "hourly": hourly, "daily": daily[1:6]},
        "astro": a,
        "sager": zambretti(slp, p_trend, local.month, cfg["lat"]),
    }


# --------------------------------------------------------------------------
# Mock data (example values from the live PiConsole screen)
# --------------------------------------------------------------------------
def mock_lightning(now, scenario=None, extra=None):
    """Example lightning history. Default: a small storm passed by earlier
    today (mostly zero hours). scenario="active": strikes are happening now."""
    if scenario == "active":
        # (minutes ago, strikes in that minute, distance mi)
        events = [(14 * 60 + 5, 1, 21), (13 * 60 + 40, 2, 18), (13 * 60 + 10, 1, 17),
                  (170, 1, 19), (150, 2, 16), (128, 3, 14), (110, 2, 13), (95, 4, 12),
                  (80, 3, 11), (66, 5, 10), (52, 4, 9), (41, 6, 8), (33, 5, 8), (27, 7, 7),
                  (21, 6, 7), (15, 8, 6), (10, 5, 6), (6, 4, 5), (3, 3, 5)]
        month_base = 6
    else:
        events = [(9 * 60 + 50, 1, 22), (9 * 60 + 12, 2, 19), (8 * 60 + 40, 3, 16),
                  (8 * 60 + 5, 4, 14), (7 * 60 + 30, 2, 12), (6 * 60 + 55, 1, 13),
                  (5 * 60 + 18, 1, 17)]
        month_base = 4
    ev = [(now - m * 60, c, d) for m, c, d in events]
    ev += [(t, 1, d) for t, d in (extra or [])]   # simulated live strikes
    tz = ZoneInfo("America/Los_Angeles")
    day_start, _ = astro.local_day_bounds(now, tz)
    last = max(ev, key=lambda e: e[0])
    recent = [e for e in ev if e[0] >= now - ACTIVE_STRIKE_SECS]
    today = sum(c for t, c, _ in ev if t >= day_start)
    return {
        "last_epoch": last[0], "last_distance": last[2],
        "count_1h": sum(c for t, c, _ in ev if t >= now - 3600),
        "count_3h": sum(c for t, c, _ in ev if t >= now - 3 * 3600),
        "count_today": today, "count_month": month_base + today,
        "count_30m": sum(c for _, c, _ in recent),
        "nearest_30m": min((d for _, _, d in recent), default=None),
        "active": now - last[0] < ACTIVE_STRIKE_SECS,
        "hourly": strike_buckets(ev, now),
    }


def mock_payload(now=None, scenario=None):
    now = now or time.time()
    tz = ZoneInfo("America/Los_Angeles")
    lat, lon = 39.52386, -122.19795
    local = datetime.fromtimestamp(now, tz)
    day = datetime(local.year, local.month, local.day, tzinfo=tz)

    def at(h, m):
        return (day + timedelta(hours=h, minutes=m)).timestamp()

    sim = live.MockSim._inst
    a = astro_block(lat, lon, tz, now)
    # example moon values from the PiConsole screen
    full = datetime(local.year, 10, 25, 21, 11, tzinfo=tz).timestamp()
    if full < now:
        full = a["moon"]["next_full"]
    a["moon"].update({"name": "Waning Crescent", "illumination": 0, "phase": 0.995,
                      "waxing": False, "rise": at(7, 20), "set": at(18, 24),
                      "next_new": at(8, 50), "next_full": full})

    temps = [73, 72, 70, 67, 64, 62, 61, 59, 58, 57, 56, 56, 55]
    icons = ["clear-day", "clear-day", "clear-day", "clear-night", "clear-night",
             "clear-night", "clear-night", "clear-night", "partly-cloudy-night",
             "partly-cloudy-night", "partly-cloudy-night", "partly-cloudy-night",
             "partly-cloudy-day"]
    conds = ["Clear", "Clear", "Clear", "Clear", "Clear", "Clear", "Clear", "Clear",
             "Partly Cloudy", "Partly Cloudy", "Partly Cloudy", "Partly Cloudy", "Partly Cloudy"]
    start_hour = local.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    hourly = []
    for i in range(12):
        t = start_hour + timedelta(hours=i)
        sun_up = astro.sun_altitude(t.timestamp(), lat, lon) > -0.833
        ic = icons[i]
        if not sun_up:
            ic = ic.replace("-day", "-night")
        else:
            ic = ic.replace("-night", "-day")
        hourly.append({"time": t.timestamp(), "temp": temps[i], "icon": ic,
                       "conditions": conds[i], "precip": [0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 10, 10][i],
                       "wind": [4, 4, 3, 3, 2, 2, 2, 1, 1, 2, 2, 3][i], "wind_dir": "SE"})
    daily_spec = [(78, 54, "partly-cloudy-day", "Partly Cloudy", 10),
                  (74, 52, "possibly-rainy-day", "Rain Possible", 30),
                  (66, 50, "rainy", "Rain Likely", 70),
                  (69, 48, "partly-cloudy-day", "Partly Cloudy", 20),
                  (75, 51, "clear-day", "Clear", 0)]
    daily = []
    for i, (hi, lo, ic, cond, pr) in enumerate(daily_spec):
        daily.append({"time": (day + timedelta(days=i + 1)).timestamp(), "high": hi, "low": lo,
                      "icon": ic, "conditions": cond, "precip": pr})
    obs_time = now - 25
    out = {
        "version": VERSION, "mock": True, "status": "ok", "stale": False, "error": None,
        "server_time": now, "obs_time": obs_time,
        "station": {"name": "Willows Weather", "id": "162139", "device": "389004",
                    "lat": lat, "lon": lon, "tz": "America/Los_Angeles", "time_format": "12"},
        "units": Units().labels(),
        "temp": {"now": 71.4, "feels": 71.4, "dew": 54.9, "comfort": "Feeling warm",
                 "trend": 1.8, "diff24": -25.2,
                 "high": {"value": 71.4, "time": at(15, 6)},
                 "low": {"value": 55.2, "time": at(7, 12)}},
        "humidity": {"now": 56, "dew": 54.9},
        "wind": {"speed": 0.0, "gust": 0.0, "dir": 22, "cardinal": "Calm", "calm": True,
                 "dir_cardinal": "NNE", "avg_today": 0.4, "gust_max": 6.3,
                 "beaufort": 0, "description": "Calm"},
        "pressure": {"slp": 999.7, "slp_mb": 999.7, "trend": -0.8, "trend_text": "Falling rapidly",
                     "tendency": "Stormy conditions likely",
                     "high": {"value": 1002.7, "time": at(10, 29)},
                     "low": {"value": 999.7, "time": at(15, 1)}},
        "rain": {"today": 0.0, "yesterday": 0.0, "month": 0.0, "year": 17.5,
                 "rate": 0.0, "rate_text": "Currently Dry"},
        "lightning": mock_lightning(now, scenario,
                                    sim.strikes_for(scenario or "default") if sim else None),
        "live": {"ws": "connected", "demo": True, "since": now},
        "solar": {"uv": 2.1, "radiation": 310},
        "forecast": {
            "now": {"conditions": "Clear", "icon": "clear-day" if a["is_day"] else "clear-night",
                    "temp": 73, "until": "Clear until 11 PM today", "wind": 4, "wind_dir": "SE",
                    "precip": 0},
            "today": {"high": 77, "low": 55, "precip": 0, "conditions": "Clear", "icon": "clear-day"},
            "hourly": hourly, "daily": daily},
        "astro": a,
        "sager": zambretti(999.7, -0.8, local.month, lat),
    }
    if sim:  # simulated rapid_wind (every 3 s)
        wt, spd, wdir = sim.wind()
        bft, bft_txt = beaufort(spd / 2.23694)
        out["wind"].update({"speed": spd, "dir": wdir, "dir_cardinal": cardinal(wdir),
                            "calm": spd < 1, "cardinal": "Calm" if spd < 1 else cardinal(wdir),
                            "gust_max": max(6.3, round(spd * 1.4, 1)), "beaufort": bft,
                            "description": bft_txt})
    if scenario == "active":
        out["forecast"]["now"].update({"conditions": "Thunderstorms Likely", "icon": "thunderstorm",
                                       "until": "Storms until 6 PM", "precip": 60})
        for i, (ic, pr) in enumerate([("thunderstorm", 60), ("thunderstorm", 50), ("rainy", 30)]):
            out["forecast"]["hourly"][i].update({"icon": ic, "precip": pr, "conditions": "Thunderstorms"})
        out["forecast"]["today"].update({"precip": 60, "icon": "thunderstorm"})
        out["rain"].update({"today": 0.14, "rate": 0.08, "rate_text": "Light rain"})
    return out


# --------------------------------------------------------------------------
# Display settings (theme) - kept OUTSIDE the install dir so updates, rollbacks
# and reinstalls never touch them. wxdash.service sets StateDirectory=wxdash, so
# systemd gives the service user a writable /var/lib/wxdash (exported as
# $STATE_DIRECTORY) even under ProtectSystem=strict / ProtectHome=read-only.
# --------------------------------------------------------------------------
def default_settings_path():
    if os.environ.get("WXDASH_SETTINGS"):
        return os.environ["WXDASH_SETTINGS"]
    state = (os.environ.get("STATE_DIRECTORY") or "/var/lib/wxdash").split(":")[0]
    return os.path.join(state, "settings.json")


class Settings:
    """Tiny JSON settings file. A missing/corrupt file means defaults (Classic).
    If the file can't be written the choice still applies in memory until restart."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self.data = {"theme": DEFAULT_THEME}
        self.saved = True       # False after a failed write
        self.error = None
        try:
            with open(path, encoding="utf-8") as fh:
                raw = json.load(fh)
            if isinstance(raw, dict) and raw.get("theme") in THEMES:
                self.data["theme"] = raw["theme"]
        except FileNotFoundError:
            pass
        except (OSError, ValueError) as e:
            log.warning("ignoring unreadable settings %s: %s", path, e)

    @property
    def theme(self):
        return self.data["theme"]

    def snapshot(self):
        with self.lock:
            return {"theme": self.data["theme"], "themes": list(THEMES),
                    "saved": self.saved, "error": self.error}

    def set_theme(self, theme):
        if theme not in THEMES:
            raise ValueError("unknown theme")
        with self.lock:
            self.data["theme"] = theme
            try:
                d = os.path.dirname(self.path)
                if d:
                    os.makedirs(d, exist_ok=True)
                tmp = self.path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(self.data, fh)
                    fh.write("\n")
                    fh.flush()
                    os.fsync(fh.fileno())
                os.replace(tmp, self.path)
                self.saved, self.error = True, None
            except OSError as e:
                self.saved = False
                self.error = f"could not save {self.path}: {e.strerror or e}"
                log.warning("%s (theme applies until wxdash restarts)", self.error)
            return {"theme": self.data["theme"], "themes": list(THEMES),
                    "saved": self.saved, "error": self.error}


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
STATIC_TYPES = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
                ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png",
                ".woff2": "font/woff2", ".ico": "image/x-icon", ".json": "application/json"}


def mock_scenario(qs):
    return "active" if qs.get("lightning", [""])[0] == "active" else "default"


def ensure_sim(broker):
    sim = live.MockSim.get(broker)
    if sim.payload_fn is None:
        sim.payload_fn = lambda scen: mock_payload(scenario=None if scen == "default" else scen)
    return sim


def make_handler(store, force_mock, broker, settings):
    class Handler(BaseHTTPRequestHandler):
        server_version = f"wxdash/{VERSION}"
        sys_version = ""

        def log_message(self, fmt, *args):  # quiet; never log query strings
            pass

        def _send(self, code, body, ctype, cache="no-store"):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def _stream(self, mock, scen):
            """Server-Sent Events: 'data' (full payload), 'wind' (rapid_wind),
            'strike' (evt_strike) and 'live' (WebSocket state)."""
            if self.command == "HEAD":
                return self._send(200, b"", "text/event-stream")
            q = broker.subscribe()
            if q is None:
                return self._send(503, b"Too many streams", "text/plain")
            accept = ("mock", "mock:" + scen) if mock else (None,)

            def emit(ev, data):
                text = data if isinstance(data, str) else json.dumps(data, separators=(",", ":"))
                self.wfile.write(f"event: {ev}\ndata: {text}\n\n".encode("utf-8"))
                self.wfile.flush()
            try:
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Accel-Buffering", "no")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                self.wfile.write(b"retry: 5000\n\n")
                if mock:
                    ensure_sim(broker)
                    emit("live", {"ws": "connected", "demo": True})
                    emit("data", mock_payload(scenario=None if scen == "default" else scen))
                else:
                    snap = store.live.snapshot()
                    emit("live", {"ws": snap["ws"], "error": snap["error"]})
                    emit("data", store.payload())
                while True:
                    try:
                        ev, text, tag = q.get(timeout=15)
                    except queue.Empty:
                        self.wfile.write(b": keepalive\n\n")   # SSE keepalive
                        self.wfile.flush()
                        continue
                    if tag in accept or tag == "*":   # "*" = for every page (settings)
                        emit(ev, text)
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
            finally:
                broker.unsubscribe(q)

        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            qs = urllib.parse.parse_qs(parsed.query)
            if path == "/api/data":
                mock = force_mock or qs.get("mock", ["0"])[0] in ("1", "true", "yes")
                if mock:
                    ensure_sim(broker)
                    scen = mock_scenario(qs)
                    data = mock_payload(scenario=None if scen == "default" else scen)
                else:
                    data = store.payload()
                body = json.dumps(data, separators=(",", ":")).encode("utf-8")
                return self._send(200, body, "application/json; charset=utf-8")
            if path == "/api/stream":
                mock = force_mock or qs.get("mock", ["0"])[0] in ("1", "true", "yes")
                return self._stream(mock, mock_scenario(qs) if mock else None)
            if path == "/api/health":
                body = json.dumps({"ok": True, "version": VERSION,
                                   "config_error": store.config_error,
                                   "mock": force_mock, "theme": settings.theme}).encode()
                return self._send(200, body, "application/json")
            if path == "/api/settings":
                return self._send(200, json.dumps(settings.snapshot()).encode(), "application/json")
            if path in ("/", "", "/index.html"):
                # Page for the saved theme; ?theme=classic|industrial previews one without saving.
                want = qs.get("theme", [""])[0]
                theme = want if want in THEMES else settings.theme
                path = "/industrial/index.html" if theme == "industrial" else "/index.html"
            elif path in ("/industrial", "/industrial/"):
                path = "/industrial/index.html"
            rel = os.path.normpath(path.lstrip("/"))
            full = os.path.realpath(os.path.join(STATIC_DIR, rel))
            if not full.startswith(os.path.realpath(STATIC_DIR) + os.sep) or not os.path.isfile(full):
                return self._send(404, b"Not found", "text/plain")
            ext = os.path.splitext(full)[1].lower()
            if ext not in STATIC_TYPES:
                return self._send(404, b"Not found", "text/plain")
            with open(full, "rb") as fh:
                body = fh.read()
            return self._send(200, body, STATIC_TYPES[ext], cache="no-cache")

        def do_POST(self):
            path = urllib.parse.urlparse(self.path).path
            if path != "/api/settings":
                return self._send(404, b"Not found", "text/plain")
            # JSON only: a cross-site form can't send application/json without a CORS
            # preflight, which this server never answers.
            ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = -1
            if ctype != "application/json" or not 0 < n <= 1024:
                return self._send(400, b'{"ok":false,"error":"bad request"}', "application/json")
            try:
                req = json.loads(self.rfile.read(n).decode("utf-8"))
                snap = settings.set_theme(req.get("theme") if isinstance(req, dict) else None)
            except (ValueError, UnicodeDecodeError):
                return self._send(400, b'{"ok":false,"error":"unknown theme"}', "application/json")
            log.info("theme set to %s (%s)", snap["theme"], "saved" if snap["saved"] else "not saved")
            broker.publish("settings", {"theme": snap["theme"]}, scenario="*")
            snap["ok"] = True
            return self._send(200, json.dumps(snap).encode(), "application/json")

    return Handler


def start_websocket(store, broker):
    """Live feed: rapid_wind -> 'wind' SSE, obs_st -> 'data', evt_strike -> 'strike' + 'data'."""
    last_data = [0.0]

    def on_wind():
        cfg = store.cfg
        snap = store.live.snapshot()
        if not cfg or not snap["rapid"]:
            return
        u = cfg["units"]
        ts, ms, d = snap["rapid"]
        calm = ms is not None and ms < 0.45
        broker.publish("wind", {"time": ts, "speed": rnd(u.w(ms)), "dir": d if ms else None,
                                "cardinal": "Calm" if calm else cardinal(d), "dir_cardinal": cardinal(d),
                                "calm": calm, "unit": u.labels()["wind"]})

    def on_obs():
        last_data[0] = time.time()
        broker.publish("data", store.payload())

    def on_strike(epoch, km):
        cfg = store.cfg
        u = cfg["units"] if cfg else Units()
        broker.publish("strike", {"epoch": epoch, "distance": rnd(u.d(km), 0),
                                  "unit": u.labels()["distance"]})
        broker.publish("data", store.payload())

    live.WeatherFlowWS(store, broker, on_wind, on_obs, on_strike).start()


def main():
    ap = argparse.ArgumentParser(description="wxdash weather dashboard server")
    ap.add_argument("--ini", default=os.environ.get("WXDASH_INI", DEFAULT_INI),
                    help=f"path to PiConsole wfpiconsole.ini (default {DEFAULT_INI})")
    ap.add_argument("--port", type=int, default=int(os.environ.get("WXDASH_PORT", 8090)))
    ap.add_argument("--host", default=os.environ.get("WXDASH_HOST", "0.0.0.0"))
    ap.add_argument("--mock", action="store_true", help="serve example data; no network access")
    ap.add_argument("--no-websocket", action="store_true",
                    default=os.environ.get("WXDASH_NO_WS") == "1",
                    help="REST polling only (no live WeatherFlow WebSocket)")
    ap.add_argument("--settings", default=default_settings_path(),
                    help="display settings JSON (default $STATE_DIRECTORY/settings.json, i.e. /var/lib/wxdash)")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    store = Store(args.ini)
    settings = Settings(args.settings)
    log.info("theme %s (settings %s)", settings.theme, args.settings)
    broker = live.Broker()
    store.broker = broker
    if args.mock:
        log.info("mock mode: serving example data with simulated live wind/strikes")
        ensure_sim(broker)
    else:
        threading.Thread(target=store.run, daemon=True, name="poller").start()
        if args.no_websocket:
            log.info("websocket disabled; REST polling only")
        else:
            start_websocket(store, broker)
    httpd = ThreadingHTTPServer((args.host, args.port), make_handler(store, args.mock, broker, settings))
    httpd.daemon_threads = True
    log.info("wxdash %s listening on http://%s:%d/", VERSION, args.host, args.port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
