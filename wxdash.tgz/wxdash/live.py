"""wxdash live data: WeatherFlow WebSocket client, SSE broker, demo simulator.

Python 3.11 standard library only (a minimal RFC 6455 client over socket+ssl).
The API token is only used to open the WebSocket; it is never logged,
published to the browser, or included in error text.
"""
import base64
import hashlib
import json
import logging
import os
import queue
import random
import socket
import ssl
import struct
import threading
import time
import urllib.parse

log = logging.getLogger("wxdash.live")

WS_URL = os.environ.get("WXDASH_WS_URL", "wss://ws.weatherflow.com/swd/data")  # override only for testing
WS_PING_EVERY = 30        # client keepalive ping (seconds)
WS_IDLE_TIMEOUT = 90      # no frames at all for this long -> reconnect
RAPID_FRESH = 60          # rapid_wind older than this is ignored
STRIKE_KEEP = 26 * 3600   # how long live strikes are remembered
_GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


def scrub(text, token):
    text = str(text)
    if token:
        text = text.replace(token, "***").replace(urllib.parse.quote(token), "***")
    return text


# --------------------------------------------------------------------------
# Server-Sent Events broker
# --------------------------------------------------------------------------
class Broker:
    """Fan-out of (event, json_text, scenario) to SSE subscribers."""
    MAX_SUBS = 24

    def __init__(self):
        self.lock = threading.Lock()
        self.subs = set()

    def subscribe(self):
        q = queue.Queue(maxsize=200)
        with self.lock:
            if len(self.subs) >= self.MAX_SUBS:
                return None
            self.subs.add(q)
        return q

    def unsubscribe(self, q):
        with self.lock:
            self.subs.discard(q)

    def publish(self, event, data, scenario=None):
        text = data if isinstance(data, str) else json.dumps(data, separators=(",", ":"))
        with self.lock:
            subs = list(self.subs)
        for q in subs:
            try:
                q.put_nowait((event, text, scenario))
            except queue.Full:  # a stuck client must not block the feed
                pass


# --------------------------------------------------------------------------
# Minimal RFC 6455 client
# --------------------------------------------------------------------------
class WSClosed(Exception):
    pass


class MiniWS:
    def __init__(self, url, timeout=15):
        u = urllib.parse.urlsplit(url)
        if u.scheme not in ("ws", "wss"):
            raise ValueError("bad websocket scheme")
        self.host = u.hostname
        port = u.port or (443 if u.scheme == "wss" else 80)
        path = (u.path or "/") + (("?" + u.query) if u.query else "")
        raw = socket.create_connection((self.host, port), timeout=timeout)
        if u.scheme == "wss":
            raw = ssl.create_default_context().wrap_socket(raw, server_hostname=self.host)
        self.sock = raw
        self.buf = b""
        self.frag = None
        self.wlock = threading.Lock()
        key = base64.b64encode(os.urandom(16)).decode()
        host_hdr = self.host if u.port is None else f"{self.host}:{port}"
        req = (f"GET {path} HTTP/1.1\r\nHost: {host_hdr}\r\nUpgrade: websocket\r\n"
               f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
               f"Sec-WebSocket-Version: 13\r\nUser-Agent: wxdash\r\n\r\n")
        self.sock.sendall(req.encode())
        while b"\r\n\r\n" not in self.buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise WSClosed("closed during handshake")
            self.buf += chunk
            if len(self.buf) > 65536:
                raise WSClosed("handshake too large")
        head, self.buf = self.buf.split(b"\r\n\r\n", 1)
        lines = head.decode("latin-1").split("\r\n")
        parts = lines[0].split(" ", 2)
        if len(parts) < 2 or parts[1] != "101":
            code = parts[1] if len(parts) > 1 else "?"
            raise WSClosed(f"handshake rejected (HTTP {code})")
        hdrs = {}
        for ln in lines[1:]:
            if ":" in ln:
                k, v = ln.split(":", 1)
                hdrs[k.strip().lower()] = v.strip()
        want = base64.b64encode(hashlib.sha1(key.encode() + _GUID).digest()).decode()
        if hdrs.get("sec-websocket-accept") != want:
            raise WSClosed("bad Sec-WebSocket-Accept")

    def send(self, opcode, payload=b""):
        if isinstance(payload, str):
            payload = payload.encode("utf-8")
        n = len(payload)
        hdr = bytes([0x80 | opcode])
        if n < 126:
            hdr += bytes([0x80 | n])
        elif n < 65536:
            hdr += bytes([0x80 | 126]) + struct.pack("!H", n)
        else:
            hdr += bytes([0x80 | 127]) + struct.pack("!Q", n)
        mask = os.urandom(4)
        if n:
            m = int.from_bytes((mask * (n // 4 + 1))[:n], "big")
            body = (int.from_bytes(payload, "big") ^ m).to_bytes(n, "big")
        else:
            body = b""
        with self.wlock:
            self.sock.sendall(hdr + mask + body)

    def send_json(self, obj):
        self.send(0x1, json.dumps(obj))

    def _frame(self):
        """Parse one complete frame from the buffer, or return None."""
        b = self.buf
        if len(b) < 2:
            return None
        op, ln, i = b[0] & 0x0F, b[1] & 0x7F, 2
        fin, masked = bool(b[0] & 0x80), bool(b[1] & 0x80)
        if ln == 126:
            if len(b) < 4:
                return None
            ln, i = struct.unpack("!H", b[2:4])[0], 4
        elif ln == 127:
            if len(b) < 10:
                return None
            ln, i = struct.unpack("!Q", b[2:10])[0], 10
        if ln > 4 * 1024 * 1024:
            raise WSClosed("frame too large")
        mk = b""
        if masked:
            if len(b) < i + 4:
                return None
            mk, i = b[i:i + 4], i + 4
        if len(b) < i + ln:
            return None
        data = b[i:i + ln]
        if masked and ln:
            m = int.from_bytes((mk * (ln // 4 + 1))[:ln], "big")
            data = (int.from_bytes(data, "big") ^ m).to_bytes(ln, "big")
        self.buf = b[i + ln:]
        return fin, op, data

    def recv_messages(self):
        """Read what is available (honours socket timeout); return complete text messages."""
        try:
            chunk = self.sock.recv(65536)
        except socket.timeout:
            chunk = None
        if chunk == b"":
            raise WSClosed("connection closed by server")
        if chunk:
            self.buf += chunk
        out = []
        got_any = bool(chunk)
        while True:
            fr = self._frame()
            if fr is None:
                break
            fin, op, data = fr
            if op == 0x9:
                self.send(0xA, data)
            elif op == 0xA:
                pass
            elif op == 0x8:
                try:
                    self.send(0x8, data[:2])
                except OSError:
                    pass
                raise WSClosed("server sent close")
            elif op in (0x1, 0x2):
                if fin:
                    out.append(data)
                else:
                    self.frag = data
            elif op == 0x0 and self.frag is not None:
                self.frag += data
                if fin:
                    out.append(self.frag)
                    self.frag = None
        return got_any, out

    def close(self):
        try:
            self.send(0x8, struct.pack("!H", 1000))
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass


# --------------------------------------------------------------------------
# WeatherFlow live feed
# --------------------------------------------------------------------------
class LiveState:
    def __init__(self):
        self.lock = threading.Lock()
        self.ws = "off"            # off | connecting | connected
        self.ws_since = None
        self.ws_error = None
        self.rapid = None          # (epoch, speed m/s, dir deg)
        self.obs = None            # latest obs_st row (list)
        self.strikes = []          # [(epoch, distance km, energy)]

    def snapshot(self):
        with self.lock:
            return {"ws": self.ws, "since": self.ws_since, "error": self.ws_error,
                    "rapid": self.rapid, "obs": list(self.obs) if self.obs else None,
                    "strikes": list(self.strikes)}


class WeatherFlowWS(threading.Thread):
    """Keeps a WebSocket open to WeatherFlow and feeds LiveState + Broker.

    REST polling keeps running regardless, so if this never connects the
    dashboard simply behaves like a polled display."""

    def __init__(self, store, broker, on_wind, on_obs, on_strike):
        super().__init__(daemon=True, name="wf-websocket")
        self.store, self.broker = store, broker
        self.on_wind, self.on_obs, self.on_strike = on_wind, on_obs, on_strike
        self.live = store.live

    def _set(self, state, error=None):
        with self.live.lock:
            if state != self.live.ws:
                self.live.ws_since = time.time()
            self.live.ws = state
            self.live.ws_error = error
        self.broker.publish("live", {"ws": state, "error": error})

    def run(self):
        backoff = 2
        while True:
            cfg = self.store.cfg
            if not cfg or not cfg.get("device_id"):
                self._set("off", None if cfg else "not configured")
                time.sleep(10)
                continue
            started = time.time()
            try:
                self.session(cfg)
                err = None
            except Exception as exc:  # never let the thread die
                err = scrub(f"{type(exc).__name__}: {exc}", cfg.get("token"))
                log.warning("websocket: %s", err)
            if time.time() - started > 120:
                backoff = 2
            wait = backoff + random.uniform(0, backoff / 2)
            self._set("connecting", err)
            log.info("websocket: reconnecting in %.0fs", wait)
            time.sleep(wait)
            backoff = min(backoff * 2, 120)

    def session(self, cfg):
        token, dev = cfg["token"], int(cfg["device_id"])
        self._set("connecting")
        ws = MiniWS(f"{WS_URL}?{urllib.parse.urlencode({'token': token})}")
        try:
            ws.sock.settimeout(2.0)
            ws.send_json({"type": "listen_start", "device_id": dev, "id": "wxdash-obs"})
            ws.send_json({"type": "listen_rapid_start", "device_id": dev, "id": "wxdash-rapid"})
            self._set("connected")
            log.info("websocket: connected (device %s)", dev)
            last_rx = last_ping = time.time()
            while True:
                got, msgs = ws.recv_messages()
                now = time.time()
                if got:
                    last_rx = now
                for m in msgs:
                    try:
                        self.handle(json.loads(m.decode("utf-8")), dev)
                    except (ValueError, UnicodeDecodeError, TypeError, IndexError, KeyError):
                        log.debug("websocket: ignored malformed message")
                if now - last_ping >= WS_PING_EVERY:
                    ws.send(0x9, b"wxdash")
                    last_ping = now
                if now - last_rx > WS_IDLE_TIMEOUT:
                    raise WSClosed(f"no data for {WS_IDLE_TIMEOUT}s")
                c = self.store.cfg
                if not c or c["token"] != token or str(c.get("device_id")) != str(dev):
                    log.info("websocket: config changed, reconnecting")
                    return
        finally:
            ws.close()

    def handle(self, msg, dev):
        t = msg.get("type")
        if msg.get("device_id") not in (None, dev):
            return
        if t == "rapid_wind":
            ob = msg["ob"]
            with self.live.lock:
                self.live.rapid = (ob[0], ob[1], ob[2])
            self.on_wind()
        elif t == "obs_st":
            row = msg["obs"][0]
            with self.live.lock:
                self.live.obs = row
            self.on_obs()
        elif t == "evt_strike":
            ev = msg["evt"]
            with self.live.lock:
                self.live.strikes.append((ev[0], ev[1], ev[2] if len(ev) > 2 else None))
                cut = time.time() - STRIKE_KEEP
                self.live.strikes = [s for s in self.live.strikes if s[0] >= cut][-5000:]
            self.on_strike(ev[0], ev[1])
        elif t in ("connection_opened", "ack"):
            pass
        elif t in ("device_offline",):
            log.warning("websocket: Tempest reported offline")


# --------------------------------------------------------------------------
# Demo simulator (mock mode)
# --------------------------------------------------------------------------
class MockSim(threading.Thread):
    """rapid_wind every 3 s with wandering speed/direction, plus occasional
    strikes. Strikes are kept per demo scenario ("default" is rare, "active"
    is frequent) so the calm preview stays calm."""
    _inst = None
    _lock = threading.Lock()

    @classmethod
    def get(cls, broker):
        with cls._lock:
            if cls._inst is None:
                cls._inst = MockSim(broker)
                cls._inst.start()
            return cls._inst

    def __init__(self, broker):
        super().__init__(daemon=True, name="mock-sim")
        self.broker = broker
        self.lock = threading.Lock()
        self.rng = random.Random()
        self.dir, self.speed = 140.0, 4.0     # deg, mph
        self.time = time.time()
        self.strikes = {"default": [], "active": []}   # (epoch, distance mi)
        now = time.time()
        self.next_strike = {"default": now + self.rng.uniform(120, 200),
                            "active": now + self.rng.uniform(4, 7)}
        self.payload_fn = None   # set by server: scenario -> payload dict

    def wind(self):
        with self.lock:
            return self.time, self.speed, self.dir

    def strikes_for(self, scenario):
        with self.lock:
            return list(self.strikes.get(scenario or "default", []))

    def run(self):
        while True:
            time.sleep(3)
            now = time.time()
            with self.lock:
                self.dir = (self.dir + self.rng.gauss(0, 14)) % 360
                self.speed = max(0.0, min(22.0, self.speed + self.rng.gauss(0, 1.3) + (5.0 - self.speed) * 0.08))
                self.time = now
                w = (now, round(self.speed, 1), round(self.dir))
            self.broker.publish("wind", {"time": w[0], "speed": w[1], "dir": w[2], "unit": "mph", "demo": True},
                                "mock")
            for scen in ("default", "active"):
                if now < self.next_strike[scen]:
                    continue
                dist = round(self.rng.uniform(4, 9) if scen == "active" else self.rng.uniform(11, 24))
                with self.lock:
                    self.strikes[scen].append((now, dist))
                    self.strikes[scen] = [s for s in self.strikes[scen] if s[0] > now - STRIKE_KEEP]
                gap = self.rng.uniform(10, 25) if scen == "active" else self.rng.uniform(180, 420)
                self.next_strike[scen] = now + gap
                self.broker.publish("strike", {"epoch": now, "distance": dist, "unit": "mi"}, "mock:" + scen)
                if self.payload_fn:
                    self.broker.publish("data", self.payload_fn(scen), "mock:" + scen)
