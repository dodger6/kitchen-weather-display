#!/usr/bin/env bash
# Build the release files for GitHub (runs on the box, not the Pi).
#   ./publish.sh            -> /workspace/wxupload/{wxdash.tgz,latest.json,install.sh,README.md}
# Bump VERSION first; the updater on the Pi only installs a version newer than its own.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
OUT="${WXDASH_PUBLISH_DIR:-/workspace/wxupload}"
VERSION="$(tr -d '[:space:]' < "$SRC/VERSION")"
[[ "$VERSION" =~ ^[0-9]+(\.[0-9]+){0,3}$ ]] || { echo "bad VERSION: $VERSION" >&2; exit 1; }
for f in server.py live.py astro.py updater.py install.sh kiosk.sh wxdash.service wxdash-update.service wxdash-update.timer static/app.js static/industrial/app.js static/desert/index.html static/desert/app.js static/desert/style.css static/arctic/index.html static/arctic/app.js static/arctic/style.css static/arctic/fonts/Exo2-var.woff2 \
         static/redwoods/index.html static/redwoods/app.js static/redwoods/style.css \
         static/redwoods/fonts/NationalPark.woff2 static/redwoods/fonts/SourceSerif4.woff2 static/redwoods/fonts/OFL.txt \
         static/redwoods/img/fog.webp static/redwoods/img/grain.png \
         static/redwoods/img/forest_dawn.jpg static/redwoods/img/forest_day.jpg static/redwoods/img/forest_aft.jpg static/redwoods/img/forest_dusk.jpg static/redwoods/img/forest_night.jpg \
         static/redwoods/img/hero_dawn.jpg static/redwoods/img/hero_day.jpg static/redwoods/img/hero_aft.jpg static/redwoods/img/hero_dusk.jpg static/redwoods/img/hero_night.jpg \
         static/redwoods/img/moon_dawn.jpg static/redwoods/img/moon_day.jpg static/redwoods/img/moon_aft.jpg static/redwoods/img/moon_dusk.jpg static/redwoods/img/moon_night.jpg \
         static/redwoods/img/slate.jpg static/redwoods/img/wood.jpg; do
  [ -f "$SRC/$f" ] || { echo "missing $f" >&2; exit 1; }
done
# Redwoods needs the .jpg/.webp MIME types and its THEMES entry, or its images/menu entry silently break.
grep -q '"redwoods"' "$SRC/server.py" && grep -q '"\.jpg": "image/jpeg"' "$SRC/server.py" && grep -q '"\.webp": "image/webp"' "$SRC/server.py" \
  || { echo "server.py is missing the redwoods theme or the .jpg/.webp types" >&2; exit 1; }
python3 -m py_compile "$SRC/server.py" "$SRC/live.py" "$SRC/astro.py" "$SRC/updater.py"
bash -n "$SRC/install.sh"
mkdir -p "$OUT"

STAGE="$(mktemp -d)"; trap 'rm -rf "$STAGE"' EXIT
PARENT="$(dirname "$SRC")"; NAME="$(basename "$SRC")"
# Reproducible-ish tarball: sorted names, root ownership, fixed mtime, top dir "wxdash/".
tar -C "$PARENT" \
    --exclude="$NAME/preview_*" --exclude="$NAME/tools" --exclude='__pycache__' --exclude='*.pyc' \
    --exclude="$NAME/.git" --exclude='*.ini' --exclude='*.bak*' \
    --sort=name --owner=0 --group=0 --numeric-owner --mtime="@$(stat -c %Y "$SRC/VERSION")" \
    --transform "s#^$NAME#wxdash#" \
    -cf - "$NAME" | gzip -n -9 > "$STAGE/wxdash.tgz"

# Sanity: everything under wxdash/, no secrets / ini files.
if tar -tzf "$STAGE/wxdash.tgz" | grep -Ev '^wxdash(/|$)' ; then echo "member outside wxdash/" >&2; exit 1; fi
if tar -tzf "$STAGE/wxdash.tgz" | grep -Ei '\.ini$|token|secret' ; then echo "suspicious file in tarball" >&2; exit 1; fi

SHA="$(sha256sum "$STAGE/wxdash.tgz" | cut -d' ' -f1)"
mv "$STAGE/wxdash.tgz" "$OUT/wxdash.tgz"
printf '{"version": "%s", "sha256": "%s"}\n' "$VERSION" "$SHA" > "$OUT/latest.json"
cp "$SRC/install.sh" "$OUT/install.sh"; chmod 0755 "$OUT/install.sh"
cp "$SRC/README.md" "$OUT/README.md"
echo "version: $VERSION"
echo "sha256:  $SHA"
ls -l "$OUT"
