/* wxdash front-end - DESERT theme (third theme, added in 1.3.0). Vanilla JS, no dependencies, works offline.
   Data plumbing (polling, live stream, menu, theme picker) follows the Industrial
   front end; every gauge here is new: sun arc over the mesa, stone star compass with a hawk
   feather, drifting-sand speed bar, canyon-strata barometer, clay ollas, cracked-earth-to-oasis
   humidity, petroglyph UV suns, moon over the mesa, dune-horizon hourly, cairn strike chart.
   1.5.2: the sky follows the station's real sun (dawn, day, late afternoon, dusk, starry night). */
(function () {
  "use strict";
  const POLL_MS = 15000;
  const params = new URLSearchParams(location.search);
  const MOCK = params.get("mock") === "1";
  if (MOCK) window.__wxstrike = (e) => onStrike(e);   // mock-only test hook: deliver a live evt_strike as if it came over SSE
  const $ = (id) => document.getElementById(id);
  const body = document.body;
  const SVGNS = "http://www.w3.org/2000/svg";
  let DATA = null, lastFetchOk = 0, serverDown = false;
  let tz = "America/Los_Angeles", h24 = false;
  let needleAngle = null, overlayTimer = null, openPanel = null;
  let sse = null, sseOpen = false, wsState = "off", demoLive = false;
  let windShown = null, windAnim = 0;

  if (params.get("lite") === "1" || localStorage.getItem("wxdash-lite") === "1") body.classList.add("lite");
  if (params.get("cursor") === "1" || localStorage.getItem("wxdash-cursor") === "1") body.classList.add("show-cursor");

  /* ---------------- mock-only clock override: ?mock=1&mock_time=13:30 ----------------
     Shifts the clock, night mode and the demo data's timestamps/day-night icons so a
     daytime preview can be rendered at any hour. Never active without mock=1. */
  const MOCK_TIME = MOCK && /^\d{1,2}:\d{2}$/.test(params.get("mock_time") || "") ? params.get("mock_time") : null;
  let OFFSET = 0;
  function computeOffset() {
    if (!MOCK_TIME) return;
    const [th, tm] = MOCK_TIME.split(":").map(Number);
    const p = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "numeric", second: "numeric", hourCycle: "h23" }).formatToParts(new Date());
    const g = (t) => +p.find((x) => x.type === t).value;
    OFFSET = ((th * 60 + tm) - ((g("hour") % 24) * 60 + g("minute"))) * 60000 - g("second") * 1000;
  }
  computeOffset();
  const nowMs = () => Date.now() + OFFSET;
  const nowS = () => nowMs() / 1000;

  /* ---------------- formatting ---------------- */
  const isNum = (v) => typeof v === "number" && isFinite(v);
  const fx = (v, d = 1) => (isNum(v) ? v.toFixed(d) : "--");
  const fi = (v) => (isNum(v) ? Math.round(v).toString() : "--");
  function signed(v, d = 1) { if (!isNum(v)) return "--"; const s = Math.abs(v).toFixed(d); return (v > 0 ? "+" : v < 0 ? "\u2212" : "") + s; }
  function fmtTime(ts, opts) {
    if (!isNum(ts)) return "--";
    return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: tz, hour: "numeric", minute: "2-digit", hour12: !h24 }, opts || {})).format(new Date(ts * 1000));
  }
  function fmtHour(ts) {
    if (!isNum(ts)) return "--";
    if (h24) return fmtTime(ts, { minute: "2-digit" });
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hour12: true }).format(new Date(ts * 1000)).replace(" ", "\u2009");
  }
  function dayKey(ts) { return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(ts * 1000)); }
  function fmtDay(ts) {
    if (!isNum(ts)) return "--";
    const now = nowS();
    if (dayKey(ts) === dayKey(now)) return "Today";
    if (dayKey(ts) === dayKey(now + 86400)) return "Tomorrow";
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000));
  }
  function ago(ts) {
    if (!isNum(ts)) return "--";
    const s = Math.max(0, nowS() - ts);
    if (s < 90) return Math.round(s) + "s ago";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " hr ago";
    return Math.round(s / 86400) + " days ago";
  }
  function setText(id, txt) { const el = $(id); if (el && el.textContent !== txt) el.textContent = txt; }
  function setHTML(id, html) { const el = $(id); if (el && el.innerHTML !== html) el.innerHTML = html; }
  function arrowFor(v, eps) { eps = eps || 0.05; if (!isNum(v)) return ["", ""]; if (v > eps) return ["\u25B2", "up"]; if (v < -eps) return ["\u25BC", "down"]; return ["\u25B6", "flat"]; }
  function setArrow(id, v, eps) { const [ch, cls] = arrowFor(v, eps); const el = $(id); el.textContent = ch; el.setAttribute("class", "arrow " + cls); }
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  /* 1.5.6: precipitation chance is drawn with an inline SVG raindrop, never the U+1F4A7 emoji
     (the Pi has no emoji font, so the emoji showed as an empty box) */
  const DROP_D = "M6 .6C6 .6 .9 6.9 .9 10.4a5.1 5.1 0 0 0 10.2 0C11.1 6.9 6 .6 6 .6Z";
  const DROP_SVG = `<svg class="drop-ic" viewBox="0 0 12 16" aria-hidden="true" focusable="false"><path d="${DROP_D}"/></svg>`;
  function setPct(id, pct, empty) {   // "<drop> 70%" chip / row; `empty` text when there is no value
    const el = $(id); if (!el) return;
    const key = isNum(pct) ? "p" + fi(pct) : "e" + empty;
    if (el.dataset.pct === key) return; el.dataset.pct = key;
    if (isNum(pct)) el.innerHTML = `${DROP_SVG}<span class="pct">${fi(pct)}%</span>`; else el.textContent = empty;
  }
  function dropLabel(x, y, fs, p) {   // SVG chart label: a drawn drop + "60%", centred on x (0% has no drop)
    if (!p) return `<text class="dp zero" x="${f1(x)}" y="${f1(y)}" font-size="${f1(fs)}">0%</text>`;
    const t = fi(p) + "%", tw = t.length * fs * 0.5, dw = fs * 0.6, gap = fs * 0.1, x0 = x - (dw + gap + tw) / 2;
    return `<path class="dp-drop" d="${DROP_D}" transform="translate(${f1(x0)} ${f1(y - fs * 0.76)}) scale(${(fs * 0.8 / 16).toFixed(3)})"/>` +
      `<text class="dp" x="${f1(x0 + dw + gap)}" y="${f1(y)}" font-size="${f1(fs)}" style="text-anchor:start">${t}</text>`;
  }
  const clamp01 = (k) => Math.max(0, Math.min(1, k));
  const f1 = (n) => n.toFixed(1);

  /* ---------------- weather icons (desert palette: orange sun, bone clouds) ---------------- */
  document.body.insertAdjacentHTML("afterbegin", `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
    <radialGradient id="gSunGlow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ff8f45" stop-opacity=".9"/><stop offset=".55" stop-color="#ff8f45" stop-opacity=".35"/><stop offset="1" stop-color="#ff8f45" stop-opacity="0"/></radialGradient>
    <linearGradient id="gCloud" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fbf1e2"/><stop offset="1" stop-color="#c9b2a6"/></linearGradient>
    <linearGradient id="gCloudD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a99398"/><stop offset="1" stop-color="#5e4652"/></linearGradient>
    <linearGradient id="gMoonI" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff6e6"/><stop offset="1" stop-color="#e2cfae"/></linearGradient>
    <radialGradient id="gMoonLit" cx=".45" cy=".4" r=".65"><stop offset="0" stop-color="#fffaf0"/><stop offset=".7" stop-color="#f1e7d6"/><stop offset="1" stop-color="#d6c6b4"/></radialGradient>
    <radialGradient id="gMoonDark" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#3a2c3e"/><stop offset="1" stop-color="#1e1626"/></radialGradient>
  </defs></svg>`);
  const CLOUD = "M18 48h29a9.5 9.5 0 0 0 .8-19 13.5 13.5 0 0 0-25.8-3.4A10.5 10.5 0 0 0 18 48z";
  const SUN_BODY = `<circle cx="60" cy="60" r="36" fill="url(#gSunGlow)"/><circle class="sun-core" cx="60" cy="60" r="19" fill="#ff8f45"/>` +
    `<g stroke="#ff8f45" stroke-width="5" stroke-linecap="round"><line x1="60" y1="20" x2="60" y2="10"/><line x1="60" y1="110" x2="60" y2="100"/>` +
    `<line x1="20" y1="60" x2="10" y2="60"/><line x1="110" y1="60" x2="100" y2="60"/><line x1="32" y1="32" x2="25" y2="25"/><line x1="88" y1="88" x2="95" y2="95"/>` +
    `<line x1="88" y1="32" x2="95" y2="25"/><line x1="32" y1="88" x2="25" y2="95"/></g>`;
  const sunI = (x, y, s) => `<svg x="${x}" y="${y}" width="${s}" height="${s}" viewBox="0 0 120 120" overflow="visible">${SUN_BODY}</svg>`;
  const moonI = (tx, ty, s) => `<g transform="translate(${tx} ${ty}) scale(${s})"><path d="M38 10a22 22 0 1 0 17 34A18 18 0 0 1 38 10z" fill="url(#gMoonI)"/></g>`;
  const cloudI = (tx, ty, s, dark) => `<path transform="translate(${tx} ${ty}) scale(${s})" d="${CLOUD}" fill="url(#${dark ? "gCloudD" : "gCloud"})"/>`;
  const dropsI = (n, c) => `<g stroke="${c || "#4fd1c0"}" stroke-width="3" stroke-linecap="round">${(n === 2 ? [26, 38] : [22, 32, 42]).map((x) => `<line x1="${x}" y1="50" x2="${x - 2}" y2="55"/>`).join("")}</g>`;
  const boltI = () => `<path d="M34 40 26 53h6l-3 9 10-14h-6l3-8z" fill="#fff1d6" stroke="#8e3418" stroke-width="1.2" stroke-linejoin="round"/>`;
  function wicon(name) {
    const n = String(name || "cloudy"), night = n.indexOf("night") >= 0;
    const small = night ? moonI(4, 2, 0.55) : sunI(2, 0, 40);
    let g;
    if (n.startsWith("clear") && !night) return `<svg viewBox="0 0 120 120" aria-hidden="true">${SUN_BODY}</svg>`;
    if (n.startsWith("clear")) g = moonI(6, 4, 1);
    else if (n.startsWith("partly-cloudy")) g = small + cloudI(4, 6, 0.95);
    else if (n === "cloudy") g = cloudI(-6, -6, 0.8, true) + cloudI(4, 4, 0.95);
    else if (n === "foggy") g = cloudI(2, -4, 0.95) + `<g stroke="#f1e2cf" stroke-width="3" stroke-linecap="round"><line x1="12" y1="50" x2="46" y2="50"/><line x1="20" y1="57" x2="54" y2="57"/></g>`;
    else if (n.startsWith("possibly-rainy")) g = small + cloudI(4, -2, 0.95) + dropsI(2);
    else if (n === "rainy") g = cloudI(2, -6, 0.95, true) + dropsI(3);
    else if (n.indexOf("sleet") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -6, 0.95, true) + dropsI(2, "#bfeee6");
    else if (n.indexOf("snow") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -6, 0.95) + `<g fill="#fff">${[22, 32, 42].map((x) => `<circle cx="${x}" cy="52" r="2.4"/>`).join("")}</g>`;
    else if (n.indexOf("thunderstorm") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -8, 0.95, true) + boltI();
    else if (n === "windy") g = `<g fill="none" stroke="#f1e2cf" stroke-width="3.5" stroke-linecap="round"><path d="M8 24h30a7 7 0 1 0-7-7"/><path d="M8 34h42a7 7 0 1 1-7 7"/><path d="M8 44h20"/></g>`;
    else g = cloudI(2, 2, 0.95);
    return `<svg viewBox="0 0 64 64" aria-hidden="true">${g}</svg>`;
  }

  /* ---------------- moon phase (phase-accurate terminator) ---------------- */
  function moonArt(illumPct, waxing) {
    const k = clamp01((illumPct || 0) / 100), r = 52, cx = 60, cy = 60, top = cy - r, bot = cy + r;
    let lit = "";
    if (k >= 0.995) lit = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonLit)"/>`;
    else if (k > 0.005) {
      const rx = (r * Math.abs(1 - 2 * k)).toFixed(2), crescent = k < 0.5;
      const d = waxing ? `M${cx} ${top} A${r} ${r} 0 0 1 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 0 : 1} ${cx} ${top}Z`
        : `M${cx} ${top} A${r} ${r} 0 0 0 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 1 : 0} ${cx} ${top}Z`;
      lit = `<path d="${d}" fill="url(#gMoonLit)"/>`;
    }
    // earthshine rim keeps a new moon visible against the sky
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonDark)" stroke="rgba(246,230,210,.45)" stroke-width="2"/>${lit}` +
      `<g fill="#000" opacity=".07"><circle cx="44" cy="40" r="9"/><circle cx="74" cy="50" r="6"/><circle cx="62" cy="80" r="11"/><circle cx="36" cy="70" r="5"/></g>`;
  }

  /* ---------------- temperature: sun arc over the mesa ----------------
     A half-circle sun path rises from the horizon; it is the cold-to-hot colour scale,
     lit (full colour) from the cold end up to the current temperature, where the sun sits,
     coloured by that temperature. Arrowheads mark today's low/high; a turquoise band
     between them is today's range. */
  const TEMP_SCALES = { f: { min: 0, max: 130, labels: [0, 20, 40, 60, 80, 100, 120] }, c: { min: -18, max: 54, labels: [-18, 0, 10, 20, 30, 40, 54] } };
  const HEAT = ["#4b6bff", "#4a8dff", "#3fb2ff", "#38d4e6", "#3fdcae", "#63e07a", "#9fd98e", "#e3cfa4", "#f4b682", "#ffa05c", "#ff8a3d", "#ff5a3d", "#f0365a"];
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
  function heatColor(k) {
    const x = clamp01(k) * (HEAT.length - 1), i = Math.min(HEAT.length - 2, Math.floor(x)), t = x - i;
    const a = hex(HEAT[i]), b = hex(HEAT[i + 1]);
    return "rgb(" + a.map((v, j) => Math.round(v + (b[j] - v) * t)).join(",") + ")";
  }
  const AC = { cx: 450, cy: 372, r: 290 };
  const pol = (cx, cy, r, a) => [cx + Math.sin(a * Math.PI / 180) * r, cy - Math.cos(a * Math.PI / 180) * r];
  function arcD(cx, cy, r, a0, a1) {
    const [x0, y0] = pol(cx, cy, r, a0), [x1, y1] = pol(cx, cy, r, a1);
    return `M${f1(x0)} ${f1(y0)} A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${f1(x1)} ${f1(y1)}`;
  }
  const angOf = (k) => -90 + clamp01(k) * 180;
  let heroUnit = null;
  function buildHero(unit) {
    if (heroUnit === unit) return; heroUnit = unit;
    const S = TEMP_SCALES[unit], N = 60;
    let seg = "";
    for (let i = 0; i < N; i++) seg += `<path d="${arcD(AC.cx, AC.cy, AC.r, angOf(i / N), angOf((i + 1) / N) + 0.4)}" stroke="${heatColor((i + 0.5) / N)}" stroke-width="30" fill="none"/>`;
    $("tScale").innerHTML = seg; $("tHeat").innerHTML = seg;
    $("heatMaskPath").setAttribute("d", arcD(AC.cx, AC.cy, AC.r, -90, 90));
    $("tBand").setAttribute("d", arcD(AC.cx, AC.cy, AC.r - 34, -90, 90));
    $("tLabels").innerHTML = S.labels.map((v) => { const [x, y] = pol(AC.cx, AC.cy, AC.r + 34, angOf((v - S.min) / (S.max - S.min))); return `<text x="${f1(x)}" y="${f1(y)}">${v}°</text>`; }).join("");
    let rays = "";
    for (let i = 0; i < 12; i++) { const a = i * 30, [x1, y1] = pol(0, 0, 33, a), [x2, y2] = pol(0, 0, 44, a); rays += `<line x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}"/>`; }
    $("tSunRays").innerHTML = rays;
  }
  function placeOnArc(el, k, r, rotate) {
    const a = angOf(k), [x, y] = pol(AC.cx, AC.cy, r, a);
    el.style.transform = `translate(${f1(x)}px, ${f1(y)}px)` + (rotate ? ` rotate(${f1(a)}deg)` : "");
  }
  function fitBigTemp() {
    const t = $("tempNow"); if (!t || !t.getComputedTextLength) return;
    t.style.fontSize = "";
    const max = 470, len = t.getComputedTextLength();
    if (len > max) t.style.fontSize = (parseFloat(getComputedStyle(t).fontSize) * max / len).toFixed(1) + "px";
  }
  function renderHero(T, U) {
    const unit = /C/i.test((U && U.temp) || "") ? "c" : "f", S = TEMP_SCALES[unit];
    buildHero(unit);
    const frac = (v) => clamp01((v - S.min) / (S.max - S.min));
    const now = T.now, lo = (T.low || {}).value, hi = (T.high || {}).value;
    $("heatMaskPath").setAttribute("stroke-dasharray", isNum(now) ? `${(frac(now) * 100).toFixed(2)} 200` : "0 200");
    const sun = $("tSun");
    if (isNum(now)) { placeOnArc(sun, frac(now), AC.r, false); $("tSunCore").setAttribute("fill", heatColor(frac(now))); sun.style.opacity = "1"; } else sun.style.opacity = "0";
    if (isNum(lo) && isNum(hi)) {
      const a = frac(Math.min(lo, hi)) * 100, b = Math.max(a + 0.8, frac(Math.max(lo, hi)) * 100);
      $("tBand").setAttribute("stroke-dasharray", `0 ${a.toFixed(2)} ${(b - a).toFixed(2)} 200`);
    } else $("tBand").setAttribute("stroke-dasharray", "0 200");
    [["tLoMk", lo], ["tHiMk", hi]].forEach(([id, v]) => { const el = $(id); if (isNum(v)) { placeOnArc(el, frac(v), AC.r - 56, true); el.style.opacity = "1"; } else el.style.opacity = "0"; });
    setText("tempNow", isNum(now) ? fx(now) + "°" : "--");
    fitBigTemp();
    setText("lowVal", isNum(lo) ? fx(lo) + "°" : "--");
    setText("highVal", isNum(hi) ? fx(hi) + "°" : "--");
    setText("lowTime", fmtTime((T.low || {}).time));
    setText("highTime", fmtTime((T.high || {}).time));
  }

  /* ---------------- wind: carved star compass + hawk feather ---------------- */
  (function buildRose() {
    const C = 150; let s = `<circle cx="${C}" cy="${C}" r="148" class="rose-disc"/><circle cx="${C}" cy="${C}" r="124" class="rose-field"/>`;
    const pt = (r, a) => pol(C, C, r, a).map(f1).join(" ");
    // 8-point star: each point split into a lit and a shaded facet (carved look)
    for (let i = 0; i < 8; i++) {
      const a = i * 45, card = i % 2 === 0, R = card ? 120 : 84, w = card ? 17 : 13;
      s += `<path class="${card ? "rp-c" : "rp-d"} lit" d="M${pt(R, a)} L${pt(w, a - 22.5)} L${C} ${C} Z"/>`;
      s += `<path class="${card ? "rp-c" : "rp-d"} shade" d="M${pt(R, a)} L${pt(w, a + 22.5)} L${C} ${C} Z"/>`;
    }
    [["N", 0], ["E", 90], ["S", 180], ["W", 270]].forEach(([l, a]) => { const [x, y] = pol(C, C, 136, a); s += `<text x="${f1(x)}" y="${f1(y)}" class="rose-l${l === "N" ? " n" : ""}">${l}</text>`; });
    $("roseStatic").innerHTML = s;
    // hawk feather: quill tip near the hub, vane out toward the direction the wind comes from
    const vane = "M150 20 C166 34 168 70 160 104 L150 110 L140 104 C132 70 134 34 150 20 Z";
    let bands = "";
    [34, 52, 70, 88].forEach((y, i) => { bands += `<path class="fb${i % 2}" d="M${136 + (y - 20) * 0.02} ${y} Q150 ${y - 5} ${164 - (y - 20) * 0.02} ${y} L${164 - (y - 20) * 0.03} ${y + 7} Q150 ${y + 2} ${136 + (y - 20) * 0.03} ${y + 7} Z"/>`; });
    $("feather").innerHTML = `<path class="f-vane" d="${vane}"/>${bands}<path class="f-tip" d="M150 20 C158 26 162 34 163 40 Q150 35 137 40 C138 34 142 26 150 20 Z"/>` +
      `<path class="f-shaft" d="M150 22 V118"/><path class="f-quill" d="M150 104 V118"/>`;
  })();
  const SAND_MAX = { mph: 40, "km/h": 64, kph: 64, "m/s": 18, kts: 35, kn: 35 };
  function sandScaleFor(unit) { return SAND_MAX[unit] || 40; }
  let sandUnit = null;
  function setSand(speed, gust, unit) {
    if (MOCK && params.has("gust")) gust = parseFloat(params.get("gust"));   // mock-only: preview the gust marker
    const max = sandScaleFor(unit);
    if (sandUnit !== unit) { sandUnit = unit; $("sandScale").innerHTML = [0, .25, .5, .75, 1].map((k) => `<span>${Math.round(max * k)}</span>`).join(""); }
    const k = isNum(speed) ? clamp01(speed / max) : 0, x = 8 + k * 384;
    $("sandClipRect").style.transform = `scaleX(${k.toFixed(3)})`;
    const tw = $("tumble");
    tw.style.transform = `translate(${f1(Math.max(14, x))}px, ${f1(46 - k * 30)}px)`;
    tw.classList.toggle("rolling", isNum(speed) && speed >= 1 && !body.classList.contains("lite"));
    const gm = $("gustMk");
    if (isNum(gust) && gust > 0) { const kg = clamp01(gust / max); gm.style.transform = `translate(${f1(8 + kg * 384)}px, ${f1(Math.max(19, 47 - kg * 31))}px)`; gm.style.opacity = "1"; } else gm.style.opacity = "0";
  }
  function tweenWind(to) {
    cancelAnimationFrame(windAnim);
    if (!isNum(to)) { windShown = null; setText("windNow", "--"); return; }
    const from = isNum(windShown) ? windShown : to, t0 = performance.now(), dur = 280;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      windShown = from + (to - from) * e; setText("windNow", windShown.toFixed(1));
      if (k < 1) windAnim = requestAnimationFrame(step); else windShown = to;
    };
    if (from === to || body.classList.contains("lite")) { windShown = to; setText("windNow", fx(to)); } else windAnim = requestAnimationFrame(step);
  }
  function setWind(speed, dir, dirCard, fallbackTxt, calm, unit, gust) {
    tweenWind(speed);
    setText("windNowUnit", unit || "mph");
    setHTML("windDir", isNum(dir) ? `${esc(dirCard || "--")}<span class="unit">${fi(dir)}°</span>` : esc(fallbackTxt || "--"));
    const f = $("feather");
    if (isNum(dir)) {
      if (needleAngle === null) needleAngle = dir;
      else { const delta = ((dir - needleAngle) % 360 + 540) % 360 - 180; needleAngle += delta; }
      f.style.transform = `rotate(${needleAngle}deg)`;
    }
    f.classList.toggle("calm", !!calm);
    f.style.opacity = isNum(dir) ? "" : "0";
    setSand(speed, gust, unit || "mph");
  }
  const CARD16 = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  function onRapidWind(w) {
    if (!DATA || !isNum(w.speed)) return;
    const W = DATA.wind = DATA.wind || {};
    const calm = w.calm != null ? !!w.calm : w.speed < 1;
    const dir = isNum(w.dir) ? w.dir : W.dir;
    const card = w.dir_cardinal || (isNum(dir) ? CARD16[Math.round(dir / 22.5) % 16] : null);
    Object.assign(W, { speed: w.speed, dir: dir, calm: calm, dir_cardinal: card, cardinal: calm ? "Calm" : card });
    if (isNum(w.gust)) { W.gust = w.gust; setText("gustNow", fx(w.gust)); }
    setWind(w.speed, dir, card, W.cardinal, calm, (DATA.units && DATA.units.wind) || w.unit, W.gust);
  }

  /* ---------------- barometer: canyon-wall strata ----------------
     Rock layers are the pressure zones (stormy at the canyon floor, very dry at the rim).
     A turquoise ledge + arrowhead marks the current pressure; chevrons show the trend;
     dashed lines are today's low and high. */
  const BZ = [[1040, 1050, "#ecd6b2", "Very dry", "#4a1e10"], [1020, 1040, "#dba673", "Fair", "#3a160a"], [1000, 1020, "#c46a3e", "Change", "#fff3e2"],
    [980, 1000, "#8e3a22", "Rain", "#fff3e2"], [950, 980, "#4c2244", "Stormy", "#fff3e2"]];
  let baroP = null;
  function setBaro(P) { baroP = P; drawStrata(); }
  function drawStrata() {
    const box = $("strataBox"); if (!box || !baroP) return;
    const W = box.clientWidth, H = box.clientHeight; if (!W || !H) return;
    const P = baroP, isIn = (DATA && DATA.units && DATA.units.pressure) === "inHg", toMb = (v) => (isIn ? v * 33.8639 : v);
    const lmb = P.low && isNum(P.low.value) ? toMb(P.low.value) : null, hmb = P.high && isNum(P.high.value) ? toMb(P.high.value) : null;
    const sig = JSON.stringify([P.slp_mb, P.trend, lmb, hmb, W, H]);
    if (box.dataset.sig === sig) return;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    const aw = u * 2.0, X0 = aw + u * 0.35, X1 = W - 1, pad = 3;
    const y = (mb) => pad + (1050 - Math.max(950, Math.min(1050, mb))) / 100 * (H - 2 * pad);
    const cliff = `M${f1(X0)} ${pad} H${f1(X1 - u * 0.4)} L${f1(X1)} ${f1(H * 0.22)} L${f1(X1 - u * 0.6)} ${f1(H * 0.45)} L${f1(X1 - u * 0.15)} ${f1(H * 0.7)} L${f1(X1 - u * 0.7)} ${f1(H - pad)} H${f1(X0)} Z`;
    const wav = (yy, k) => `M${f1(X0)} ${f1(yy)} C${f1(X0 + (X1 - X0) * 0.3)} ${f1(yy - k * u * 0.25)} ${f1(X0 + (X1 - X0) * 0.65)} ${f1(yy + k * u * 0.3)} ${f1(X1)} ${f1(yy - k * u * 0.12)}`;
    let g = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-label="pressure strata"><defs><clipPath id="cliffClip"><path d="${cliff}"/></clipPath></defs><g clip-path="url(#cliffClip)">`;
    BZ.forEach(([lo, hi, col], i) => {
      const yt = y(hi), yb = y(lo), k = i % 2 ? 1 : -1;
      g += `<path d="${wav(yt, k)} L${f1(X1)} ${f1(yb + 2)} L${f1(X0)} ${f1(yb + 2)} Z" fill="${col}"/>`;
      g += `<path d="${wav(yt + (yb - yt) * 0.62, -k)}" stroke="rgba(0,0,0,.13)" stroke-width="1.5" fill="none"/>`;
    });
    g += `</g><path d="${cliff}" fill="none" stroke="rgba(20,6,10,.6)" stroke-width="1.5"/>`;
    const fz = Math.min(u * 0.82, (H - 2 * pad) / 5 * 0.62);
    BZ.forEach(([lo, hi, , name, tc]) => { g += `<text x="${f1(X0 + u * 0.5)}" y="${f1((y(lo) + y(hi)) / 2)}" class="z-l" fill="${tc}" font-size="${f1(fz)}">${name}</text>`; });
    [[lmb, "L"], [hmb, "H"]].forEach(([v, l]) => { if (isNum(v)) g += `<path class="bl-mk" d="M${f1(X0)} ${f1(y(v))} H${f1(X1 - u * 0.3)}"/>`; });
    if (isNum(P.slp_mb)) {
      const ym = y(P.slp_mb), ah = u * 0.75;
      g += `<path class="b-ledge" d="M${f1(aw * 0.6)} ${f1(ym)} H${f1(X1 - u * 0.2)}"/><path class="b-arrow" d="M1 ${f1(ym - ah)} L${f1(aw)} ${f1(ym)} L1 ${f1(ym + ah)} Z"/>`;
      const tr = P.trend, n = !isNum(tr) || Math.abs(tr) < 0.3 ? 0 : Math.abs(tr) < 1.5 ? 1 : 2, up = tr > 0, cw = aw * 0.38, cx = aw * 0.42;
      for (let i = 0; i < n; i++) {
        const yy = up ? ym - ah - u * 0.55 - i * u * 0.6 : ym + ah + u * 0.55 + i * u * 0.6, d = up ? -1 : 1;
        g += `<path class="b-chev ${up ? "up" : "down"}" d="M${f1(cx - cw)} ${f1(yy - d * cw * 0.6)} L${f1(cx)} ${f1(yy + d * cw * 0.4)} L${f1(cx + cw)} ${f1(yy - d * cw * 0.6)}"/>`;
      }
    }
    box.innerHTML = g + `</svg>`; box.dataset.sig = sig;
  }

  /* ---------------- humidity / UV ---------------- */
  const UV_COL = ["#9db38a", "#9db38a", "#b9b48a", "#dba673", "#e08a58", "#d9703f", "#c4572e", "#b23a2a", "#9a2a34", "#82284a", "#6e2a66"];
  (function buildUV() {
    let s = "";
    for (let i = 0; i < 11; i++) {
      const cx = 20 + i * 40, cy = 20; let rays = "";
      for (let j = 0; j < 8; j++) { const [x1, y1] = pol(cx, cy, 11, j * 45), [x2, y2] = pol(cx, cy, 17, j * 45); rays += `M${f1(x1)} ${f1(y1)} L${f1(x2)} ${f1(y2)} `; }
      s += `<g class="uvg" data-i="${i}" style="--c:${UV_COL[i]}"><circle cx="${cx}" cy="${cy}" r="7.5"/><path d="M${cx - 2.5} ${cy} a2.5 2.5 0 1 1 2.5 2.5" /><path d="${rays}"/></g>`;
    }
    $("uvGlyphs").innerHTML = s;
  })();
  function humText(rh, dew, unit) {
    if (!isNum(rh)) return "--";
    let dp = dew; if (isNum(dp) && unit === "°C") dp = dp * 9 / 5 + 32;
    if (isNum(dp)) { if (dp < 50) return "Dry"; if (dp < 60) return "Comfortable"; if (dp < 65) return "Sticky"; if (dp < 70) return "Humid"; return "Oppressive"; }
    return rh < 30 ? "Dry" : rh < 60 ? "Comfortable" : "Humid";
  }
  const uvText = (uv) => (uv < 3 ? "Low" : uv < 6 ? "Moderate" : uv < 8 ? "High" : uv < 11 ? "Very high" : "Extreme");

  /* ---------------- next 12 hours: the dune horizon ---------------- */
  function smoothPath(pts) {
    if (pts.length < 2) return "";
    let d = `M${f1(pts[0][0])} ${f1(pts[0][1])}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      d += ` C${f1(p1[0] + (p2[0] - p0[0]) / 6)} ${f1(p1[1] + (p2[1] - p0[1]) / 6)} ${f1(p2[0] - (p3[0] - p1[0]) / 6)} ${f1(p2[1] - (p3[1] - p1[1]) / 6)} ${f1(p2[0])} ${f1(p2[1])}`;
    }
    return d;
  }
  let hourList = [];
  function renderHourly(hours) { hourList = hours.slice(0, 12); drawDunes(); }
  function drawDunes() {
    const el = $("hours"), W = el.clientWidth, H = el.clientHeight;
    const list = hourList;
    if (!W || !H) return;
    if (!list.length) { setHTML("hours", `<div class="label dunes-none">Hourly forecast unavailable</div>`); el.dataset.sig = ""; return; }
    const sig = JSON.stringify([list.map((h) => [h.time, h.temp, h.icon, h.precip]), W, H, h24]);
    if (el.dataset.sig === sig) return;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    const n = list.length, cw = W / 12;
    const temps = list.map((h) => h.temp).filter(isNum);
    const mn = Math.min.apply(null, temps), mx = Math.max.apply(null, temps), span = Math.max(1, mx - mn);
    const fsH = u * 1.05, fsT = u * 1.55, fsP = u * 0.95, ic = Math.min(cw * 0.62, H * 0.27);
    const yHour = fsH * 1.05;                                 // hour labels along the sky
    const crestTop = yHour + fsH * 0.5 + ic + fsT * 1.25;     // highest dune crest
    const crestBot = H - fsP * 2.2;                           // lowest crest (precip sits below in the sand)
    const pts = list.map((h, i) => [(i + 0.5) * cw, isNum(h.temp) ? crestTop + (1 - (h.temp - mn) / span) * (crestBot - crestTop) : (crestTop + crestBot) / 2]);
    const ext = [[-cw * 0.5, pts[0][1] + 6], ...pts, [W + cw * 0.5, pts[n - 1][1] + 6]];
    const line = smoothPath(ext);
    const back = smoothPath(ext.map(([x, y], i) => [x, Math.min(H - 2, y + 14 + (i % 2 ? 8 : -4))]));
    let s = `<svg class="dune-svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-label="next 12 hours"><defs>
      <linearGradient id="duneG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e6b07c"/><stop offset=".5" stop-color="#c77a4a"/><stop offset="1" stop-color="#8e4428"/></linearGradient>
      <linearGradient id="duneB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a65a3a"/><stop offset="1" stop-color="#5a2a22"/></linearGradient></defs>`;
    s += `<path class="dune-back" d="${back} L${W + cw} ${H} L${-cw} ${H} Z"/>`;
    s += `<path class="dune-front" d="${line} L${W + cw} ${H} L${-cw} ${H} Z"/><path class="dune-crest" d="${line}"/>`;
    list.forEach((h, i) => {
      const [x, y] = pts[i];
      s += `<text class="dh${i === 0 ? " now" : ""}" x="${f1(x)}" y="${f1(yHour)}" font-size="${f1(fsH)}">${esc(i === 0 ? "Now" : fmtHour(h.time))}</text>`;
      const iy = y - fsT * 1.2 - ic;
      const wi = wicon(h.icon), vb = (wi.match(/viewBox="([^"]+)"/) || [0, "0 0 64 64"])[1];
      s += `<svg x="${f1(x - ic / 2)}" y="${f1(iy)}" width="${f1(ic)}" height="${f1(ic)}" viewBox="${vb}" overflow="visible">${wi.replace(/^<svg[^>]*>|<\/svg>$/g, "")}</svg>`;
      s += `<text class="dt" x="${f1(x)}" y="${f1(y - fsT * 0.3)}" font-size="${f1(fsT)}">${fi(h.temp)}°</text>`;
      const p = isNum(h.precip) ? h.precip : null;
      if (p !== null) s += dropLabel(x, Math.min(H - fsP * 0.4, y + fsP * 1.6), fsP, p);
    });
    s += `</svg>`;
    el.innerHTML = s; el.dataset.sig = sig;
  }
  // Redraw the pixel-sized gauges when the grid OR their own boxes resize (a box can change size
  // without the grid changing, e.g. when fonts load or a neighbour's text wraps).
  if (window.ResizeObserver) {
    const ro = new ResizeObserver(() => { drawDunes(); drawCairns(); drawStrata(); });
    ["grid", "ltBars", "hours", "strataBox"].forEach((id) => { const e = document.getElementById(id); if (e) ro.observe(e); });
  }

  /* ---------------- lightning: storm over the mesa, cairn chart ---------------- */
  function strikeRecentRed(L) { return isNum(L.last_epoch) && nowS() - L.last_epoch < 600; }
  function lightningActive(L) { return isNum(L.last_epoch) && nowS() - L.last_epoch < 1800; }
  function setLamp(el, color, blink) {
    if (!el) return;
    const sm = el.classList.contains("sm") ? " sm" : "", extra = el.classList.contains("lt-lamp") ? " lt-lamp" : "";
    const cls = "lamp" + sm + extra + (color ? " " + color : "") + (blink ? " blink" : "");
    if (el.className !== cls) el.className = cls;
  }
  function strikeWhen(ts) {
    if (!isNum(ts)) return "";
    if (dayKey(ts) === dayKey(nowS())) return "at " + fmtTime(ts);
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000)) + ", " + fmtTime(ts);
  }
  function flashLightning() {
    flashCard($("ltCard"));
    const b = $("strikeBadge"); b.classList.remove("zap"); void b.offsetWidth; b.classList.add("zap");
  }
  function onStrikeCore(e) {
    if (!DATA || !isNum(e.epoch)) return;
    const ep = e.epoch + OFFSET / 1000;
    const L = DATA.lightning = DATA.lightning && typeof DATA.lightning === "object" ? DATA.lightning : {};
    if (!isNum(L.last_epoch) || ep >= L.last_epoch) { L.last_epoch = ep; L.last_distance = e.distance; }
    ["count_1h", "count_3h", "count_today", "count_month", "count_30m"].forEach((k) => { L[k] = (isNum(L[k]) ? L[k] : 0) + 1; });
    if (isNum(e.distance)) L.nearest_30m = isNum(L.nearest_30m) ? Math.min(L.nearest_30m, e.distance) : e.distance;
    if (Array.isArray(L.hourly) && L.hourly.length) {
      const hr = Math.floor(ep / 3600) * 3600; let last = L.hourly[L.hourly.length - 1];
      for (let g = 0; last && isNum(last.time) && last.time < hr && g < 48; g++) { L.hourly.shift(); last = { time: last.time + 3600, count: 0, min_distance: null }; L.hourly.push(last); }
      if (last && last.time === hr) last.count = (isNum(last.count) ? last.count : 0) + 1;
    }
    renderLightning(L, DATA.units || {}); updateStrikeBadge(); flashLightning();
  }
  let cairnData = null;
  function drawCairns() {
    const el = $("ltBars"); if (!cairnData || !el) return;
    const { counts, active } = cairnData, W = el.clientWidth, H = el.clientHeight;
    if (!W || !H) return;
    const sig = JSON.stringify([counts, active, W, H]);
    if (el.dataset.sig === sig) return;
    const n = counts.length, mx = Math.max(1, Math.max.apply(null, counts)), cw = W / n, MAXS = 6;
    const sh = (H - 3) / MAXS, sw = Math.min(cw * 0.78, sh * 2.4);
    let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-label="strikes per hour, last ${n} hours">`;
    s += `<path class="cairn-ground" d="M0 ${H - 1.5} H${W}"/>`;
    counts.forEach((c, i) => {
      if (!c) return;
      const k = Math.max(1, Math.round(Math.sqrt(c / mx) * MAXS)), now = i === n - 1 && active;
      let g = `<g class="cairn${now ? " now" : ""}"><title>${c} strikes</title>`;
      for (let j = 0; j < k; j++) {
        const w = sw * (1 - j * 0.07) * (j % 2 ? 0.9 : 1), off = ((i * 7 + j * 3) % 5 - 2) * cw * 0.03;
        const x = (i + 0.5) * cw - w / 2 + off, y = H - 3 - (j + 1) * sh + 0.8;
        g += `<rect class="st${(i + j) % 3}" x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(sh - 1.6)}" rx="${f1(Math.min(sh, w) * 0.45)}"/>`;
      }
      s += g + `</g>`;
    });
    el.innerHTML = s + `</svg>`; el.dataset.sig = sig;
  }
    /* 1.5.5: the Lightning card is always on screen. Strike data is cleaned before drawing, a draw that
     fails falls back to the last good values (never a blank or missing card), and missing values show "—".
     The card's tap/strike highlight uses the class "lt-flash" ("flash" is the full-screen sky-flash
     layer in some themes; putting that class on the card hid it after the first live strike). */
  let ltLastGood = null;
  const fiD = (v) => (isNum(v) ? fi(v) : "\u2014");
  function cleanLightning(L) {
    const src = L && typeof L === "object" ? L : {}, n = (v) => (isNum(v) ? v : null), out = Object.assign({}, src);
    ["last_epoch", "last_distance", "count_1h", "count_3h", "count_today", "count_month", "count_30m", "nearest_30m"].forEach((k) => { out[k] = n(src[k]); });
    out.hourly = Array.isArray(src.hourly) ? src.hourly.map((b) => (b && typeof b === "object"
      ? { time: n(b.time), count: isNum(b.count) ? b.count : 0, min_distance: n(b.min_distance) } : { time: null, count: 0, min_distance: null })) : null;
    return out;
  }
  function renderLightning(L, U) {
    const card = $("ltCard"); if (!card) return;
    card.classList.remove("flash", "hidden");
    try { const c = cleanLightning(L); renderLightningCore(c, U || {}); ltLastGood = c; }
    catch (err) {
      try { console.info("wxdash: lightning draw failed, keeping the last good values", err); } catch (_) {}
      try { if (ltLastGood) renderLightningCore(ltLastGood, U || {}); } catch (_) {}
    }
  }
  function flashCard(c) {
    if (!c) return;
    c.classList.remove("flash", "lt-flash"); void c.offsetWidth; c.classList.add("lt-flash");
    clearTimeout(c._ltf); c._ltf = setTimeout(() => c.classList.remove("lt-flash"), 900);
  }
  function onStrike(e) {
    try { onStrikeCore(e && typeof e === "object" ? e : {}); }
    catch (err) {
      try { console.info("wxdash: strike update failed", err); } catch (_) {}
      if (DATA) renderLightning(DATA.lightning, DATA.units || {});
    }
  }
  function renderLightningCore(L, U) {
    const dist = U.distance || "mi", has = isNum(L.last_epoch), active = lightningActive(L), red = active && strikeRecentRed(L);
    $("ltCard").classList.toggle("active", active);
    $("ltCard").classList.toggle("near", red);
    setLamp($("ltLamp"), active ? (red ? "red" : "amber") : "", active);
    const near = isNum(L.nearest_30m) ? L.nearest_30m : L.last_distance;
    const noData = !has && !isNum(L.count_1h) && !isNum(L.count_3h) && !isNum(L.count_today);
    setText("ltStatusText", active ? (isNum(near) ? `Active \u00b7 ${fiD(near)} ${dist}` : "Active") : noData ? "No data" : "No strikes nearby");
    setText("ltDist", has && isNum(L.last_distance) ? fiD(L.last_distance) : "\u2014");
    setText("ltUnit", dist);
    setText("ltAgo", has ? ago(L.last_epoch) : noData ? "\u2014" : "No strikes detected");
    setText("ltWhen", has ? strikeWhen(L.last_epoch) : "\u00a0");
    [["ltC1", L.count_1h], ["ltC3", L.count_3h], ["ltCT", L.count_today], ["ltCM", L.count_month]].forEach(([id, v]) => { setText(id, fiD(v)); $(id).classList.toggle("zero", fiD(v) === "0"); });
    const hrs = Array.isArray(L.hourly) ? L.hourly : null;
    if (!hrs || !hrs.length) { cairnData = null; setHTML("ltBars", `<div class="lt-none">Hourly history unavailable</div>`); $("ltBars").dataset.sig = ""; setText("ltPeak", ""); $("ltAxis").classList.add("hidden"); return; }
    $("ltAxis").classList.remove("hidden");
    const counts = hrs.map((b) => (isNum(b.count) ? b.count : 0)), total = counts.reduce((a, b) => a + b, 0);
    setText("ltPeak", total ? `${total} in ${hrs.length}h` : `None in ${hrs.length}h`);
    $("ltAxis").children[0].textContent = hrs.length + "h ago"; $("ltAxis").children[1].textContent = Math.round(hrs.length / 2) + "h";
    cairnData = { counts, active }; drawCairns();
  }

  /* ---------------- small text fitting helpers ---------------- */
  function fitOne(el, minK) {
    if (!el) return;
    const key = el.textContent + "|" + el.clientWidth; if (el.dataset.fit === key) return; el.dataset.fit = key;
    el.style.fontSize = ""; el.classList.remove("two");
    const base = parseFloat(getComputedStyle(el).fontSize);
    for (let f = base; el.scrollWidth > el.clientWidth + 0.5 && f > base * minK; ) { f *= 0.95; el.style.fontSize = f + "px"; }
    if (el.scrollWidth > el.clientWidth + 0.5) { el.style.fontSize = ""; el.classList.add("two"); }
  }
  const FIT = ["heroCond", "fcUntil", "moonName", "fcTmCond", "baroTendency"];
  function fitAll() { FIT.forEach((id) => fitOne($(id), 0.72)); document.querySelectorAll(".card-head .tag").forEach((t) => fitOne(t, 0.72)); fitBigTemp(); }
  window.addEventListener("resize", () => { FIT.forEach((id) => { const e = $(id); if (e) e.dataset.fit = ""; }); document.querySelectorAll(".card-head .tag").forEach((t) => { t.dataset.fit = ""; }); fitAll(); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { FIT.forEach((id) => { const e = $(id); if (e) e.dataset.fit = ""; }); fitAll(); if ($("hours")) $("hours").dataset.sig = ""; drawDunes(); });

  /* ---------------- clock ---------------- */
  let lastDateMin = -1;
  function tickClock() {
    const d = new Date(nowMs());
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", second: "2-digit", hour12: !h24 }).formatToParts(d);
    let h = "", m = "", sec = "", ap = "";
    parts.forEach((p) => { if (p.type === "hour") h = p.value; else if (p.type === "minute") m = p.value; else if (p.type === "second") sec = p.value; else if (p.type === "dayPeriod") ap = p.value; });
    if (h24 && h === "24") h = "00";
    setText("clock", h + ":" + m); setText("clockSec", ":" + sec); setText("ampm", ap);
    const minKey = Math.floor(d.getTime() / 60000);
    if (minKey !== lastDateMin) { lastDateMin = minKey; setText("date", new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric" }).format(d)); }
  }
  function clockLoop() { tickClock(); setTimeout(clockLoop, 1000 - (Date.now() % 1000) + 15); }

  /* ---------------- mock-only test values (same as Industrial) ---------------- */
  function applyMockOverrides(d) {
    if (!MOCK || !d) return d;
    d = JSON.parse(JSON.stringify(d));
    const F = d.forecast || {}, N = F.now || {};
    if (params.has("fc_until")) N.until = params.get("fc_until");
    if (params.has("fc_temp")) N.temp = parseFloat(params.get("fc_temp"));
    if (params.has("fc_wind")) N.wind = parseFloat(params.get("fc_wind"));
    if (params.has("fc_dir")) N.wind_dir = params.get("fc_dir");
    if (params.has("fc_icon")) N.icon = params.get("fc_icon");
    const M = (d.astro && d.astro.moon) || {};
    if (params.has("moon_illum")) M.illumination = parseFloat(params.get("moon_illum"));
    if (params.has("moon_waxing")) M.waxing = params.get("moon_waxing") === "1";
    if (params.has("moon_name")) M.name = params.get("moon_name");
    if (params.has("moon_set")) M.set = null;
    if (params.has("temp") && d.temp) {
      const raw = params.get("temp"), v = raw === "none" || raw === "" ? null : parseFloat(raw);
      d.temp.now = isNum(v) ? v : null;
      if (isNum(v)) { d.temp.feels = v; d.temp.high = Object.assign({}, d.temp.high, { value: Math.max(v, (d.temp.high || {}).value ?? v) }); d.temp.low = Object.assign({}, d.temp.low, { value: Math.min(v, (d.temp.low || {}).value ?? v) }); }
    }
    if (params.get("tunit") === "c" && d.temp) {
      const c = (f) => (isNum(f) ? Math.round((f - 32) / 1.8 * 10) / 10 : f), t = d.temp;
      t.now = c(t.now); t.feels = c(t.feels); t.dew = c(t.dew);
      if (t.high) t.high.value = c(t.high.value); if (t.low) t.low.value = c(t.low.value);
      d.units = Object.assign({}, d.units, { temp: "\u00B0C" });
    }
    if (MOCK_TIME) {   // shift the demo data to the overridden clock
      const off = OFFSET / 1000, A = d.astro || {}, now = nowS();
      const isDay = (t) => isNum(A.sunrise) && isNum(A.sunset) ? t >= A.sunrise && t < A.sunset : true;
      const dn = (ic, t) => String(ic || "").replace(isDay(t) ? "-night" : "-day", isDay(t) ? "-day" : "-night");
      ["obs_time", "server_time"].forEach((k) => { if (isNum(d[k])) d[k] += off; });
      const L = d.lightning || {};
      if (isNum(L.last_epoch)) L.last_epoch += off;
      if (Array.isArray(L.hourly)) L.hourly.forEach((b) => { if (isNum(b.time)) b.time += off; });
      const start = Math.ceil(now / 3600) * 3600;
      (F.hourly || []).forEach((h, i) => { h.time = start + i * 3600; h.icon = dn(h.icon, h.time); });
      if (N.icon) N.icon = dn(N.icon, now);
      A.is_day = isDay(now);
    }
    return d;
  }

  /* ---------------- render ---------------- */
  /* 1.5.8: the "Feeling …" chip uses the Menu > Feels-like labels cut-offs (static/feel.js); the server's text until they load */
  function paintComfort() {
    const T = (DATA && DATA.temp) || {};
    const c = (window.WXFeel && WXFeel.label(T.feels, ((DATA && DATA.units) || {}).temp)) || T.comfort;
    setText("comfort", c || "--"); $("comfort").classList.toggle("hidden", !c);
  }
  function render(d) {
    // the mock clock override is defined in the STATION's zone: recompute it if the zone changed
    if (d && d.station && d.station.tz && d.station.tz !== tz) { tz = d.station.tz; computeOffset(); }
    d = applyMockOverrides(d);
    DATA = d;
    tz = (d.station && d.station.tz) || tz;
    updateSky();
    h24 = d.station && d.station.time_format === "24";
    const U = d.units || {};
    const T = d.temp || {}, W = d.wind || {}, P = d.pressure || {}, R = d.rain || {}, H = d.humidity || {};
    const F = d.forecast || {}, FN = F.now || {}, FT = F.today || {}, A = d.astro || {}, M = A.moon || {};
    const hasData = isNum(d.obs_time);
    setText("stationName", (d.station && d.station.name) || "Weather Station");
    document.title = ((d.station && d.station.name) || "Weather") + " \u2014 " + fx(T.now) + "°";
    updateStatus();

    // hero
    const heroIcon = FN.icon || (hasData ? (A.is_day === false ? "clear-night" : "clear-day") : "cloudy");
    if ($("heroIcon").dataset.icon !== heroIcon) { $("heroIcon").innerHTML = wicon(heroIcon); $("heroIcon").dataset.icon = heroIcon; }
    setText("heroCond", FN.conditions || (hasData ? "Observed" : "--"));
    paintComfort();
    setArrow("trendArrow", T.trend); setText("trendVal", isNum(T.trend) ? signed(T.trend) + "°" : "--");
    setArrow("diffArrow", T.diff24, 0.5); setText("diffVal", isNum(T.diff24) ? signed(T.diff24) + "°" : "--");
    setText("feels", isNum(T.feels) ? fx(T.feels) + "°" : "--");
    setText("dewHero", isNum(T.dew) ? fx(T.dew) + "°" : "--");
    setText("humHero", isNum(H.now) ? fi(H.now) + "%" : "--");
    renderHero(T, U);

    // wind
    setText("windDesc", W.description || (W.calm ? "Calm" : "--"));
    setWind(W.speed, W.dir, W.dir_cardinal || (W.calm ? null : W.cardinal), W.cardinal, !!W.calm, U.wind || "mph", W.gust);
    setHTML("windAvg", isNum(W.avg_today) ? `${fx(W.avg_today)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setHTML("windGust", isNum(W.gust_max) ? `${fx(W.gust_max)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setText("gustNow", isNum(W.gust) ? fx(W.gust) : "--");

    // barometer
    setText("baroVal", isNum(P.slp) ? fx(P.slp, U.pressure === "inHg" ? 2 : 1) : "--");
    setText("baroUnit", U.pressure || "mb");
    setText("baroTrendText", P.trend_text || "--");
    setArrow("baroArrow", P.trend, 0.3);
    setText("baroTrend", isNum(P.trend) ? `${signed(P.trend)} ${U.pressure}/hr` : "--");
    setText("baroTendency", P.tendency || "--");
    setText("baroLow", P.low && isNum(P.low.value) ? fx(P.low.value) : "--");
    setText("baroHigh", P.high && isNum(P.high.value) ? fx(P.high.value) : "--");
    setText("baroLowT", P.low ? fmtTime(P.low.time) : "");
    setText("baroHighT", P.high ? fmtTime(P.high.time) : "");
    setBaro(P);

    // moon & sun
    const moonSig = `${M.illumination}|${M.waxing}`;
    if ($("moonSvg").dataset.sig !== moonSig) { $("moonSvg").innerHTML = moonArt(M.illumination, M.waxing); $("moonSvg").dataset.sig = moonSig; }
    setText("moonName", M.name || "--");
    setText("moonIllum", isNum(M.illumination) ? M.illumination + "% lit" : "--");
    setText("moonRise", fmtTime(M.rise)); setText("moonSet", fmtTime(M.set));
    setText("nextNew", fmtDay(M.next_new)); setText("nextFull", fmtDay(M.next_full));
    setText("sunRise", fmtTime(A.sunrise)); setText("sunSet", fmtTime(A.sunset));

    // humidity / uv / solar
    setText("humVal", fi(H.now));
    $("humPin").style.left = (isNum(H.now) ? clamp01(H.now / 100) * 100 : 0).toFixed(1) + "%";
    $("humPin").style.opacity = isNum(H.now) ? "1" : "0";
    setText("humDesc", humText(H.now, T.dew, U.temp));
    const uv = d.solar && d.solar.uv;
    setHTML("uv", isNum(uv) ? `${fx(uv)} <span class="unit">${uvText(uv)}</span>` : "--");
    const lit = isNum(uv) ? Math.max(1, Math.min(11, Math.round(uv))) : 0;
    document.querySelectorAll("#uvGlyphs .uvg").forEach((g) => g.classList.toggle("on", +g.dataset.i < lit));
    const rad = d.solar && d.solar.radiation;
    setHTML("solar", isNum(rad) ? `${fi(rad)}<span class="unit">W/m²</span>` : "--");

    // rain: clay ollas
    const pu = U.precip || "in", dec = pu === "mm" ? 1 : 2;
    const scales = pu === "mm" ? { today: 25, yesterday: 25, month: 125, year: 600 } : { today: 1, yesterday: 1, month: 5, year: 25 };
    document.querySelectorAll("#rainBars .pot").forEach((el) => {
      const k = el.dataset.k, v = R[k];
      const txt = isNum(v) ? (k === "year" && pu === "in" ? v.toFixed(1) : v.toFixed(dec)) : "--";
      const rv = el.querySelector(".rv");
      if (rv.dataset.v !== txt) { rv.dataset.v = txt; rv.innerHTML = esc(txt) + (isNum(v) ? `<span class="ru">${pu === "in" ? "\u2033" : " mm"}</span>` : ""); }
      const pct = isNum(v) ? Math.min(1, v / Math.max(scales[k], v)) : 0;
      el.querySelector(".water").style.transform = `scaleY(${(v > 0 ? Math.max(0.05, pct) : 0).toFixed(3)})`;
    });
    setText("rainText", R.rate_text || "--");
    setText("rainRate", isNum(R.rate) ? `${fx(R.rate, dec)} ${U.rate || "in/hr"}` : "--");

    // forecast
    setText("fcUntil", FN.until || FN.conditions || "--");
    const fci = FN.icon || "cloudy";
    if ($("fcIcon").dataset.icon !== fci) { $("fcIcon").innerHTML = wicon(fci); $("fcIcon").dataset.icon = fci; }
    setText("fcTemp", isNum(FN.temp) ? fi(FN.temp) + "°" : "--");
    setText("fcLow", isNum(FT.low) ? fi(FT.low) + "°" : "--");
    setText("fcHigh", isNum(FT.high) ? fi(FT.high) + "°" : "--");
    const rainPct = isNum(FT.precip) ? FT.precip : FN.precip;
    setPct("fcRainPill", rainPct, "--");
    setText("fcWind", isNum(FN.wind) ? `${fi(FN.wind)} ${U.wind} ${FN.wind_dir || ""}`.trim() : "--");
    const DL = Array.isArray(F.daily) ? F.daily : [];
    const tmKey = dayKey(nowS() + 86400);
    const TM = DL.find((x) => x && isNum(x.time) && dayKey(x.time + 3600) === tmKey) || DL.find((x) => x && isNum(x.time) && x.time > nowS()) || null;
    $("fcTm").classList.toggle("empty", !TM);
    if (TM) {
      const tmi = String(TM.icon || "cloudy").replace("-night", "-day");
      if ($("fcTmIcon").dataset.icon !== tmi) { $("fcTmIcon").innerHTML = wicon(tmi); $("fcTmIcon").dataset.icon = tmi; }
      setText("fcTmDay", "Tomorrow \u00b7 " + new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(new Date((TM.time + 3600) * 1000)));
      setText("fcTmCond", TM.conditions || "--");
      setText("fcTmHigh", isNum(TM.high) ? fi(TM.high) + "°" : "--");
      setText("fcTmLow", isNum(TM.low) ? fi(TM.low) + "°" : "--");
      setPct("fcTmRain", TM.precip, "");
    } else {
      setText("fcTmDay", "Tomorrow"); setText("fcTmCond", "Forecast unavailable");
      setText("fcTmHigh", "--"); setText("fcTmLow", "--"); setPct("fcTmRain", null, "");
      $("fcTmIcon").innerHTML = ""; $("fcTmIcon").dataset.icon = "";
    }

    fitAll();
    renderHourly(F.hourly || []);
    renderLightning(d.lightning || {}, U);
    updateStrikeBadge();
    if (openPanel) showPanel(openPanel, true);
  }

  /* ---------------- status / live / strike badge ---------------- */
  function updateStatus() {
    const d = DATA, pill = $("statusPill");
    let cls = "loading", txt = "Connecting…";
    if (serverDown) { cls = "error"; txt = "Dashboard server unreachable" + (lastFetchOk ? " · showing data from " + ago(lastFetchOk / 1000 + OFFSET / 1000) : ""); }
    else if (d) {
      if (d.mock) { cls = "mock"; txt = "Demo data"; }
      else if (d.status === "ok") { cls = "ok"; txt = "Live · updated " + ago(d.obs_time); }
      else if (d.status === "stale") { cls = "stale"; txt = "Stale · last obs " + ago(d.obs_time) + (d.error ? " · " + d.error : ""); }
      else if (d.status === "loading") { cls = "loading"; txt = d.error || "Loading…"; }
      else { cls = "error"; txt = "Offline · " + (d.error || "no data"); }
    }
    pill.className = "status " + cls; setText("statusText", txt);
    const noData = !d || !isNum(d.obs_time), showErr = noData && (serverDown || (d && d.status === "error"));
    $("errorState").classList.toggle("hidden", !showErr);
    body.classList.toggle("has-error", cls === "error" || cls === "stale");
    if (showErr) setText("errorMsg", serverDown ? "The wxdash server on this Pi is not responding." : (d && d.error) || "Unknown error");
  }
  function updateStrikeBadge() {
    const L = (DATA && DATA.lightning) || {}, b = $("strikeBadge");
    const recent = lightningActive(L), red = recent && strikeRecentRed(L);
    b.classList.toggle("on", recent); b.classList.toggle("near", red);
    setLamp(b.querySelector(".lamp"), recent ? (red ? "red" : "amber") : "", recent);
    if (DATA) renderLightningTick();
    setText("strikeText", recent ? `\u26A1 ${fi(L.last_distance)} ${(DATA.units && DATA.units.distance) || "mi"} \u00b7 ${ago(L.last_epoch)}` : "No strikes");
  }
  function renderLightningTick() {
    const L = (DATA && DATA.lightning) || {}, active = lightningActive(L);
    if ($("ltCard").classList.contains("active") !== active || $("ltCard").classList.contains("near") !== (active && strikeRecentRed(L))) renderLightning(L, DATA.units || {});
    else if (isNum(L.last_epoch)) { setText("ltAgo", ago(L.last_epoch)); setText("ltWhen", strikeWhen(L.last_epoch)); }
  }
  function updateLive() {
    const el = $("livePill");
    let cls = "off", txt = "Polling", title = "Live stream not connected; refreshing every 15 s";
    if (sseOpen && (wsState === "connected" || demoLive)) { cls = "on"; txt = "Live"; title = demoLive ? "Simulated live feed (demo)" : "WeatherFlow live feed connected"; }
    else if (sseOpen && wsState === "connecting") { cls = "wait"; txt = "Reconnecting"; title = "WeatherFlow live feed reconnecting; using REST updates"; }
    el.className = "ind live " + cls;
    setLamp(el.querySelector(".lamp"), cls === "on" ? "green" : cls === "wait" ? "amber" : "", cls === "wait");
    el.title = title; setText("liveText", txt);
  }

  /* ---------------- theme picker (saved on the Pi via POST /api/settings) ---------------- */
  const THEME = "desert";
  const THEMES = [["classic", "Classic"], ["industrial", "Industrial"], ["desert", "Desert"], ["arctic", "Arctic"], ["redwoods", "Redwoods"]];
  let themeMsg = "";
  function themeHTML() {
    return `<div class="theme-pick"><div class="label">Theme</div><div class="theme-btns">` +
      THEMES.map(([k, n]) => `<button data-act="theme" data-theme="${k}" class="${k === THEME ? "on" : ""}" aria-pressed="${k === THEME}">` +
        `<span class="tn">${n}</span><span class="cur">${k === THEME ? "\u2713 Current" : "Tap to switch"}</span></button>`).join("") +
      `</div>${themeMsg ? `<div class="theme-msg">${esc(themeMsg)}</div>` : ""}</div>`;
  }
  function urlWithoutTheme() { const u = new URL(location.href); u.searchParams.delete("theme"); u.searchParams.delete("panel"); return u.toString(); }
  async function setTheme(t) {
    if (!t || t === THEME) { closePanel(); return; }
    themeMsg = "Switching\u2026"; showPanel("menu", true);
    try {
      const r = await fetch("/api/settings", { method: "POST", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ theme: t }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      location.replace(urlWithoutTheme());
    } catch (e) { themeMsg = "Couldn't switch theme: " + (e.message || e); showPanel("menu", true); }
  }
  // Another screen switched the theme: follow it (not for ?theme= previews).
  function onSettings(s) { if (s && s.feel && window.WXFeel) WXFeel.sync(s.feel); if (s && s.theme && s.theme !== THEME && !params.get("theme")) location.replace(urlWithoutTheme()); }
  fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()).then((s) => {
    if (s && s.saved === false) themeMsg = "Theme not saved on the Pi (run install.sh once); it resets when wxdash restarts.";
  }).catch(() => {});

  /* ---------------- overlays ---------------- */
  function showPanel(name, refresh) {
    const d = DATA || {}, U = d.units || {};
    let html = "";
    if (name === "sager") {
      const S = d.sager, P = d.pressure || {};
      html = `<h3>Sager-style outlook</h3><div class="lead">Barometric forecast for the next 12–24 hours</div>
        <div class="big">${esc(S ? S.outlook : "Not enough pressure history yet")}</div>
        <div class="grid3"><div><div class="label">Sea-level pressure</div><div class="v">${fx(P.slp)} <small>${esc(U.pressure)}</small></div></div>
        <div><div class="label">3-hour trend</div><div class="v">${signed(P.trend)} <small>${esc(U.pressure)}/hr</small></div></div>
        <div><div class="label">Tendency</div><div class="v sm">${esc(P.trend_text || "--")}</div></div></div>
        <div class="note">Computed on this Pi with the Zambretti barometer method (pressure, 3-hour trend and season).${P.tendency ? " Barometer tendency: " + esc(P.tendency) + "." : ""}</div>`;
    } else if (name === "menu") {
      const s = d.station || {};
      html = `<h3>${esc(s.name || "Weather Station")}</h3><div class="lead">Station ${esc(s.id || "--")} · Tempest ${esc(s.device || "--")} · ${isNum(s.lat) ? s.lat.toFixed(4) + ", " + s.lon.toFixed(4) : ""}</div>
        <div class="grid3"><div><div class="label">Data</div><div class="v sm">${esc(d.mock ? "Demo" : d.status || "--")}</div></div>
        <div><div class="label">Last observation</div><div class="v sm">${esc(fmtTime(d.obs_time))}</div></div>
        <div><div class="label">Version</div><div class="v sm">wxdash ${esc(d.version || "")}</div></div></div>
        ${d.error ? `<div class="note">${esc(d.error)}</div>` : ""}
        ${themeHTML()}
        <div class="rowbtn"><button data-act="refresh">Refresh now</button><button data-act="reload">Reload page</button>
        <button data-act="lite">${body.classList.contains("lite") ? "Lite mode: on" : "Lite mode: off"}</button>
        ${window.WXFeel ? WXFeel.menuButton() : ""}<button data-act="cursor">${body.classList.contains("show-cursor") ? "Hide cursor" : "Show cursor"}</button></div>`;
    } else if (name === "feel" && window.WXFeel) {
      html = WXFeel.panelHTML(d);
    }
    if (!html) return;
    if (refresh && $("overlayBody").dataset.panel === name && $("overlayBody").innerHTML === html) return;
    $("overlayBody").innerHTML = html; $("overlayBody").dataset.panel = name;
    $("overlayBody").parentNode.classList.toggle("sheet-feel", name === "feel");
    $("overlay").classList.remove("hidden"); openPanel = name;
    if (!refresh) { clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000); }
  }
  function closePanel() { $("overlay").classList.add("hidden"); openPanel = null; clearTimeout(overlayTimer); }
  document.querySelectorAll("[data-panel]").forEach((b) => b.addEventListener("click", () => showPanel(b.dataset.panel)));
  $("strikeBadge").addEventListener("click", () => { flashCard($("ltCard")); });
  if (window.WXFeel) WXFeel.init({ show: (n) => showPanel(n),
    changed: () => { paintComfort(); if (openPanel === "feel" || openPanel === "menu") showPanel(openPanel, true); } });
  $("overlayClose").addEventListener("click", closePanel);
  $("overlay").addEventListener("click", (e) => { if (e.target === $("overlay")) closePanel(); });
  $("overlayBody").addEventListener("click", (e) => {
    const btn = e.target && e.target.closest ? e.target.closest("[data-act]") : null, act = btn && btn.dataset.act;
    if (act && act.indexOf("feel-") === 0 && window.WXFeel) {   // Feels-like labels editor: keep the sheet open while tapping
      clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000);
      WXFeel.act(act, btn); return;
    }
    if (act === "theme") setTheme(btn.dataset.theme);
    else if (act === "refresh") { load(); closePanel(); }
    else if (act === "reload") location.reload();
    else if (act === "lite") { body.classList.toggle("lite"); localStorage.setItem("wxdash-lite", body.classList.contains("lite") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "cursor") { body.classList.toggle("show-cursor"); localStorage.setItem("wxdash-cursor", body.classList.contains("show-cursor") ? "1" : "0"); showPanel("menu", true); }
  });

  /* ---------------- polling / live stream ---------------- */
  function dataQuery() {
    const q = new URLSearchParams();
    if (MOCK) q.set("mock", "1");
    if (params.get("lightning")) q.set("lightning", params.get("lightning"));
    const qs = q.toString(); return qs ? "?" + qs : "";
  }
  function startStream() {
    if (!window.EventSource || params.get("stream") === "0") return;
    try { sse = new EventSource("/api/stream" + dataQuery()); } catch (e) { return; }
    const ok = () => { if (!sseOpen) { sseOpen = true; updateLive(); } };
    const parse = (ev, fn) => { try { fn(JSON.parse(ev.data)); ok(); } catch (e) { /* ignore bad event */ } };
    sse.addEventListener("open", ok);
    sse.addEventListener("error", () => { sseOpen = false; updateLive(); });
    sse.addEventListener("data", (ev) => parse(ev, (d) => { serverDown = false; lastFetchOk = Date.now(); render(d); }));
    sse.addEventListener("wind", (ev) => parse(ev, onRapidWind));
    sse.addEventListener("strike", (ev) => parse(ev, onStrike));
    sse.addEventListener("settings", (ev) => parse(ev, onSettings));
    sse.addEventListener("live", (ev) => parse(ev, (l) => { wsState = l.ws || "off"; demoLive = !!l.demo; updateLive(); }));
  }
  async function load() {
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch("/api/data" + dataQuery(), { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const d = await r.json();
      serverDown = false; lastFetchOk = Date.now();
      if (d.live) { wsState = d.live.ws || "off"; demoLive = !!d.live.demo; }
      render(d); updateLive();
    } catch (e) { serverDown = true; updateStatus(); }
  }

  /* ---------------- sky follows the sun (1.5.2) ----------------
     The backdrop, the hero scene and the moon card's sky are coloured from the sun's real
     elevation at the STATION (station lat/lon from the API, UTC epoch -> works whatever zone the
     browser is in). Phases: night -> dawn (pink/peach/lavender, civil twilight to ~1 h after
     sunrise) -> day (clear desert blue) -> late afternoon (golden-orange) -> dusk (orange,
     magenta, purple; first stars) -> night (stars, twinkles, shooting star, moonlight).
     Colours are interpolated once a minute (no running animation, no filters); only the
     twinkles/shooting star animate (opacity/transform), and not in Lite mode or reduced motion.
     Night look (body.night) = sun below -6 deg (end of civil twilight) instead of 8 PM - 6 AM. */
  const NIGHT_FORCE = MOCK && params.has("night") ? params.get("night") === "1" : null;
  const RMQ = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
  function localHour() {
    try { return +new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hourCycle: "h23" }).format(new Date(nowMs())) % 24; }
    catch (e) { return new Date(nowMs()).getHours(); }
  }
  function isNightHour() { const h = localHour(); return h >= 20 || h < 6; }   // fallback only (no station position yet)
  // Low-precision solar position (NOAA / Astronomical Almanac, ~0.1 deg; plenty for colours).
  function sunPos(ms, lat, lon) {
    const R = Math.PI / 180, d = ms / 86400000 - 10957.5;                // days since J2000.0
    const g = (357.529 + 0.98560028 * d) * R, q = 280.459 + 0.98564736 * d;
    const L = (q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * R, e = (23.439 - 0.00000036 * d) * R;
    const ra = Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L)) / R, dec = Math.asin(Math.sin(e) * Math.sin(L));
    const gmst = 280.46061837 + 360.98564736629 * d;
    let ha = ((gmst + lon - ra) % 360 + 540) % 360 - 180;                  // hour angle, -180..180 (neg = morning)
    const la = lat * R, el = Math.asin(Math.sin(la) * Math.sin(dec) + Math.cos(la) * Math.cos(dec) * Math.cos(ha * R)) / R;
    const c0 = (Math.sin(-0.833 * R) - Math.sin(la) * Math.sin(dec)) / (Math.cos(la) * Math.cos(dec));
    const h0 = c0 <= -1 ? 180 : c0 >= 1 ? 0 : Math.acos(c0) / R;          // sunset hour angle
    return { el, ha, h0, maxEl: 90 - Math.abs(lat - dec / R) };
  }
  // Pre-made palettes: sky [top, mid, low, horizon]; ground [mesa1, mesa2, mesaFar, nearTop, nearBot, ground]
  const SKY = {
    night: ["#05040f", "#0c0a22", "#181234", "#2a1636"],
    dawn:  ["#34366f", "#7c66a6", "#de94a6", "#f6bc98"],
    day:   ["#17487f", "#2b6aa8", "#4f8fc4", "#86b9d8"],
    aft:   ["#1d4478", "#56689a", "#cf875c", "#f08446"],
    dusk:  ["#1c1240", "#55245e", "#ad3e66", "#e8734a"],
  };
  const GND = {
    night: ["#1e1028", "#120818", "#2a1634", "#2c1532", "#120814", "#0a0410"],
    dawn:  ["#5e3452", "#3e1f3a", "#74405a", "#5a2a40", "#2a1222", "#200c18"],
    day:   ["#8a4430", "#5c2820", "#9a4e36", "#723322", "#341410", "#26100c"],
    aft:   ["#954630", "#62281c", "#a8553a", "#7c3520", "#38150c", "#28100a"],
    dusk:  ["#5a2440", "#3a1530", "#6a2c48", "#5a2533", "#2a1220", "#1e0c18"],
  };
  const hexRGB = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const mixHex = (a, b, t) => { const A = hexRGB(a), B = hexRGB(b); return "rgb(" + A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(",") + ")"; };
  const sstep = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  // Two neighbouring phases blend at any moment: returns [from, to, t] (+ the dominant name).
  function skyPhase(s) {
    const e = s.el, am = s.ha < 0, mx = Math.max(4, s.maxEl);
    const dayE = Math.min(14, mx * 0.45), aftA = Math.min(28, mx * 0.68), aftB = Math.min(9, mx * 0.28);
    let p;
    if (e <= -14) p = ["night", "night", 0];
    else if (am) {
      if (e < -6) p = ["night", "dawn", sstep(-14, -6, e)];
      else if (e < 3) p = ["dawn", "dawn", 0];
      else p = ["dawn", "day", sstep(3, Math.max(5, dayE), e)];
    } else {
      if (e > aftA) p = ["day", "day", 0];
      else if (e > aftB) p = ["day", "aft", 1 - sstep(aftB, aftA, e)];
      else if (e > -2.5) p = ["aft", "dusk", 1 - sstep(-2.5, Math.max(-1, aftB * 0.6), e)];
      else if (e > -6) p = ["dusk", "dusk", 0];
      else p = ["dusk", "night", 1 - sstep(-14, -6, e)];
    }
    p.push(p[2] < 0.5 ? p[0] : p[1]);
    return p;
  }
  let skyEls = null, skyKey = "", shootTimer = 0, skyStars = 0, sunInfo = null;
  function skyNodes() {
    if (skyEls) return skyEls;
    const stops = (id) => Array.from(document.querySelectorAll("#" + id + " stop"));
    skyEls = { bg: stops("bgDay"), hs: stops("hsDay"), ms: stops("mskyD"), glow: stops("horizGlowG"),
      ns: document.querySelectorAll(".bg-night, .sky-n"), stars: document.querySelectorAll(".bg-stars, .stars-n"),
      moonlit: document.querySelectorAll(".moonlit"), shimmer: document.querySelector("#tScene .shimmer"),
      m1: document.querySelector(".bg-mesa1"), m2: document.querySelector(".bg-mesa2"), far: document.querySelector("#tScene .mesa-far"),
      near: stops("mesaG"), ground: document.querySelector("#tScene .ground"),
      sun: $("skySun"), sunCore: $("skySunCore"), glowG: $("skyGlow") };
    return skyEls;
  }
  function stationPos() {
    const S = (DATA && DATA.station) || {};
    return isNum(S.lat) && isNum(S.lon) && Math.abs(S.lat) <= 90 && Math.abs(S.lon) <= 180 ? [S.lat, S.lon] : null;
  }
  function updateSky() {
    if (document.hidden) return;                        // paused while hidden; refreshed on visibilitychange
    const pos = stationPos();
    if (!pos) { body.classList.toggle("night", NIGHT_FORCE !== null ? NIGHT_FORCE : isNightHour()); return; }
    const s = sunPos(nowMs(), pos[0], pos[1]);
    if (NIGHT_FORCE === true) s.el = Math.min(s.el, -20);   // ?mock=1&night=1 preview
    sunInfo = s;
    const [a, b, t, name] = skyPhase(s), N = skyNodes();
    const key = a + b + t.toFixed(3) + Math.round(s.ha * 4) + "/" + (((DATA && DATA.astro && DATA.astro.moon) || {}).illumination);
    const night = NIGHT_FORCE !== null ? NIGHT_FORCE : s.el < -6;
    body.classList.toggle("night", night);
    body.dataset.sky = name; body.dataset.sunEl = s.el.toFixed(2);
    if (key === skyKey) return; skyKey = key;
    const sky = SKY[a].map((c, i) => mixHex(c, SKY[b][i], t)), gnd = GND[a].map((c, i) => mixHex(c, GND[b][i], t));
    N.bg.forEach((st, i) => st.setAttribute("stop-color", sky[i]));
    N.hs.forEach((st, i) => st.setAttribute("stop-color", sky[i]));
    if (N.ms.length === 2) { N.ms[0].setAttribute("stop-color", sky[0]); N.ms[1].setAttribute("stop-color", sky[2]); }
    N.ns.forEach((el) => { el.style.opacity = "0"; });          // the palette already includes the night sky
    if (N.m1) N.m1.style.fill = gnd[0]; if (N.m2) N.m2.style.fill = gnd[1]; if (N.far) N.far.style.fill = gnd[2];
    if (N.near.length === 2) { N.near[0].setAttribute("stop-color", gnd[3]); N.near[1].setAttribute("stop-color", gnd[4]); }
    if (N.ground) N.ground.style.fill = gnd[5];
    // stars fade in from sunset to nautical dusk (and out again before dawn)
    skyStars = 1 - sstep(-11, -1.5, s.el);
    N.stars.forEach((el) => { el.style.opacity = skyStars.toFixed(3); });
    body.classList.toggle("sky-stars", skyStars > 0.05);
    // moonlight on the mesas/dunes: night only, brighter with a fuller moon
    const M = (DATA.astro && DATA.astro.moon) || {}, illum = isNum(M.illumination) ? M.illumination / 100 : 0.5;
    const moon = (1 - sstep(-14, -7, s.el)) * (0.25 + 0.75 * illum);
    N.moonlit.forEach((el) => { el.style.opacity = (moon * 0.22).toFixed(3); });
    // heat shimmer only in daylight (and paused otherwise)
    if (N.shimmer) { const sh = sstep(4, 12, s.el); N.shimmer.style.opacity = sh.toFixed(2); N.shimmer.classList.toggle("off", sh < 0.02); }
    // the real sun: low over the hero mesas at dawn / late afternoon / dusk, moving left (east) -> right (west)
    // on an arc; it fades out when high so it never competes with the temperature-sun on the gauge.
    const frac = s.h0 > 0 ? 0.5 + s.ha / (2 * s.h0) : 0.5;
    const x = 70 + Math.max(-0.1, Math.min(1.1, frac)) * 760, y = 352 - Math.max(-6, s.el) / Math.max(8, s.maxEl) * 300;
    const sunOp = sstep(-3, 0.5, s.el) * (1 - sstep(12, 24, s.el));
    if (N.sun) { N.sun.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`; N.sun.style.opacity = sunOp.toFixed(3); }
    if (N.sunCore) N.sunCore.setAttribute("fill", mixHex("#ff6a30", "#ffe2c6", sstep(1, 30, s.el)));
    // horizon glow under the sun at dawn and dusk
    const glow = Math.max(0, 1 - Math.abs(s.el - 0.5) / 10);
    if (N.glowG) { N.glowG.style.transform = `translate(${Math.max(80, Math.min(820, x)).toFixed(1)}px, 0px)`; N.glowG.style.opacity = glow.toFixed(3); }
    if (N.glow.length) N.glow[0].setAttribute("stop-color", s.ha < 0 ? "#ffc0a0" : "#ff7a44");
  }
  function scheduleShoot() {
    clearTimeout(shootTimer);
    shootTimer = setTimeout(() => {
      const el = $("shootStar");
      if (el && el.animate && skyStars > 0.6 && !document.hidden && !body.classList.contains("lite") && !RMQ.matches) {
        const x0 = 120 + Math.random() * 520, y0 = 30 + Math.random() * 110, dx = 150 + Math.random() * 120, dy = dx * (0.3 + Math.random() * 0.25);
        el.animate([{ transform: `translate(${x0}px, ${y0}px)`, opacity: 0 }, { opacity: 1, offset: 0.15 },
          { transform: `translate(${x0 + dx}px, ${y0 + dy}px)`, opacity: 0 }], { duration: 1100, easing: "ease-out" });
      }
      scheduleShoot();
    }, (MOCK && params.get("shoot") === "fast" ? 4000 : 45000 + Math.random() * 45000));
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { skyKey = ""; updateSky(); } });
  // mock-only: jump the demo clock (used to render the day timelapse). Not defined without ?mock=1.
  if (MOCK) window.__wxMockAt = (hhmm) => {
    const [th, tm] = String(hhmm).split(":").map(Number);
    const p = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "numeric", second: "numeric", hourCycle: "h23" }).formatToParts(new Date());
    const g = (k) => +p.find((x) => x.type === k).value;
    OFFSET = ((th * 60 + tm) - ((g("hour") % 24) * 60 + g("minute"))) * 60000 - g("second") * 1000;
    tickClock(); updateSky(); return body.dataset.sky;
  };
  updateSky();
  scheduleShoot();
  setTimeout(function skyLoop() { updateSky(); setTimeout(skyLoop, 60000 - (nowMs() % 60000) + 50); }, 60000 - (nowMs() % 60000) + 50);
  clockLoop();
  setInterval(() => { updateStatus(); if (DATA) updateStrikeBadge(); }, 5000);
  load().then(() => { const p = params.get("panel"); if (p) showPanel(p); startStream(); });
  setInterval(() => { if (!sseOpen || Date.now() - lastFetchOk > 60000) load(); }, POLL_MS);
  let loadedVersion = null;
  async function checkVersion() {
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 8000);
      const r = await fetch("/api/health", { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) return;
      const h = await r.json();
      if (!h || !h.ok || typeof h.version !== "string" || !h.version) return;
      if (loadedVersion === null) loadedVersion = h.version;
      else if (h.version !== loadedVersion) location.reload();
      else if (h.theme && h.theme !== THEME) onSettings({ theme: h.theme });   // backup if the SSE event was missed
    } catch (e) { /* server restarting or down */ }
  }
  checkVersion();
  setInterval(checkVersion, 60000);
  setInterval(() => { const h = new Date().getHours(), m = new Date().getMinutes(); if (h === 3 && m === 30) location.reload(); }, 60000);
})();
