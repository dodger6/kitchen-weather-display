/* wxdash front-end — vanilla JS, no dependencies, works offline. */
(function () {
  "use strict";
  const POLL_MS = 15000;
  const params = new URLSearchParams(location.search);
  const MOCK = params.get("mock") === "1";
  const $ = (id) => document.getElementById(id);
  const body = document.body;
  let DATA = null;
  let lastFetchOk = 0;
  let serverDown = false;
  let tz = "America/Los_Angeles";
  let h24 = false;
  let needleAngle = null;
  let overlayTimer = null;
  let openPanel = null;
  let sse = null, sseOpen = false, wsState = "off", demoLive = false;
  let windShown = null, windAnim = 0;

  if (params.get("lite") === "1" || localStorage.getItem("wxdash-lite") === "1") body.classList.add("lite");
  if (params.get("cursor") === "1" || localStorage.getItem("wxdash-cursor") === "1") body.classList.add("show-cursor");

  /* ---------------- formatting ---------------- */
  const isNum = (v) => typeof v === "number" && isFinite(v);
  const fx = (v, d = 1) => (isNum(v) ? v.toFixed(d) : "--");
  const fi = (v) => (isNum(v) ? Math.round(v).toString() : "--");
  function signed(v, d = 1) {
    if (!isNum(v)) return "--";
    const s = Math.abs(v).toFixed(d);
    return (v > 0 ? "+" : v < 0 ? "\u2212" : "") + s;
  }
  function fmtTime(ts, opts) {
    if (!isNum(ts)) return "--";
    return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: tz, hour: "numeric", minute: "2-digit", hour12: !h24 }, opts || {})).format(new Date(ts * 1000));
  }
  function fmtHour(ts) {
    if (!isNum(ts)) return "--";
    if (h24) return fmtTime(ts, { minute: "2-digit" });
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hour12: true }).format(new Date(ts * 1000)).replace(" ", "\u2009");
  }
  function dayKey(ts) {
    return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(ts * 1000));
  }
  function fmtDay(ts) {
    if (!isNum(ts)) return "--";
    const now = Date.now() / 1000;
    if (dayKey(ts) === dayKey(now)) return "Today";
    if (dayKey(ts) === dayKey(now + 86400)) return "Tomorrow";
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000));
  }
  function ago(ts) {
    if (!isNum(ts)) return "--";
    const s = Math.max(0, Date.now() / 1000 - ts);
    if (s < 90) return Math.round(s) + "s ago";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " hr ago";
    return Math.round(s / 86400) + " days ago";
  }
  function setText(id, txt) { const el = $(id); if (el && el.textContent !== txt) el.textContent = txt; }
  function setHTML(id, html) { const el = $(id); if (el && el.innerHTML !== html) el.innerHTML = html; }
  function arrowFor(v, eps) {
    eps = eps || 0.05;
    if (!isNum(v)) return ["", ""];
    if (v > eps) return ["\u25B2", "up"];
    if (v < -eps) return ["\u25BC", "down"];
    return ["\u25B6", "flat"];
  }
  function setArrow(id, v, eps) {
    const [ch, cls] = arrowFor(v, eps);
    const el = $(id); el.textContent = ch; el.setAttribute("class", "arrow " + cls);
  }
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  /* ---------------- icons (inline SVG, viewBox 64) ---------------- */
  const DEFS = `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
    <radialGradient id="gSun" cx=".4" cy=".35" r=".7"><stop offset="0" stop-color="#fff3b0"/><stop offset=".55" stop-color="#ffd166"/><stop offset="1" stop-color="#ff9f43"/></radialGradient>
    <linearGradient id="gCloud" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#d4ddef"/></linearGradient>
    <linearGradient id="gCloudD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c3cde3"/><stop offset="1" stop-color="#8592b0"/></linearGradient>
    <linearGradient id="gMoonI" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffbe6"/><stop offset="1" stop-color="#c9d3f0"/></linearGradient>
    <radialGradient id="gMoonLit" cx=".45" cy=".4" r=".65"><stop offset="0" stop-color="#fffdf2"/><stop offset=".7" stop-color="#ecebe0"/><stop offset="1" stop-color="#c9cbd6"/></radialGradient>
    <radialGradient id="gMoonDark" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#2b3459"/><stop offset="1" stop-color="#1a2040"/></radialGradient>
  </defs></svg>`;
  document.body.insertAdjacentHTML("afterbegin", DEFS);

  const CLOUD = "M18 48h29a9.5 9.5 0 0 0 .8-19 13.5 13.5 0 0 0-25.8-3.4A10.5 10.5 0 0 0 18 48z";
  function sun(cx, cy, r) {
    let rays = "";
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4, c = Math.cos(a), s = Math.sin(a);
      rays += `<line x1="${(cx + c * (r + 4)).toFixed(1)}" y1="${(cy + s * (r + 4)).toFixed(1)}" x2="${(cx + c * (r + 8.5)).toFixed(1)}" y2="${(cy + s * (r + 8.5)).toFixed(1)}"/>`;
    }
    return `<g class="wi-rays" stroke="#ffd166" stroke-width="3.2" stroke-linecap="round">${rays}</g><circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gSun)"/>`;
  }
  function moonIcon(tx, ty, s) {
    return `<g transform="translate(${tx} ${ty}) scale(${s})"><path d="M38 10a22 22 0 1 0 17 34A18 18 0 0 1 38 10z" fill="url(#gMoonI)"/><circle cx="20" cy="18" r="1.4" fill="#fff" opacity=".9"/><circle cx="12" cy="30" r="1" fill="#fff" opacity=".7"/></g>`;
  }
  function cloud(tx, ty, s, dark) {
    return `<g class="wi-cloud"><path transform="translate(${tx} ${ty}) scale(${s})" d="${CLOUD}" fill="url(#${dark ? "gCloudD" : "gCloud"})"/></g>`;
  }
  function drops(n, color) {
    const xs = n === 2 ? [26, 38] : [22, 32, 42];
    return `<g stroke="${color || "#7dd3fc"}" stroke-width="3" stroke-linecap="round">${xs.map((x) => `<line class="wi-drop" x1="${x}" y1="50" x2="${x - 2}" y2="55"/>`).join("")}</g>`;
  }
  function flakes() {
    return `<g fill="#fff">${[22, 32, 42].map((x) => `<circle class="wi-flake" cx="${x}" cy="52" r="2.4"/>`).join("")}</g>`;
  }
  function bolt() { return `<path class="wi-bolt" d="M34 40 26 53h6l-3 9 10-14h-6l3-8z" fill="#fde047" stroke="#f59e0b" stroke-width="1" stroke-linejoin="round"/>`; }
  function wicon(name) {
    const n = String(name || "cloudy");
    const night = n.indexOf("night") >= 0;
    const small = night ? moonIcon(4, 2, 0.55) : sun(22, 20, 9);
    let g = "";
    if (n.startsWith("clear")) g = night ? moonIcon(6, 4, 1) : sun(32, 32, 14);
    else if (n.startsWith("partly-cloudy")) g = small + cloud(4, 6, 0.95);
    else if (n === "cloudy") g = cloud(-6, -6, 0.8, true) + cloud(4, 4, 0.95);
    else if (n === "foggy") g = cloud(2, -4, 0.95) + `<g class="wi-fog" stroke="#e2e8f0" stroke-width="3" stroke-linecap="round"><line x1="12" y1="50" x2="46" y2="50"/><line x1="20" y1="57" x2="54" y2="57"/></g>`;
    else if (n.startsWith("possibly-rainy")) g = small + cloud(4, -2, 0.95) + drops(2);
    else if (n === "rainy") g = cloud(2, -6, 0.95, true) + drops(3);
    else if (n.indexOf("sleet") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -6, 0.95, true) + drops(2, "#bae6fd") + `<circle class="wi-flake" cx="32" cy="54" r="2.2" fill="#fff"/>`;
    else if (n.indexOf("snow") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -6, 0.95) + flakes();
    else if (n.indexOf("thunderstorm") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -8, 0.95, true) + bolt();
    else if (n === "windy") g = `<g fill="none" stroke="#e0f2fe" stroke-width="3.5" stroke-linecap="round" class="wi-fog"><path d="M8 24h30a7 7 0 1 0-7-7"/><path d="M8 34h42a7 7 0 1 1-7 7"/><path d="M8 44h20"/></g>`;
    else g = cloud(2, 2, 0.95);
    return `<svg viewBox="0 0 64 64" aria-hidden="true">${g}</svg>`;
  }

  /* ---------------- moon phase art ---------------- */
  function moonArt(illumPct, waxing) {
    const k = Math.max(0, Math.min(1, (illumPct || 0) / 100));
    const r = 52, cx = 60, cy = 60, top = cy - r, bot = cy + r;
    let lit = "";
    if (k >= 0.995) lit = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonLit)"/>`;
    else if (k > 0.005) {
      const rx = (r * Math.abs(1 - 2 * k)).toFixed(2);
      const crescent = k < 0.5;
      let d;
      if (waxing) d = `M${cx} ${top} A${r} ${r} 0 0 1 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 0 : 1} ${cx} ${top}Z`;
      else d = `M${cx} ${top} A${r} ${r} 0 0 0 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 1 : 0} ${cx} ${top}Z`;
      lit = `<path d="${d}" fill="url(#gMoonLit)"/>`;
    }
    const craters = `<g fill="#000" opacity=".07"><circle cx="44" cy="40" r="9"/><circle cx="74" cy="50" r="6"/><circle cx="62" cy="80" r="11"/><circle cx="36" cy="70" r="5"/><circle cx="82" cy="78" r="4"/></g>`;
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonDark)" stroke="rgba(200,215,255,.35)" stroke-width="1.5"/>${lit}${craters}`;
  }

  /* ---------------- static gauge furniture ---------------- */
  (function buildTicks() {
    let s = "";
    for (let d = 0; d < 360; d += 10) {
      if (d % 90 === 0) continue;
      const major = d % 30 === 0;
      const a = (d * Math.PI) / 180, r1 = major ? 76 : 80, r2 = 88;
      s += `<line class="${major ? "major" : ""}" x1="${(100 + Math.sin(a) * r1).toFixed(1)}" y1="${(100 - Math.cos(a) * r1).toFixed(1)}" x2="${(100 + Math.sin(a) * r2).toFixed(1)}" y2="${(100 - Math.cos(a) * r2).toFixed(1)}"/>`;
    }
    $("ticks").innerHTML = s;
  })();

  /* ---------------- clock ---------------- */
  function tickClock() {
    const d = new Date();
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", hour12: !h24 }).formatToParts(d);
    let hm = "", ap = "";
    parts.forEach((p) => { if (p.type === "dayPeriod") ap = p.value; else if (p.type !== "literal" || p.value === ":") hm += p.value; });
    setHTML("clock", esc(hm) + (ap ? `<span class="ampm">${esc(ap)}</span>` : ""));
    setText("date", new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric" }).format(d));
  }

  /* ---------------- theme ---------------- */
  function pickTheme(d) {
    const icon = (d.forecast && d.forecast.now && d.forecast.now.icon) || "";
    const a = d.astro || {};
    const alt = a.sun_altitude;
    const night = a.is_day === false || icon.indexOf("night") >= 0 && a.is_day !== true;
    if (icon.indexOf("thunder") >= 0) return "storm";
    if (icon.indexOf("rain") >= 0 || icon.indexOf("sleet") >= 0) return "rain";
    if (icon.indexOf("snow") >= 0) return "snow";
    if (icon === "cloudy" || icon === "foggy") return night ? "cloudy-night" : "cloudy-day";
    if (isNum(alt) && alt > -6 && alt < 6) return "dusk";
    return night ? "night" : "clear-day";
  }

  /* ---------------- render ---------------- */
  /* Shrink the hero temperature until the full value (degree sign included)
     fits the temperature card. CSS cqi sizing gives the first guess; this
     corrects for font metrics and never grows past the CSS maximum. */
  function fitTemp() {
    const el = document.querySelector(".big-temp");
    const row = el && el.parentNode;
    if (!el || !row) return;
    el.style.fontSize = "";                       // back to the CSS (cqi/clamp) size
    const avail = row.clientWidth;
    if (!avail) return;
    let fs = parseFloat(getComputedStyle(el).fontSize);
    const minFs = 12;
    for (let i = 0; i < 40 && el.scrollWidth > avail && fs > minFs; i++) {
      const ratio = avail / el.scrollWidth;
      fs = Math.max(minFs, Math.floor(i < 3 ? fs * ratio : fs - 1));
      el.style.fontSize = fs + "px";
    }
  }
  let fitRaf = 0;
  const refit = () => { cancelAnimationFrame(fitRaf); fitRaf = requestAnimationFrame(fitTemp); };
  window.addEventListener("resize", refit);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(refit);
  if (window.ResizeObserver) { const ro = new ResizeObserver(refit); const r0 = document.querySelector(".temp-row"); if (r0) ro.observe(r0); }

  /* Mock-only test values: ?mock=1&temp=104.5 (or temp=none for "no data"). */
  function applyMockOverrides(d) {
    if (!MOCK || !params.has("temp") || !d || !d.temp) return d;
    const raw = params.get("temp");
    const v = raw === "none" || raw === "" ? null : parseFloat(raw);
    const t = Object.assign({}, d.temp);
    t.now = isNum(v) ? v : null;
    if (isNum(v)) {
      t.feels = v;
      t.high = Object.assign({}, t.high, { value: Math.max(v, (t.high && t.high.value) ?? v) });
      t.low = Object.assign({}, t.low, { value: Math.min(v, (t.low && t.low.value) ?? v) });
    }
    return Object.assign({}, d, { temp: t });
  }

  function render(d) {
    d = applyMockOverrides(d);
    DATA = d;
    tz = (d.station && d.station.tz) || tz;
    h24 = d.station && d.station.time_format === "24";
    const U = d.units || {};
    const T = d.temp || {}, W = d.wind || {}, P = d.pressure || {}, R = d.rain || {}, H = d.humidity || {};
    const F = d.forecast || {}, FN = F.now || {}, FT = F.today || {}, A = d.astro || {}, M = A.moon || {};
    const hasData = isNum(d.obs_time);

    setText("stationName", (d.station && d.station.name) || "Weather Station");
    document.title = ((d.station && d.station.name) || "Weather") + " — " + fx(T.now) + "°";
    body.dataset.theme = pickTheme(d);
    updateStatus();

    // hero
    const heroIcon = FN.icon || (hasData ? (A.is_day === false ? "clear-night" : "clear-day") : "cloudy");
    if ($("heroIcon").dataset.icon !== heroIcon) { $("heroIcon").innerHTML = wicon(heroIcon); $("heroIcon").dataset.icon = heroIcon; }
    setText("heroCond", FN.conditions || (hasData ? "Observed" : "--"));
    setText("comfort", T.comfort || "--");
    $("comfort").classList.toggle("hidden", !T.comfort);
    setText("tempNow", fx(T.now));
    const tl = fx(T.now).length;
    $("tempNow").parentNode.classList.toggle("long", tl === 5);
    $("tempNow").parentNode.classList.toggle("xlong", tl >= 6);
    $("tempNow").parentNode.classList.toggle("empty", !isNum(T.now));
    fitTemp();
    setArrow("trendArrow", T.trend);
    setText("trendVal", isNum(T.trend) ? signed(T.trend) + "°" : "--");
    setArrow("diffArrow", T.diff24, 0.5);
    setText("diffVal", isNum(T.diff24) ? signed(T.diff24) + "°" : "--");
    setText("feels", isNum(T.feels) ? fx(T.feels) + "°" : "--");
    setText("dewHero", isNum(T.dew) ? fx(T.dew) + "°" : "--");
    setText("humHero", isNum(H.now) ? fi(H.now) + "%" : "--");
    const lo = T.low || {}, hi = T.high || {};
    setText("lowVal", isNum(lo.value) ? fx(lo.value) + "°" : "--");
    setText("highVal", isNum(hi.value) ? fx(hi.value) + "°" : "--");
    setText("lowTime", fmtTime(lo.time));
    setText("highTime", fmtTime(hi.time));
    if (isNum(lo.value) && isNum(hi.value) && isNum(T.now)) {
      const span = Math.max(0.1, hi.value - lo.value);
      const pos = Math.max(0, Math.min(1, (T.now - lo.value) / span));
      $("rangeDot").style.left = (pos * 100).toFixed(1) + "%";
    }
    $("rangeDot").style.opacity = isNum(lo.value) && isNum(hi.value) && isNum(T.now) ? "1" : "0";

    // wind
    setText("windDesc", W.description || (W.calm ? "Calm" : "--"));
    setWind(W.speed, W.dir, W.dir_cardinal || (W.calm ? null : W.cardinal), W.cardinal, !!W.calm, U.wind || "mph");
    setHTML("windAvg", isNum(W.avg_today) ? `${fx(W.avg_today)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setHTML("windGust", isNum(W.gust_max) ? `${fx(W.gust_max)}<span class="unit">${esc(U.wind)}</span>` : "--");

    // barometer
    const slpMb = P.slp_mb;
    setText("baroVal", isNum(P.slp) ? fx(P.slp, U.pressure === "inHg" ? 2 : 1) : "--");
    setText("baroUnit", U.pressure || "mb");
    setText("baroTrendText", P.trend_text || "--");
    setArrow("baroArrow", P.trend, 0.3);
    setText("baroTrend", isNum(P.trend) ? `${signed(P.trend)} ${U.pressure}/hr` : "--");
    setText("baroTendency", P.tendency || "--");
    setText("baroLow", P.low && isNum(P.low.value) ? fx(P.low.value) : "--");
    setText("baroHigh", P.high && isNum(P.high.value) ? fx(P.high.value) : "--");
    setText("baroLowT", P.low ? fmtTime(P.low.time) : "");
    setText("baroHighT", P.high ? fmtTime(P.high.time) : "");
    if (isNum(slpMb)) {
      const frac = Math.max(0, Math.min(1, (slpMb - 950) / 100));
      $("baroArc").style.strokeDashoffset = (100 - frac * 100).toFixed(2);
      $("baroMarker").style.transform = `rotate(${(-120 + frac * 240).toFixed(2)}deg)`;
    }
    $("baroMarker").style.opacity = isNum(slpMb) ? "1" : "0";

    // moon & sun
    setHTML("moonSvg", moonArt(M.illumination, M.waxing));
    setText("moonName", M.name || "--");
    setText("moonIllum", isNum(M.illumination) ? M.illumination + "% lit" : "--");
    setText("moonRise", fmtTime(M.rise));
    setText("moonSet", fmtTime(M.set));
    setText("nextNew", fmtDay(M.next_new));
    setText("nextFull", fmtDay(M.next_full));
    setText("sunRise", fmtTime(A.sunrise));
    setText("sunSet", fmtTime(A.sunset));

    // humidity
    setText("humVal", fi(H.now));
    if (isNum(H.now)) $("humArc").style.strokeDashoffset = (100 - Math.max(0, Math.min(100, H.now))).toFixed(1);
    setText("humDesc", humText(H.now, T.dew, U.temp));
    setText("dew", isNum(H.dew) ? fx(H.dew) + "°" : "--");
    const uv = d.solar && d.solar.uv;
    setHTML("uv", isNum(uv) ? `${fx(uv)} <span class="unit">${uvText(uv)}</span>` : "--");
    const rad = d.solar && d.solar.radiation;
    setHTML("solar", isNum(rad) ? `${fi(rad)}<span class="unit">W/m²</span>` : "--");

    // rain
    const pu = U.precip || "in", dec = pu === "mm" ? 1 : 2;
    const scales = pu === "mm" ? { today: 25, yesterday: 25, month: 125, year: 600 } : { today: 1, yesterday: 1, month: 5, year: 25 };
    document.querySelectorAll("#rainBars .rb").forEach((el) => {
      const k = el.dataset.k, v = R[k];
      el.querySelector(".rv").textContent = isNum(v) ? (k === "year" && pu === "in" ? v.toFixed(1) : v.toFixed(dec)) + (pu === "in" ? "\u2033" : "") : "--";
      const pct = isNum(v) ? Math.min(100, (v / Math.max(scales[k], v)) * 100) : 0;
      el.querySelector(".bar i").style.height = pct.toFixed(1) + "%";
    });
    setText("rainText", R.rate_text || "--");
    setText("rainRate", isNum(R.rate) ? `${fx(R.rate, dec)} ${U.rate || "in/hr"}` : "--");

    // forecast now
    setText("fcUntil", FN.until || FN.conditions || "--");
    const fci = FN.icon || "cloudy";
    if ($("fcIcon").dataset.icon !== fci) { $("fcIcon").innerHTML = wicon(fci); $("fcIcon").dataset.icon = fci; }
    setText("fcTemp", isNum(FN.temp) ? fi(FN.temp) + "°" : "--");
    setText("fcLow", isNum(FT.low) ? fi(FT.low) + "°" : "--");
    setText("fcHigh", isNum(FT.high) ? fi(FT.high) + "°" : "--");
    const rainPct = isNum(FT.precip) ? FT.precip : FN.precip;
    setText("fcRainPill", isNum(rainPct) ? `\u{1F4A7} ${fi(rainPct)}%` : "--");
    setText("fcWind", isNum(FN.wind) ? `${fi(FN.wind)} ${U.wind} ${FN.wind_dir || ""}`.trim() : "--");

    renderHourly(F.hourly || []);
    renderLightning(d.lightning || {}, U);
    updateStrikeBadge();
    if (openPanel) showPanel(openPanel, true);
  }

  /* wind: shared by full renders and 3-second rapid_wind pushes */
  function tweenWind(to) {
    cancelAnimationFrame(windAnim);
    if (!isNum(to)) { windShown = null; setText("windNow", "--"); return; }
    const from = isNum(windShown) ? windShown : to;
    const t0 = performance.now(), dur = 280;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      windShown = from + (to - from) * e;
      setText("windNow", windShown.toFixed(1));
      if (k < 1) windAnim = requestAnimationFrame(step);
      else windShown = to;
    };
    if (from === to || body.classList.contains("lite")) { windShown = to; setText("windNow", fx(to)); }
    else windAnim = requestAnimationFrame(step);
  }
  function setWind(speed, dir, dirCard, fallbackTxt, calm, unit) {
    tweenWind(speed);
    setText("windNowUnit", unit || "mph");
    setHTML("windDir", isNum(dir) ? `${esc(dirCard || "--")}<span class="unit">${fi(dir)}°</span>` : esc(fallbackTxt || "--"));
    if (isNum(dir)) {
      if (needleAngle === null) needleAngle = dir;
      else { const delta = ((dir - needleAngle) % 360 + 540) % 360 - 180; needleAngle += delta; }
      $("needle").style.transform = `rotate(${needleAngle}deg)`;
    }
    $("needle").classList.toggle("calm", !!calm);
    $("needle").style.opacity = isNum(dir) ? "" : "0";
  }
  const CARD16 = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  function onRapidWind(w) {
    if (!DATA || !isNum(w.speed)) return;
    const W = DATA.wind = DATA.wind || {};
    const calm = w.calm != null ? !!w.calm : w.speed < 1;
    const dir = isNum(w.dir) ? w.dir : W.dir;
    const card = w.dir_cardinal || (isNum(dir) ? CARD16[Math.round(dir / 22.5) % 16] : null);
    Object.assign(W, { speed: w.speed, dir: dir, calm: calm, dir_cardinal: card, cardinal: calm ? "Calm" : card });
    setWind(w.speed, dir, card, W.cardinal, calm, (DATA.units && DATA.units.wind) || w.unit);
    const c = document.querySelector(".card.wind");
    c.classList.remove("tick"); void c.offsetWidth; c.classList.add("tick");
  }

  function humText(rh, dew, unit) {
    if (!isNum(rh)) return "--";
    let dp = dew;
    if (isNum(dp) && unit === "°C") dp = dp * 9 / 5 + 32;
    if (isNum(dp)) {
      if (dp < 50) return "Dry";
      if (dp < 60) return "Comfortable";
      if (dp < 65) return "Sticky";
      if (dp < 70) return "Humid";
      return "Oppressive";
    }
    return rh < 30 ? "Dry" : rh < 60 ? "Comfortable" : "Humid";
  }
  function uvText(uv) {
    return uv < 3 ? "Low" : uv < 6 ? "Moderate" : uv < 8 ? "High" : uv < 11 ? "Very high" : "Extreme";
  }

  function smoothPath(pts) {
    if (pts.length < 2) return "";
    let d = `M${pts[0][0]} ${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)} ${c2x.toFixed(1)} ${c2y.toFixed(1)} ${p2[0]} ${p2[1].toFixed(1)}`;
    }
    return d;
  }

  function renderHourly(hours) {
    const list = hours.slice(0, 12);
    if (!list.length) { setHTML("hours", `<div class="label" style="grid-column:1/-1;grid-row:1/-1;align-self:center;text-align:center">Hourly forecast unavailable</div>`); return; }
    const temps = list.map((h) => h.temp).filter(isNum);
    const mn = Math.min.apply(null, temps), mx = Math.max.apply(null, temps), span = Math.max(1, mx - mn);
    const n = list.length;
    const pts = list.map((h, i) => [((i + 0.5) * 1200) / 12, isNum(h.temp) ? 12 + (1 - (h.temp - mn) / span) * 76 : 50]);
    const line = smoothPath(pts);
    const area = line + ` L${pts[n - 1][0]} 100 L${pts[0][0]} 100 Z`;
    let html = `<svg class="spark" viewBox="0 0 1200 100" preserveAspectRatio="none" aria-hidden="true"><defs>
      <linearGradient id="sparkG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffd166"/><stop offset="1" stop-color="#7cc4ff"/></linearGradient>
      <linearGradient id="sparkA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="rgba(255,209,102,.28)"/><stop offset="1" stop-color="rgba(124,196,255,0)"/></linearGradient></defs>
      <path class="area" d="${area}"/><path class="line" d="${line}"/></svg>`;
    list.forEach((h, i) => {
      const p = isNum(h.precip) ? h.precip : null;
      html += `<div class="hcell"><div class="h${i === 0 ? " now" : ""}" style="grid-column:${i + 1}">${esc(fmtHour(h.time))}</div>
        <div class="i" style="grid-column:${i + 1}">${wicon(h.icon)}</div>
        <div class="tt" style="grid-column:${i + 1}">${fi(h.temp)}°</div>
        <div class="p${!p ? " zero" : ""}" style="grid-column:${i + 1}">${p === null ? "" : fi(p) + "%"}</div></div>`;
    });
    const sig = JSON.stringify(list.map((h) => [h.time, h.temp, h.icon, h.precip]));
    const el = $("hours");
    if (el.dataset.sig !== sig) { el.innerHTML = html; el.dataset.sig = sig; }
  }

  function lightningActive(L) {
    return isNum(L.last_epoch) && Date.now() / 1000 - L.last_epoch < 1800;
  }
  function strikeWhen(ts) {
    if (!isNum(ts)) return "";
    if (dayKey(ts) === dayKey(Date.now() / 1000)) return "at " + fmtTime(ts);
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000)) + ", " + fmtTime(ts);
  }

  function flashLightning() {
    const c = $("ltCard");
    c.classList.remove("flash"); void c.offsetWidth; c.classList.add("flash");
    const b = $("strikeBadge");
    b.classList.remove("zap"); void b.offsetWidth; b.classList.add("zap");
  }
  function onStrike(e) {
    if (!DATA || !isNum(e.epoch)) return;
    const L = DATA.lightning = DATA.lightning || {};
    if (!isNum(L.last_epoch) || e.epoch >= L.last_epoch) { L.last_epoch = e.epoch; L.last_distance = e.distance; }
    ["count_1h", "count_3h", "count_today", "count_month", "count_30m"].forEach((k) => { L[k] = (isNum(L[k]) ? L[k] : 0) + 1; });
    if (isNum(e.distance)) L.nearest_30m = isNum(L.nearest_30m) ? Math.min(L.nearest_30m, e.distance) : e.distance;
    if (Array.isArray(L.hourly) && L.hourly.length) {
      const hr = Math.floor(e.epoch / 3600) * 3600;
      let last = L.hourly[L.hourly.length - 1];
      while (last.time < hr) { L.hourly.shift(); last = { time: last.time + 3600, count: 0, min_distance: null }; L.hourly.push(last); }
      if (last.time === hr) last.count += 1;
    }
    renderLightning(L, DATA.units || {});
    updateStrikeBadge();
    flashLightning();
  }

  function renderLightning(L, U) {
    const dist = U.distance || "mi";
    const has = isNum(L.last_epoch);
    const active = lightningActive(L);
    $("ltCard").classList.toggle("active", active);
    const near = isNum(L.nearest_30m) ? L.nearest_30m : L.last_distance;
    const noData = !has && !isNum(L.count_1h) && !isNum(L.count_3h) && !isNum(L.count_today);
    setText("ltStatusText", active ? `Active \u2014 strikes within ${fi(near)} ${dist}` : noData ? "No data" : "No strikes nearby");
    setHTML("ltDist", has && isNum(L.last_distance) ? `${fi(L.last_distance)}<span class="unit">${esc(dist)}</span>` : (has || noData ? "--" : "None"));
    setText("ltAgo", has ? ago(L.last_epoch) : noData ? "--" : "No strikes detected");
    setText("ltWhen", has ? strikeWhen(L.last_epoch) : "\u00a0");
    setText("ltC1", fi(L.count_1h));
    setText("ltC3", fi(L.count_3h));
    setText("ltCT", fi(L.count_today));
    setText("ltCM", fi(L.count_month));
    ["ltC1", "ltC3", "ltCT", "ltCM"].forEach((id) => { const v = $(id).textContent; $(id).classList.toggle("zero", v === "0"); });

    const hrs = Array.isArray(L.hourly) ? L.hourly : null;
    const el = $("ltBars");
    if (!hrs || !hrs.length) {
      setHTML("ltBars", `<div class="lt-none">Hourly history unavailable</div>`);
      setText("ltPeak", "");
      $("ltAxis").classList.add("hidden");
      el.dataset.sig = "";
      return;
    }
    $("ltAxis").classList.remove("hidden");
    const counts = hrs.map((b) => (isNum(b.count) ? b.count : 0));
    const mx = Math.max.apply(null, counts);
    const total = counts.reduce((a, b) => a + b, 0);
    setText("ltPeak", total ? `${total} in ${hrs.length}h` : `None in ${hrs.length}h`);
    $("ltPeak").title = total ? `Peak ${mx} strikes in one hour` : "";
    const n = hrs.length;
    const sig = JSON.stringify([counts, active]);
    if (el.dataset.sig === sig) return;
    let html = "";
    hrs.forEach((b, i) => {
      const c = counts[i];
      const h = c ? Math.max(10, Math.sqrt(c / Math.max(1, mx)) * 100) : 0;
      const cls = c ? (i === n - 1 && active ? "on now" : "on") : "";
      html += `<i class="${cls}" style="height:${h.toFixed(1)}%" title="${esc(fmtHour(b.time))}: ${c}"></i>`;
    });
    el.style.gridTemplateColumns = `repeat(${n}, 1fr)`;
    el.innerHTML = html;
    el.dataset.sig = sig;
    const axis = $("ltAxis").children;
    axis[0].textContent = n + "h ago";
    axis[1].textContent = Math.round(n / 2) + "h";
  }

  /* ---------------- status / errors ---------------- */
  function updateStatus() {
    const d = DATA;
    const pill = $("statusPill");
    let cls = "loading", txt = "Connecting…";
    if (serverDown) {
      cls = "error"; txt = "Dashboard server unreachable" + (lastFetchOk ? " · showing data from " + ago(lastFetchOk / 1000) : "");
    } else if (d) {
      if (d.mock) { cls = "mock"; txt = "Demo data"; }
      else if (d.status === "ok") { cls = "ok"; txt = "Live · updated " + ago(d.obs_time); }
      else if (d.status === "stale") { cls = "stale"; txt = "Stale · last obs " + ago(d.obs_time) + (d.error ? " · " + d.error : ""); }
      else if (d.status === "loading") { cls = "loading"; txt = d.error || "Loading…"; }
      else { cls = "error"; txt = "Offline · " + (d.error || "no data"); }
    }
    pill.className = "pill status " + cls;
    setText("statusText", txt);
    const noData = !d || !isNum(d.obs_time);
    const showErr = noData && (serverDown || (d && (d.status === "error")));
    $("errorState").classList.toggle("hidden", !showErr);
    body.classList.toggle("has-error", cls === "error" || cls === "stale");
    if (showErr) setText("errorMsg", serverDown ? "The wxdash server on this Pi is not responding." : (d && d.error) || "Unknown error");
  }

  function updateStrikeBadge() {
    const L = (DATA && DATA.lightning) || {};
    const b = $("strikeBadge");
    const recent = lightningActive(L);
    b.classList.toggle("hidden", !recent);
    if (DATA) renderLightningTick();
    if (recent) b.textContent = `\u26A1 ${fi(L.last_distance)} ${(DATA.units && DATA.units.distance) || "mi"} · ${ago(L.last_epoch)}`;
  }

  function renderLightningTick() {
    const L = (DATA && DATA.lightning) || {};
    const active = lightningActive(L);
    if ($("ltCard").classList.contains("active") !== active) renderLightning(L, DATA.units || {});
    else if (isNum(L.last_epoch)) { setText("ltAgo", ago(L.last_epoch)); setText("ltWhen", strikeWhen(L.last_epoch)); }
  }

  /* live indicator: green = WebSocket feed connected and pushing to this page */
  function updateLive() {
    const el = $("livePill");
    let cls = "off", txt = "Polling", title = "Live stream not connected; refreshing every 15 s";
    if (sseOpen && (wsState === "connected" || demoLive)) { cls = "on"; txt = "Live"; title = demoLive ? "Simulated live feed (demo)" : "WeatherFlow live feed connected"; }
    else if (sseOpen && wsState === "connecting") { cls = "wait"; txt = "Reconnecting"; title = "WeatherFlow live feed reconnecting; using REST updates"; }
    el.className = "pill live " + cls;
    el.title = title;
    setText("liveText", txt);
  }

  /* ---------------- overlays ---------------- */
  function showPanel(name, refresh) {
    const d = DATA || {};
    const U = d.units || {};
    let html = "";
    if (name === "sager") {
      const S = d.sager, P = d.pressure || {};
      html = `<h3>Sager-style outlook</h3><div class="lead">Barometric forecast for the next 12–24 hours</div>
        <div class="big">${esc(S ? S.outlook : "Not enough pressure history yet")}</div>
        <div class="grid3"><div><div class="label">Sea-level pressure</div><div class="v">${fx(P.slp)} <small>${esc(U.pressure)}</small></div></div>
        <div><div class="label">3-hour trend</div><div class="v">${signed(P.trend)} <small>${esc(U.pressure)}/hr</small></div></div>
        <div><div class="label">Tendency</div><div class="v" style="font-size:calc(var(--u)*1.3);white-space:normal">${esc(P.trend_text || "--")}</div></div></div>
        <div class="note">Computed on this Pi with the Zambretti barometer method (pressure, 3-hour trend and season).${P.tendency ? " Barometer tendency: " + esc(P.tendency) + "." : ""}</div>`;
    } else if (name === "menu") {
      const s = d.station || {};
      html = `<h3>${esc(s.name || "Weather Station")}</h3><div class="lead">Station ${esc(s.id || "--")} · Tempest ${esc(s.device || "--")} · ${isNum(s.lat) ? s.lat.toFixed(4) + ", " + s.lon.toFixed(4) : ""}</div>
        <div class="grid3"><div><div class="label">Data</div><div class="v" style="font-size:calc(var(--u)*1.4)">${esc(d.mock ? "Demo" : d.status || "--")}</div></div>
        <div><div class="label">Last observation</div><div class="v" style="font-size:calc(var(--u)*1.4)">${esc(fmtTime(d.obs_time))}</div></div>
        <div><div class="label">Version</div><div class="v" style="font-size:calc(var(--u)*1.4)">wxdash ${esc(d.version || "")}</div></div></div>
        ${d.error ? `<div class="note">${esc(d.error)}</div>` : ""}
        <div class="rowbtn"><button data-act="refresh">Refresh now</button><button data-act="reload">Reload page</button>
        <button data-act="lite">${body.classList.contains("lite") ? "Glass effects: off" : "Glass effects: on"}</button>
        <button data-act="cursor">${body.classList.contains("show-cursor") ? "Hide cursor" : "Show cursor"}</button></div>`;
    }
    if (!html) return;
    if (refresh && $("overlayBody").dataset.panel === name && $("overlayBody").innerHTML === html) return;
    $("overlayBody").innerHTML = html;
    $("overlayBody").dataset.panel = name;
    $("overlay").classList.remove("hidden");
    openPanel = name;
    if (!refresh) { clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000); }
  }
  function closePanel() { $("overlay").classList.add("hidden"); openPanel = null; clearTimeout(overlayTimer); }

  document.querySelectorAll("[data-panel]").forEach((b) => b.addEventListener("click", () => showPanel(b.dataset.panel)));
  // The header badge just draws attention to the permanent Lightning card.
  $("strikeBadge").addEventListener("click", () => {
    const c = $("ltCard"); c.classList.remove("flash"); void c.offsetWidth; c.classList.add("flash");
  });
  $("overlayClose").addEventListener("click", closePanel);
  $("overlay").addEventListener("click", (e) => { if (e.target === $("overlay")) closePanel(); });
  $("overlayBody").addEventListener("click", (e) => {
    const act = e.target && e.target.dataset && e.target.dataset.act;
    if (act === "refresh") { load(); closePanel(); }
    else if (act === "reload") location.reload();
    else if (act === "lite") { body.classList.toggle("lite"); localStorage.setItem("wxdash-lite", body.classList.contains("lite") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "cursor") { body.classList.toggle("show-cursor"); localStorage.setItem("wxdash-cursor", body.classList.contains("show-cursor") ? "1" : "0"); showPanel("menu", true); }
  });

  /* ---------------- polling ---------------- */
  function dataQuery() {
    const q = new URLSearchParams();
    if (MOCK) q.set("mock", "1");
    if (params.get("lightning")) q.set("lightning", params.get("lightning"));
    const qs = q.toString();
    return qs ? "?" + qs : "";
  }
  function startStream() {
    if (!window.EventSource || params.get("stream") === "0") return;
    try { sse = new EventSource("/api/stream" + dataQuery()); } catch (e) { return; }
    const ok = () => { if (!sseOpen) { sseOpen = true; updateLive(); } };
    const parse = (ev, fn) => { try { fn(JSON.parse(ev.data)); ok(); } catch (e) { /* ignore bad event */ } };
    sse.addEventListener("open", ok);
    sse.addEventListener("error", () => { sseOpen = false; updateLive(); });  // EventSource auto-reconnects
    sse.addEventListener("data", (ev) => parse(ev, (d) => { serverDown = false; lastFetchOk = Date.now(); render(d); }));
    sse.addEventListener("wind", (ev) => parse(ev, onRapidWind));
    sse.addEventListener("strike", (ev) => parse(ev, onStrike));
    sse.addEventListener("live", (ev) => parse(ev, (l) => { wsState = l.ws || "off"; demoLive = !!l.demo; updateLive(); }));
  }

  async function load() {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch("/api/data" + dataQuery(), { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const d = await r.json();
      serverDown = false;
      lastFetchOk = Date.now();
      if (d.live) { wsState = d.live.ws || "off"; demoLive = !!d.live.demo; }
      render(d);
      updateLive();
    } catch (e) {
      serverDown = true;
      updateStatus();
    }
  }
  tickClock();
  setInterval(tickClock, 1000);
  setInterval(() => { updateStatus(); if (DATA) updateStrikeBadge(); }, 5000);
  load().then(() => { const p = params.get("panel"); if (p) showPanel(p); startStream(); });
  // Polling is the fallback; while the live stream is healthy it only runs once a minute.
  setInterval(() => { if (!sseOpen || Date.now() - lastFetchOk > 60000) load(); }, POLL_MS);
  // Recover from long-running kiosk memory growth: reload once a day at ~3:30 AM.
  setInterval(() => { const h = new Date().getHours(), m = new Date().getMinutes(); if (h === 3 && m === 30) location.reload(); }, 60000);
})();
