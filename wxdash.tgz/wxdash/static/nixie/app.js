/* wxdash front-end — NIXIE theme (1.5.9 preview). Vanilla JS, no dependencies, works offline.
   Tube digits are drawn as SVG stroke paths (IN-12 style) with ghost cathodes + mesh;
   no emoji glyphs. Data plumbing matches Classic. */
(function () {
  "use strict";
  const POLL_MS = 15000;
  const params = new URLSearchParams(location.search);
  const MOCK = params.get("mock") === "1";
  if (MOCK) window.__wxstrike = (e) => onStrike(e);   // mock-only test hook: deliver a live evt_strike as if it came over SSE
  const $ = (id) => document.getElementById(id);
  const body = document.body;
  let DATA = null;
  let lastFetchOk = 0;
  let serverDown = false;
  let tz = "America/Los_Angeles";
  let h24 = false;
  let needleAngle = null;
  let overlayTimer = null;
  let openPanel = null;
  let sse = null, sseOpen = false, wsState = "off", demoLive = false;
  let windShown = null, windAnim = 0;

  // Smooth mode is the default (no backdrop blur, static background) because the Pi 5's
  // GPU re-blurs every glass card on every frame. ?glass=1 (or the menu) restores the
  // frosted glass + drifting background; ?glass=0 turns it back off. ?lite=1 is the
  // most minimal look (opaque cards, no wind-number tween).
  if (params.has("glass")) localStorage.setItem("wxdash-glass", params.get("glass") === "0" ? "0" : "1");
  if (localStorage.getItem("wxdash-glass") === "1") body.classList.add("glass");
  if (params.get("lite") === "1" || localStorage.getItem("wxdash-lite") === "1") body.classList.add("lite");
  if (params.get("cursor") === "1" || localStorage.getItem("wxdash-cursor") === "1") body.classList.add("show-cursor");

  /* ---------------- formatting ---------------- */
  const isNum = (v) => typeof v === "number" && isFinite(v);
  const fx = (v, d = 1) => (isNum(v) ? v.toFixed(d) : "--");
  const fi = (v) => (isNum(v) ? Math.round(v).toString() : "--");
  function signed(v, d = 1) {
    if (!isNum(v)) return "--";
    const s = Math.abs(v).toFixed(d);
    return (v > 0 ? "+" : v < 0 ? "\u2212" : "") + s;
  }
  function fmtTime(ts, opts) {
    if (!isNum(ts)) return "--";
    return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: tz, hour: "numeric", minute: "2-digit", hour12: !h24 }, opts || {})).format(new Date(ts * 1000));
  }
  function fmtHour(ts) {
    if (!isNum(ts)) return "--";
    if (h24) return fmtTime(ts, { minute: "2-digit" });
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hour12: true }).format(new Date(ts * 1000)).replace(" ", "\u2009");
  }
  function dayKey(ts) {
    return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(ts * 1000));
  }
  function fmtDay(ts) {
    if (!isNum(ts)) return "--";
    const now = Date.now() / 1000;
    if (dayKey(ts) === dayKey(now)) return "Today";
    if (dayKey(ts) === dayKey(now + 86400)) return "Tomorrow";
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000));
  }
  function ago(ts) {
    if (!isNum(ts)) return "--";
    const s = Math.max(0, Date.now() / 1000 - ts);
    if (s < 90) return Math.round(s) + "s ago";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " hr ago";
    return Math.round(s / 86400) + " days ago";
  }
  function setText(id, txt) { const el = $(id); if (el && el.textContent !== txt) el.textContent = txt; }
  function setHTML(id, html) { const el = $(id); if (el && el.innerHTML !== html) el.innerHTML = html; }
  function arrowFor(v, eps) {
    eps = eps || 0.05;
    if (!isNum(v)) return ["", ""];
    if (v > eps) return ["\u25B2", "up"];
    if (v < -eps) return ["\u25BC", "down"];
    return ["\u25B6", "flat"];
  }
  function setArrow(id, v, eps) {
    const [ch, cls] = arrowFor(v, eps);
    const el = $(id); el.textContent = ch; el.setAttribute("class", "arrow " + cls);
  }
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  /* 1.5.6: precipitation chance is drawn with an inline SVG raindrop, never the U+1F4A7 emoji
     (the Pi has no emoji font, so the emoji showed as an empty box) */
  const DROP_D = "M6 .6C6 .6 .9 6.9 .9 10.4a5.1 5.1 0 0 0 10.2 0C11.1 6.9 6 .6 6 .6Z";
  const DROP_SVG = `<svg class="drop-ic" viewBox="0 0 12 16" aria-hidden="true" focusable="false"><path d="${DROP_D}"/></svg>`;
  function setPct(id, pct, empty) {   // "<drop> 70%" chip / row; `empty` text when there is no value
    const el = $(id); if (!el) return;
    const key = isNum(pct) ? "p" + fi(pct) : "e" + empty;
    if (el.dataset.pct === key) return; el.dataset.pct = key;
    if (isNum(pct)) el.innerHTML = `${DROP_SVG}<span class="pct">${fi(pct)}%</span>`; else el.textContent = empty;
  }
  function dropLabel(x, y, fs, p) {   // SVG chart label: a drawn drop + "60%", centred on x (0% has no drop)
    if (!p) return `<text class="dp zero" x="${f1(x)}" y="${f1(y)}" font-size="${f1(fs)}">0%</text>`;
    const t = fi(p) + "%", tw = t.length * fs * 0.5, dw = fs * 0.6, gap = fs * 0.1, x0 = x - (dw + gap + tw) / 2;
    return `<path class="dp-drop" d="${DROP_D}" transform="translate(${f1(x0)} ${f1(y - fs * 0.76)}) scale(${(fs * 0.8 / 16).toFixed(3)})"/>` +
      `<text class="dp" x="${f1(x0 + dw + gap)}" y="${f1(y)}" font-size="${f1(fs)}" style="text-anchor:start">${t}</text>`;
  }


  /* ---------------- nixie tubes (SVG stroke digits, offline-safe) ----------------
     Each tube shows faint ghost cathodes (0-9) behind the lit digit, a honeycomb mesh
     overlay, and a soft blue-violet base glow (CSS). Digits are stroke paths, not fonts. */
  const NX = {
    // viewBox 0 0 40 70 — thin cathode-like strokes
    "0": "M20 8C11 8 8 18 8 35s3 27 12 27 12-10 12-27S29 8 20 8Z",
    "1": "M16 16L22 10V60M14 60H30",
    "2": "M10 20C10 12 15 9 20 9c6 0 11 4 11 11 0 8-6 13-12 18L10 60H31",
    "3": "M11 14H28L18 32c7 0 12 4 12 12 0 9-6 15-15 15-5 0-9-2-12-5",
    "4": "M26 10L10 42H30M24 10V60",
    "5": "M29 10H12L10 32h14c7 0 12 4 12 13 0 9-6 14-14 14-5 0-10-2-13-6",
    "6": "M28 16C24 11 20 9 15 9 9 9 7 16 7 28v10c0 13 4 22 13 22s13-8 13-19S27 22 18 22c-3 0-6 1-8 3",
    "7": "M9 12H31L18 60",
    "8": "M20 9c-6 0-10 4-10 10 0 6 4 9 10 12 6 3 10 6 10 13 0 8-5 13-12 13s-12-5-12-13c0-7 4-10 10-13 6-3 10-6 10-12 0-6-4-10-10-10Z",
    "9": "M12 54C16 59 20 61 25 61c6 0 8-7 8-19V32C33 19 29 10 20 10S7 18 7 29s4 19 13 19c3 0 6-1 8-3",
    "-": "M12 35H28",
    ".": "M20 56c-2.4 0-4 1.6-4 4s1.6 4 4 4 4-1.6 4-4-1.6-4-4-4Z",
  };
  const NX_GHOST = "0123456789";
  // honeycomb mesh as a few cheap diagonals (no filter / no blur)
  const NX_MESH = `<g class="mesh" stroke="rgba(180,190,210,.22)" stroke-width=".55" fill="none">` +
    Array.from({length: 9}, (_, i) => `<path d="M${2+i*4.5} 4 V66"/>`).join("") +
    Array.from({length: 7}, (_, i) => `<path d="M2 ${8+i*9} H38"/>`).join("") + `</g>`;
  function nxPaths(ch, lit) {
    const d = NX[ch];
    if (!d) return "";
    if (ch === ".") {
      return lit
        ? `<circle cx="20" cy="60" r="4.2" fill="#ff9a4a" stroke="none" opacity=".55"/>` +
          `<circle cx="20" cy="60" r="2.6" fill="#ffe6c8" stroke="none"/>`
        : `<circle cx="20" cy="60" r="2.4" fill="rgba(160,150,140,.12)" stroke="none"/>`;
    }
    if (lit) {
      // warm outer glow stroke → bright orange body → pale near-white core (cathode look)
      return `<path d="${d}" fill="none" stroke="#ff5a10" stroke-width="5.8" stroke-linecap="round" stroke-linejoin="round" opacity=".38"/>` +
             `<path d="${d}" fill="none" stroke="#ff8530" stroke-width="3.8" stroke-linecap="round" stroke-linejoin="round"/>` +
             `<path d="${d}" fill="none" stroke="#fff0d8" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>`;
    }
    // faint ghost cathodes
    return `<path d="${d}" fill="none" stroke="rgba(175,170,165,.13)" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round"/>`;
  }
  function nxSvg(ch) {
    if (!ch || ch === " ") {
      return `<svg viewBox="0 0 40 70" aria-hidden="true">${NX_MESH}</svg><i class="base-glow"></i>`;
    }
    const ghost = NX_GHOST.split("").map((g) => nxPaths(g, false)).join("");
    const lit = NX[ch] ? nxPaths(ch, true) : "";
    return `<svg viewBox="0 0 40 70" aria-hidden="true"><g class="ghosts">${ghost}</g><g class="lit">${lit}</g>${NX_MESH}</svg><i class="base-glow"></i>`;
  }
  function setTube(el, ch, opts) {
    if (!el) return;
    opts = opts || {};
    const blank = (ch == null || ch === "" || ch === " ");
    if (opts.hideBlank) {
      el.classList.toggle("blank", blank);
      if (blank) { el.dataset.d = ""; el.hidden = true; el.innerHTML = ""; return; }
      el.hidden = false;
    }
    const dig = blank ? "-" : String(ch);
    if (el.dataset.d === dig && el.querySelector("svg")) return;
    el.dataset.d = dig;
    el.innerHTML = nxSvg(blank ? "" : dig);
  }
  /* Temperature bank: integer tubes + neon decimal + tenths tube (no full "." tube). */
  function paintBank(bankEl, text) {
    if (!bankEl) return;
    const raw = String(text == null ? "--" : text).trim();
    const m = raw.match(/^(-?)(\d+)(?:\.(\d))?$/);
    const slots = [...bankEl.querySelectorAll(".nx[data-slot]")];
    const dot = bankEl.querySelector(".nx-dot") || $("tempDot");
    if (!m) {
      // fallback: show "--" on last two tubes
      slots.forEach((el, i) => {
        const show = i >= slots.length - 2;
        el.classList.toggle("blank", !show); el.hidden = !show;
        if (show) setTube(el, "-"); else { el.dataset.d = ""; el.innerHTML = ""; }
      });
      if (dot) dot.classList.add("off");
      return;
    }
    const sign = m[1], whole = m[2], frac = m[3];
    // 3 tubes: below 100 → [tens?][ones] · [tenths]; 100+ → three integer tubes, no decimal.
    let d0, d1, d2, showDot;
    if (whole.length >= 3) {
      const w = whole.slice(-3);
      d0 = w[0]; d1 = w[1]; d2 = w[2]; showDot = false;
    } else {
      d0 = whole.length === 2 ? whole[0] : null;
      d1 = whole.length === 2 ? whole[1] : whole[0];
      d2 = frac != null ? frac : null;
      showDot = d2 != null;
    }
    if (sign) { /* negative: show minus on the first visible tube by prefixing when blank leading */
      if (d0 == null) d0 = "-";
      else { d2 = d1; d1 = d0; d0 = "-"; showDot = false; }
    }
    setTube(slots[0], d0, { hideBlank: true });
    setTube(slots[1], d1 == null ? "-" : d1);
    if (slots[2]) {
      if (d2 == null) { slots[2].classList.add("blank"); slots[2].hidden = true; slots[2].dataset.d = ""; slots[2].innerHTML = ""; }
      else { slots[2].classList.remove("blank"); slots[2].hidden = false; setTube(slots[2], d2); }
    }
    if (dot) { dot.classList.toggle("off", !showDot); dot.style.display = showDot ? "" : "none"; }
  }

  /* ---------------- icons (inline SVG, viewBox 64) ---------------- */
  const DEFS = `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
    <radialGradient id="gSunGlow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ff9a4a" stop-opacity=".95"/><stop offset=".5" stop-color="#ff9a4a" stop-opacity=".6"/><stop offset=".75" stop-color="#ff9a4a" stop-opacity=".18"/><stop offset="1" stop-color="#ff9a4a" stop-opacity="0"/></radialGradient>
    <linearGradient id="gCloud" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#d4ddef"/></linearGradient>
    <linearGradient id="gCloudD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c3cde3"/><stop offset="1" stop-color="#8592b0"/></linearGradient>
    <linearGradient id="gMoonI" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe8d2"/><stop offset="1" stop-color="#c9d3f0"/></linearGradient>
    <radialGradient id="gMoonLit" cx=".45" cy=".4" r=".65"><stop offset="0" stop-color="#fffdf2"/><stop offset=".7" stop-color="#ecebe0"/><stop offset="1" stop-color="#c9cbd6"/></radialGradient>
    <radialGradient id="gMoonDark" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#2b3459"/><stop offset="1" stop-color="#1a2040"/></radialGradient>
  </defs></svg>`;
  document.body.insertAdjacentHTML("afterbegin", DEFS);

  const CLOUD = "M18 48h29a9.5 9.5 0 0 0 .8-19 13.5 13.5 0 0 0-25.8-3.4A10.5 10.5 0 0 0 18 48z";
  /* Sun: the exact drawing from the Home Assistant willows-weather-card (viewBox 120,
     colour #ff9a4a). The HA card animates a drop-shadow filter, which repaints every
     frame; here the glow is a pre-blurred radial-gradient circle (gSunGlow) behind the
     core, and only its opacity/transform animate, so the Pi just composites it. */
  const SUN_BODY = `<circle class="sun-glow" cx="60" cy="60" r="34" fill="url(#gSunGlow)"/>` +
    `<circle class="sun-core" cx="60" cy="60" r="18" fill="#ff9a4a"/>` +
    `<g class="sun-rays" stroke="#ff9a4a" stroke-width="4" stroke-linecap="round">` +
    `<line x1="60" y1="18" x2="60" y2="8"/><line x1="60" y1="112" x2="60" y2="102"/>` +
    `<line x1="18" y1="60" x2="8" y2="60"/><line x1="112" y1="60" x2="102" y2="60"/>` +
    `<line x1="30" y1="30" x2="22" y2="22"/><line x1="90" y1="90" x2="98" y2="98"/>` +
    `<line x1="90" y1="30" x2="98" y2="22"/><line x1="30" y1="90" x2="22" y2="98"/></g>`;
  // A sun inside a 64-unit icon: a nested 120-unit viewport, so transform-box:view-box
  // pivots on the sun's own centre (60,60) exactly like the HA card.
  function sun(x, y, size) {
    return `<svg class="wi-sun" x="${x}" y="${y}" width="${size}" height="${size}" viewBox="0 0 120 120" overflow="visible">${SUN_BODY}</svg>`;
  }
  function moonIcon(tx, ty, s) {
    return `<g transform="translate(${tx} ${ty}) scale(${s})"><path d="M38 10a22 22 0 1 0 17 34A18 18 0 0 1 38 10z" fill="url(#gMoonI)"/><circle cx="20" cy="18" r="1.4" fill="#fff" opacity=".9"/><circle cx="12" cy="30" r="1" fill="#fff" opacity=".7"/></g>`;
  }
  function cloud(tx, ty, s, dark) {
    return `<g class="wi-cloud"><path transform="translate(${tx} ${ty}) scale(${s})" d="${CLOUD}" fill="url(#${dark ? "gCloudD" : "gCloud"})"/></g>`;
  }
  function drops(n, color) {
    const xs = n === 2 ? [26, 38] : [22, 32, 42];
    return `<g stroke="${color || "#7dd3fc"}" stroke-width="3" stroke-linecap="round">${xs.map((x) => `<line class="wi-drop" x1="${x}" y1="50" x2="${x - 2}" y2="55"/>`).join("")}</g>`;
  }
  function flakes() {
    return `<g fill="#fff">${[22, 32, 42].map((x) => `<circle class="wi-flake" cx="${x}" cy="52" r="2.4"/>`).join("")}</g>`;
  }
  function bolt() { return `<path class="wi-bolt" d="M34 40 26 53h6l-3 9 10-14h-6l3-8z" fill="#ff9a4a" stroke="#8a3a10" stroke-width="1" stroke-linejoin="round"/>`; }
  function wicon(name) {
    const n = String(name || "cloudy");
    const night = n.indexOf("night") >= 0;
    const small = night ? moonIcon(4, 2, 0.55) : sun(2, 0, 40);
    let g = "";
    if (n.startsWith("clear") && !night) return `<svg viewBox="0 0 120 120" class="cond-svg wi-sun" aria-hidden="true">${SUN_BODY}</svg>`;
    if (n.startsWith("clear")) g = moonIcon(6, 4, 1);
    else if (n.startsWith("partly-cloudy")) g = small + cloud(4, 6, 0.95);
    else if (n === "cloudy") g = cloud(-6, -6, 0.8, true) + cloud(4, 4, 0.95);
    else if (n === "foggy") g = cloud(2, -4, 0.95) + `<g class="wi-fog" stroke="#e2e8f0" stroke-width="3" stroke-linecap="round"><line x1="12" y1="50" x2="46" y2="50"/><line x1="20" y1="57" x2="54" y2="57"/></g>`;
    else if (n.startsWith("possibly-rainy")) g = small + cloud(4, -2, 0.95) + drops(2);
    else if (n === "rainy") g = cloud(2, -6, 0.95, true) + drops(3);
    else if (n.indexOf("sleet") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -6, 0.95, true) + drops(2, "#bae6fd") + `<circle class="wi-flake" cx="32" cy="54" r="2.2" fill="#fff"/>`;
    else if (n.indexOf("snow") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -6, 0.95) + flakes();
    else if (n.indexOf("thunderstorm") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -8, 0.95, true) + bolt();
    else if (n === "windy") g = `<g fill="none" stroke="#e0f2fe" stroke-width="3.5" stroke-linecap="round" class="wi-fog"><path d="M8 24h30a7 7 0 1 0-7-7"/><path d="M8 34h42a7 7 0 1 1-7 7"/><path d="M8 44h20"/></g>`;
    else g = cloud(2, 2, 0.95);
    return `<svg viewBox="0 0 64 64" aria-hidden="true">${g}</svg>`;
  }

  /* ---------------- moon phase art ---------------- */
  function moonArt(illumPct, waxing) {
    const k = Math.max(0, Math.min(1, (illumPct || 0) / 100));
    const r = 52, cx = 60, cy = 60, top = cy - r, bot = cy + r;
    let lit = "";
    if (k >= 0.995) lit = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonLit)"/>`;
    else if (k > 0.005) {
      const rx = (r * Math.abs(1 - 2 * k)).toFixed(2);
      const crescent = k < 0.5;
      let d;
      if (waxing) d = `M${cx} ${top} A${r} ${r} 0 0 1 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 0 : 1} ${cx} ${top}Z`;
      else d = `M${cx} ${top} A${r} ${r} 0 0 0 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 1 : 0} ${cx} ${top}Z`;
      lit = `<path d="${d}" fill="url(#gMoonLit)"/>`;
    }
    const craters = `<g fill="#000" opacity=".07"><circle cx="44" cy="40" r="9"/><circle cx="74" cy="50" r="6"/><circle cx="62" cy="80" r="11"/><circle cx="36" cy="70" r="5"/><circle cx="82" cy="78" r="4"/></g>`;
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonDark)" stroke="rgba(200,215,255,.35)" stroke-width="1.5"/>${lit}${craters}`;
  }

  /* ---------------- static gauge furniture ---------------- */
  (function buildTicks() {
    let s = "";
    for (let d = 0; d < 360; d += 10) {
      if (d % 90 === 0) continue;
      const major = d % 30 === 0;
      const a = (d * Math.PI) / 180, r1 = major ? 76 : 80, r2 = 88;
      s += `<line class="${major ? "major" : ""}" x1="${(100 + Math.sin(a) * r1).toFixed(1)}" y1="${(100 - Math.cos(a) * r1).toFixed(1)}" x2="${(100 + Math.sin(a) * r2).toFixed(1)}" y2="${(100 - Math.cos(a) * r2).toFixed(1)}"/>`;
    }
    $("ticks").innerHTML = s;
  })();

  /* ---------------- clock (H:MM:SS tubes; colons steady — seconds provide the once-a-second pulse) ---------------- */
  function tickClock() {
    const d = new Date();
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, hour: h24 ? "2-digit" : "numeric", minute: "2-digit", second: "2-digit",
      hour12: !h24, hourCycle: h24 ? "h23" : undefined
    }).formatToParts(d);
    let hour = "", minute = "", second = "", ap = "";
    parts.forEach((p) => {
      if (p.type === "hour") hour = p.value;
      else if (p.type === "minute") minute = p.value;
      else if (p.type === "second") second = p.value;
      else if (p.type === "dayPeriod") ap = p.value.toUpperCase();
    });
    if (hour.length < 2) hour = h24 ? hour.padStart(2, "0") : (" " + hour).slice(-2);
    if (minute.length < 2) minute = minute.padStart(2, "0");
    if (second.length < 2) second = second.padStart(2, "0");
    // 12h: hide leading tube for 1–9 (no empty mesh). 24h / 10–12: keep it.
    const h0 = (hour[0] === " " || hour[0] === "") ? "" : hour[0];
    const h1 = hour[1] || "0";
    setTube($("clkH0"), h0, { hideBlank: true });
    setTube($("clkH1"), h1);
    setTube($("clkM0"), minute[0]);
    setTube($("clkM1"), minute[1]);
    setTube($("clkS0"), second[0]);
    setTube($("clkS1"), second[1]);
    // Steady neon colons (blink looked busy next to ticking seconds).
    const c1 = $("clkColon"); if (c1) c1.classList.remove("off");
    const c2 = $("clkColon2"); if (c2) c2.classList.remove("off");
    setText("ampm", h24 ? "" : ap);
    setText("date", new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric" }).format(d));
  }

  /* ---------------- theme ---------------- */
  function pickTheme(d) {
    const icon = (d.forecast && d.forecast.now && d.forecast.now.icon) || "";
    const a = d.astro || {};
    const alt = a.sun_altitude;
    const night = a.is_day === false || icon.indexOf("night") >= 0 && a.is_day !== true;
    if (icon.indexOf("thunder") >= 0) return "storm";
    if (icon.indexOf("rain") >= 0 || icon.indexOf("sleet") >= 0) return "rain";
    if (icon.indexOf("snow") >= 0) return "snow";
    if (icon === "cloudy" || icon === "foggy") return night ? "cloudy-night" : "cloudy-day";
    if (isNum(alt) && alt > -6 && alt < 6) return "dusk";
    return night ? "night" : "clear-day";
  }

  /* ---------------- render ---------------- */
  /* Shrink the hero temperature until the full value (degree sign included)
     fits the temperature card. CSS cqi sizing gives the first guess; this
     corrects for font metrics and never grows past the CSS maximum. */
  function fitTemp() { /* nixie tube bank sizes itself; nothing to fit */ }
  let fitRaf = 0;
  const refit = () => { cancelAnimationFrame(fitRaf); fitRaf = requestAnimationFrame(fitTemp); };
  window.addEventListener("resize", refit);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(refit);
  if (window.ResizeObserver) { const ro = new ResizeObserver(refit); const r0 = document.querySelector(".temp-row"); if (r0) ro.observe(r0); }

  /* v1.1.5 forecast card: the condition line shrinks a little to stay on one line,
     otherwise it is clamped to 2 lines by CSS; the big temperature (and icon) are
     sized to whatever height/width is left in the .fc-body grid row, so they can
     never spill onto the L/H + wind line. */
  function fitForecast() {
    const until = $("fcUntil"), bodyEl = document.querySelector(".fc-body"), t = $("fcTemp"), ic = $("fcIcon");
    const row = document.querySelector(".fc-row");
    if (!until || !bodyEl || !t || !row) return;
    const card = bodyEl.parentNode, wind = $("fcWind");
    const key = [until.textContent, t.textContent, wind && wind.textContent, $("fcTm") && $("fcTm").textContent, card.clientWidth, card.clientHeight].join("|");
    if (key === fitForecast.key) return;          // nothing changed: skip the relayout (render runs on every live tick)
    fitForecast.key = key;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    until.style.fontSize = ""; row.style.fontSize = ""; t.style.fontSize = ""; row.classList.remove("tight");
    // 1. L/H + wind always on one line: shrink that line (down to 75%) if it is too wide.
    const rowBase = parseFloat(getComputedStyle(row).fontSize);
    for (let f = rowBase; row.scrollWidth > row.clientWidth + 0.5 && f > rowBase * 0.75; ) {
      f = Math.max(rowBase * 0.75, f * Math.min(0.97, row.clientWidth / row.scrollWidth));
      row.style.fontSize = f + "px";
    }
    if (row.scrollWidth > row.clientWidth + 0.5) row.classList.add("tight");
    // 2. Condition: one line if a slightly smaller size (>= 82%) fits; otherwise two lines,
    //    shrunk (down to 75%) until the icon/temp row keeps at least minBody of height.
    const base = parseFloat(getComputedStyle(until).fontSize);
    const lines = (f) => until.scrollHeight / (f * 1.2);
    if (lines(base) > 1.5) {
      let f = base, one = false;
      while (f > base * 0.82) { f *= 0.96; until.style.fontSize = f + "px"; if (lines(f) <= 1.5) { one = true; break; } }
      if (!one) {
        f = base; until.style.fontSize = "";
        const minBody = u * 3.6;
        while (bodyEl.clientHeight < minBody && f > base * 0.75) { f *= 0.96; until.style.fontSize = f + "px"; }
      }
    }
    // 3. Big temperature: fit the height and the width left next to the icon.
    const h = bodyEl.clientHeight, w = bodyEl.clientWidth;
    if (!h || !w) return;
    const gap = parseFloat(getComputedStyle(bodyEl).columnGap) || 0;
    const icW = () => (ic && ic.offsetWidth) || 0;
    let fs = parseFloat(getComputedStyle(t).fontSize);
    for (let i = 0; i < 60 && fs > 10 && (t.offsetHeight > h || t.scrollWidth + icW() + gap > w); i++) {
      fs = Math.max(10, Math.floor(i < 3 ? fs * Math.min(h / t.offsetHeight, (w - icW() - gap) / t.scrollWidth, 0.99) : fs - 1));
      t.style.fontSize = fs + "px";
    }
  }
  let fcRaf = 0;
  const refitFc = () => { cancelAnimationFrame(fcRaf); fcRaf = requestAnimationFrame(fitForecast); };
  window.addEventListener("resize", refitFc);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(refitFc);
  if (window.ResizeObserver) { const fb = document.querySelector(".fc-body"); if (fb) new ResizeObserver(refitFc).observe(fb); }

  /* Mock-only forecast test values: ?mock=1&fc_until=...&fc_temp=104&fc_wind=25&fc_dir=WNW&fc_icon=thunderstorm */
  function applyMockForecast(d) {
    if (!MOCK || !d || !d.forecast || !["fc_until", "fc_temp", "fc_wind", "fc_dir", "fc_icon"].some((k) => params.has(k))) return d;
    const n = Object.assign({}, d.forecast.now);
    if (params.has("fc_until")) n.until = params.get("fc_until");
    if (params.has("fc_temp")) n.temp = parseFloat(params.get("fc_temp"));
    if (params.has("fc_wind")) n.wind = parseFloat(params.get("fc_wind"));
    if (params.has("fc_dir")) n.wind_dir = params.get("fc_dir");
    if (params.has("fc_icon")) n.icon = params.get("fc_icon");
    return Object.assign({}, d, { forecast: Object.assign({}, d.forecast, { now: n }) });
  }

  /* Mock-only test values: ?mock=1&temp=104.5 (or temp=none for "no data"). */
  function applyMockOverrides(d) {
    d = applyMockForecast(d);
    if (!MOCK || !(params.has("temp") || params.has("tunit")) || !d || !d.temp) return d;
    const raw = params.get("temp");
    const v = raw === "none" || raw === "" ? null : parseFloat(raw);
    const t = Object.assign({}, d.temp);
    if (params.has("temp")) t.now = isNum(v) ? v : null;
    if (isNum(v)) {
      t.feels = v;
      t.high = Object.assign({}, t.high, { value: Math.max(v, (t.high && t.high.value) ?? v) });
      t.low = Object.assign({}, t.low, { value: Math.min(v, (t.low && t.low.value) ?? v) });
    }
    let out = Object.assign({}, d, { temp: t });
    if (params.get("tunit") === "c") {  // mock-only: preview the Celsius scale
      const c = (f) => (isNum(f) ? Math.round((f - 32) / 1.8 * 10) / 10 : f);
      t.now = c(t.now); t.feels = c(t.feels); t.dew = c(t.dew);
      if (t.high) t.high = Object.assign({}, t.high, { value: c(t.high.value) });
      if (t.low) t.low = Object.assign({}, t.low, { value: c(t.low.value) });
      out.units = Object.assign({}, d.units, { temp: "\u00B0C" });
    }
    return out;
  }

  /* Temperature bar on a fixed absolute scale: 0–130 °F, or -18–54 °C. */
  const TEMP_SCALES = {
    f: { min: 0, max: 130, ticks: [0, 32, 65, 100, 130] },
    c: { min: -18, max: 54, ticks: [-18, 0, 18, 38, 54] },
  };
  let tickUnit = null;
  function fitTicks() {
    const box = $("rangeTicks");
    if (!box) return;
    const spans = Array.from(box.children);
    spans.forEach((s) => s.classList.remove("hide"));
    // Hide middle labels that would touch a neighbour (keeps 0 and 130 always).
    let prevRight = -Infinity;
    const lastLeft = spans.length ? spans[spans.length - 1].getBoundingClientRect().left : Infinity;
    spans.forEach((s, i) => {
      const r = s.getBoundingClientRect();
      const end = i === spans.length - 1;
      if (i > 0 && !end && (r.left < prevRight + 10 || r.right > lastLeft - 10)) { s.classList.add("hide"); return; }
      prevRight = r.right;
    });
  }
  function renderTempRange(T, U) {
    const unit = /C/i.test((U && U.temp) || "") ? "c" : "f";
    const S = TEMP_SCALES[unit];
    const frac = (v) => Math.max(0, Math.min(1, (v - S.min) / (S.max - S.min)));
    if (tickUnit !== unit) {
      tickUnit = unit;
      $("rangeTicks").innerHTML = S.ticks.map((t, i) =>
        `<span class="${i === 0 ? "first" : i === S.ticks.length - 1 ? "last" : ""}" style="left:${(frac(t) * 100).toFixed(2)}%">${t}°</span>`).join("");
      requestAnimationFrame(fitTicks);
    }
    const lo = (T.low || {}).value, hi = (T.high || {}).value;
    const hasRange = isNum(lo) && isNum(hi);
    const a = hasRange ? frac(Math.min(lo, hi)) : 0, b = hasRange ? frac(Math.max(lo, hi)) : 1;
    $("rangeDimLo").style.width = (a * 100).toFixed(2) + "%";
    $("rangeDimHi").style.transform = `translateX(${(b * 100).toFixed(2)}%)`;
    if (isNum(T.now)) $("rangeDotRail").style.transform = `translateX(${(frac(T.now) * 100).toFixed(2)}%)`;
    $("rangeDot").style.opacity = isNum(T.now) ? "1" : "0";
    $("tempRange").setAttribute("aria-label", `Temperature scale ${S.min} to ${S.max}°`);
  }
  window.addEventListener("resize", () => requestAnimationFrame(fitTicks));

  /* 1.5.8: the "Feeling …" chip uses the Menu > Feels-like labels cut-offs (static/feel.js); the server's text until they load */
  function paintComfort() {
    const T = (DATA && DATA.temp) || {};
    const c = (window.WXFeel && WXFeel.label(T.feels, ((DATA && DATA.units) || {}).temp)) || T.comfort;
    setText("comfort", c || "--"); $("comfort").classList.toggle("hidden", !c);
  }
  function render(d) {
    d = applyMockOverrides(d);
    DATA = d;
    tz = (d.station && d.station.tz) || tz;
    h24 = d.station && d.station.time_format === "24";
    const U = d.units || {};
    const T = d.temp || {}, W = d.wind || {}, P = d.pressure || {}, R = d.rain || {}, H = d.humidity || {};
    const F = d.forecast || {}, FN = F.now || {}, FT = F.today || {}, A = d.astro || {}, M = A.moon || {};
    const hasData = isNum(d.obs_time);

    setText("stationName", (d.station && d.station.name) || "Weather Station");
    document.title = ((d.station && d.station.name) || "Weather") + " — " + fx(T.now) + "°";
    body.dataset.theme = pickTheme(d);
    // nixie night shade follows the station sun when known; clock hours are the fallback
    if (NIGHT_FORCE === null && A && typeof A.is_day === "boolean") body.classList.toggle("night", !A.is_day);
    updateStatus();

    // hero
    const heroIcon = FN.icon || (hasData ? (A.is_day === false ? "clear-night" : "clear-day") : "cloudy");
    if ($("heroIcon").dataset.icon !== heroIcon) { $("heroIcon").innerHTML = wicon(heroIcon); $("heroIcon").dataset.icon = heroIcon; }
    setText("heroCond", FN.conditions || (hasData ? "Observed" : "--"));
    paintComfort();
    setText("tempNow", fx(T.now));
    paintBank($("tempBank"), isNum(T.now) ? fx(T.now) : "--");
    const tu = ((U.temp || "°F") + "").replace("°", "") || "F";
    setText("tempUnit", tu);
    fitTemp();
    setArrow("trendArrow", T.trend);
    setText("trendVal", isNum(T.trend) ? signed(T.trend) + "°" : "--");
    setArrow("diffArrow", T.diff24, 0.5);
    setText("diffVal", isNum(T.diff24) ? signed(T.diff24) + "°" : "--");
    setText("feels", isNum(T.feels) ? fx(T.feels) + "°" : "--");
    setText("dewHero", isNum(T.dew) ? fx(T.dew) + "°" : "--");
    setText("humHero", isNum(H.now) ? fi(H.now) + "%" : "--");
    const lo = T.low || {}, hi = T.high || {};
    setText("lowVal", isNum(lo.value) ? fx(lo.value) + "°" : "--");
    setText("highVal", isNum(hi.value) ? fx(hi.value) + "°" : "--");
    setText("lowTime", fmtTime(lo.time));
    setText("highTime", fmtTime(hi.time));
    renderTempRange(T, U);

    // wind
    setText("windDesc", W.description || (W.calm ? "Calm" : "--"));
    setWind(W.speed, W.dir, W.dir_cardinal || (W.calm ? null : W.cardinal), W.cardinal, !!W.calm, U.wind || "mph");
    setHTML("windAvg", isNum(W.avg_today) ? `${fx(W.avg_today)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setHTML("windGust", isNum(W.gust_max) ? `${fx(W.gust_max)}<span class="unit">${esc(U.wind)}</span>` : "--");

    // barometer
    const slpMb = P.slp_mb;
    setText("baroVal", isNum(P.slp) ? fx(P.slp, U.pressure === "inHg" ? 2 : 1) : "--");
    setText("baroUnit", U.pressure || "mb");
    setText("baroTrendText", P.trend_text || "--");
    setArrow("baroArrow", P.trend, 0.3);
    setText("baroTrend", isNum(P.trend) ? `${signed(P.trend)} ${U.pressure}/hr` : "--");
    setText("baroTendency", P.tendency || "--");
    setText("baroLow", P.low && isNum(P.low.value) ? fx(P.low.value) : "--");
    setText("baroHigh", P.high && isNum(P.high.value) ? fx(P.high.value) : "--");
    setText("baroLowT", P.low ? fmtTime(P.low.time) : "");
    setText("baroHighT", P.high ? fmtTime(P.high.time) : "");
    if (isNum(slpMb)) {
      const frac = Math.max(0, Math.min(1, (slpMb - 950) / 100));
      $("baroArc").style.strokeDashoffset = (100 - frac * 100).toFixed(2);
      $("baroMarker").style.transform = `rotate(${(-120 + frac * 240).toFixed(2)}deg)`;
    }
    $("baroMarker").style.opacity = isNum(slpMb) ? "1" : "0";

    // moon & sun
    // Compare a signature, not innerHTML (the browser re-serialises SVG differently, which
    // made every render rewrite the moon and repaint its card).
    const moonSig = `${M.illumination}|${M.waxing}`;
    if ($("moonSvg").dataset.sig !== moonSig) { $("moonSvg").innerHTML = moonArt(M.illumination, M.waxing); $("moonSvg").dataset.sig = moonSig; }
    setText("moonName", M.name || "--");
    setText("moonIllum", isNum(M.illumination) ? M.illumination + "% lit" : "--");
    setText("moonRise", fmtTime(M.rise));
    setText("moonSet", fmtTime(M.set));
    setText("nextNew", fmtDay(M.next_new));
    setText("nextFull", fmtDay(M.next_full));
    setText("sunRise", fmtTime(A.sunrise));
    setText("sunSet", fmtTime(A.sunset));

    // humidity
    setText("humVal", fi(H.now));
    if (isNum(H.now)) $("humArc").style.strokeDashoffset = (100 - Math.max(0, Math.min(100, H.now))).toFixed(1);
    setText("humDesc", humText(H.now, T.dew, U.temp));
    setText("dew", isNum(H.dew) ? fx(H.dew) + "°" : "--");
    const uv = d.solar && d.solar.uv;
    setHTML("uv", isNum(uv) ? `${fx(uv)} <span class="unit">${uvText(uv)}</span>` : "--");
    const rad = d.solar && d.solar.radiation;
    setHTML("solar", isNum(rad) ? `${fi(rad)}<span class="unit">W/m²</span>` : "--");

    // rain
    const pu = U.precip || "in", dec = pu === "mm" ? 1 : 2;
    const scales = pu === "mm" ? { today: 25, yesterday: 25, month: 125, year: 600 } : { today: 1, yesterday: 1, month: 5, year: 25 };
    document.querySelectorAll("#rainBars .rb").forEach((el) => {
      const k = el.dataset.k, v = R[k];
      el.querySelector(".rv").textContent = isNum(v) ? (k === "year" && pu === "in" ? v.toFixed(1) : v.toFixed(dec)) + (pu === "in" ? "\u2033" : "") : "--";
      const pct = isNum(v) ? Math.min(100, (v / Math.max(scales[k], v)) * 100) : 0;
      el.querySelector(".bar i").style.height = pct.toFixed(1) + "%";
    });
    setText("rainText", R.rate_text || "--");
    setText("rainRate", isNum(R.rate) ? `${fx(R.rate, dec)} ${U.rate || "in/hr"}` : "--");

    // forecast now
    setText("fcUntil", String(FN.until || FN.conditions || "--").replace(/\s+/g, " ").trim());
    const fci = FN.icon || "cloudy";
    if ($("fcIcon").dataset.icon !== fci) { $("fcIcon").innerHTML = wicon(fci); $("fcIcon").dataset.icon = fci; }
    setText("fcTemp", isNum(FN.temp) ? fi(FN.temp) + "°" : "--");
    setText("fcLow", isNum(FT.low) ? fi(FT.low) + "°" : "--");
    setText("fcHigh", isNum(FT.high) ? fi(FT.high) + "°" : "--");
    const rainPct = isNum(FT.precip) ? FT.precip : FN.precip;
    setPct("fcRainPill", rainPct, "--");
    setText("fcWind", isNum(FN.wind) ? `${fi(FN.wind)} ${U.wind} ${FN.wind_dir || ""}`.trim() : "--");
    refitFc();
    // tomorrow: forecast.daily starts at tomorrow; skip an entry that is already today/past
    // (stale feed just after midnight) by matching on the local calendar day.
    const DL = Array.isArray(F.daily) ? F.daily : [];
    const tmKey = dayKey(Date.now() / 1000 + 86400);
    const TM = DL.find((x) => x && isNum(x.time) && dayKey(x.time + 3600) === tmKey) || DL.find((x) => x && isNum(x.time) && x.time > Date.now() / 1000) || null;
    $("fcTm").classList.toggle("empty", !TM);
    if (TM) {
      const tmi = String(TM.icon || "cloudy").replace("-night", "-day");
      if ($("fcTmIcon").dataset.icon !== tmi) { $("fcTmIcon").innerHTML = wicon(tmi); $("fcTmIcon").dataset.icon = tmi; }
      setText("fcTmDay", "Tomorrow \u00b7 " + new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(new Date((TM.time + 3600) * 1000)));
      setText("fcTmCond", TM.conditions || "--");
      setText("fcTmHigh", isNum(TM.high) ? fi(TM.high) + "°" : "--");
      setText("fcTmLow", isNum(TM.low) ? fi(TM.low) + "°" : "--");
      setPct("fcTmRain", TM.precip, "");
    } else {
      setText("fcTmDay", "Tomorrow"); setText("fcTmCond", "Forecast unavailable");
      setText("fcTmHigh", "--"); setText("fcTmLow", "--"); setPct("fcTmRain", null, "");
      $("fcTmIcon").innerHTML = ""; $("fcTmIcon").dataset.icon = "";
    }

    renderHourly(F.hourly || []);
    renderLightning(d.lightning || {}, U);
    updateStrikeBadge();
    if (openPanel) showPanel(openPanel, true);
  }

  /* Keep the wind compass square inside its shell so the speed bar never overlaps it. */
  function fitWindDial() {
    const shell = document.querySelector(".dial-shell");
    const svg = $("compass");
    const main = document.querySelector(".wind-main");
    if (!shell || !svg || !main) return;
    // Clear any previous inline height so the grid can assign the true main-row size.
    shell.style.height = "";
    shell.style.maxHeight = "100%";
    const mh = Math.max(0, main.clientHeight);
    const mw = Math.max(0, shell.clientWidth);
    // Fill the dial column: largest square that fits the main row.
    const s = Math.max(48, Math.floor(Math.min(mw, mh)));
    const key = s + "x" + mh + "x" + mw;
    if (svg.dataset.fit === key) return;
    svg.dataset.fit = key;
    svg.style.width = s + "px";
    svg.style.height = s + "px";
  }
  window.addEventListener("resize", () => { clearTimeout(window._wxWindFit); window._wxWindFit = setTimeout(fitWindDial, 60); });
  if (window.ResizeObserver) {
    const ro = new ResizeObserver(() => fitWindDial());
    const main = document.querySelector(".wind-main"); if (main) ro.observe(main);
    const card = document.querySelector(".card.wind"); if (card) ro.observe(card);
  }

  /* wind: shared by full renders and 3-second rapid_wind pushes */
  function tweenWind(to) {
    cancelAnimationFrame(windAnim);
    if (!isNum(to)) { windShown = null; setText("windNow", "--"); return; }
    const from = isNum(windShown) ? windShown : to;
    const t0 = performance.now(), dur = 280;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      windShown = from + (to - from) * e;
      setText("windNow", windShown.toFixed(1));
      if (k < 1) windAnim = requestAnimationFrame(step);
      else windShown = to;
    };
    if (from === to || body.classList.contains("lite")) { windShown = to; setText("windNow", fx(to)); }
    else windAnim = requestAnimationFrame(step);
  }
  function setWind(speed, dir, dirCard, fallbackTxt, calm, unit) {
    tweenWind(speed);
    setText("windNowUnit", unit || "mph");
    setHTML("windDir", isNum(dir) ? `${esc(dirCard || "--")}<span class="unit">${fi(dir)}°</span>` : esc(fallbackTxt || "--"));
    if (isNum(dir)) {
      if (needleAngle === null) needleAngle = dir;
      else { const delta = ((dir - needleAngle) % 360 + 540) % 360 - 180; needleAngle += delta; }
      $("needle").style.transform = `rotate(${needleAngle}deg)`;
    }
    $("needle").classList.toggle("calm", !!calm);
    $("needle").style.opacity = isNum(dir) ? "" : "0";
    // 1.5.6 wind bar: fill + downward arrow on a fixed 0–40 scale (mph-ish; still fine for km/h as relative)
    const maxS = 40;
    const pct = isNum(speed) ? Math.max(0, Math.min(100, (speed / maxS) * 100)) : 0;
    const fill = $("windBarFill"), ptr = $("windBarPtr");
    if (fill) fill.style.width = pct.toFixed(2) + "%";
    if (ptr) { ptr.style.left = pct.toFixed(2) + "%"; ptr.style.opacity = isNum(speed) ? "1" : "0"; }
    fitWindDial();
  }
  const CARD16 = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  function onRapidWind(w) {
    if (!DATA || !isNum(w.speed)) return;
    const W = DATA.wind = DATA.wind || {};
    const calm = w.calm != null ? !!w.calm : w.speed < 1;
    const dir = isNum(w.dir) ? w.dir : W.dir;
    const card = w.dir_cardinal || (isNum(dir) ? CARD16[Math.round(dir / 22.5) % 16] : null);
    Object.assign(W, { speed: w.speed, dir: dir, calm: calm, dir_cardinal: card, cardinal: calm ? "Calm" : card });
    setWind(w.speed, dir, card, W.cardinal, calm, (DATA.units && DATA.units.wind) || w.unit);
    const c = document.querySelector(".card.wind");
    c.classList.remove("tick"); void c.offsetWidth; c.classList.add("tick");
  }

  function humText(rh, dew, unit) {
    if (!isNum(rh)) return "--";
    let dp = dew;
    if (isNum(dp) && unit === "°C") dp = dp * 9 / 5 + 32;
    if (isNum(dp)) {
      if (dp < 50) return "Dry";
      if (dp < 60) return "Comfortable";
      if (dp < 65) return "Sticky";
      if (dp < 70) return "Humid";
      return "Oppressive";
    }
    return rh < 30 ? "Dry" : rh < 60 ? "Comfortable" : "Humid";
  }
  function uvText(uv) {
    return uv < 3 ? "Low" : uv < 6 ? "Moderate" : uv < 8 ? "High" : uv < 11 ? "Very high" : "Extreme";
  }

  function smoothPath(pts) {
    if (pts.length < 2) return "";
    let d = `M${pts[0][0]} ${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)} ${c2x.toFixed(1)} ${c2y.toFixed(1)} ${p2[0]} ${p2[1].toFixed(1)}`;
    }
    return d;
  }

  function renderHourly(hours) {
    const list = hours.slice(0, 12);
    if (!list.length) { setHTML("hours", `<div class="label" style="grid-column:1/-1;grid-row:1/-1;align-self:center;text-align:center">Hourly forecast unavailable</div>`); return; }
    const temps = list.map((h) => h.temp).filter(isNum);
    const mn = Math.min.apply(null, temps), mx = Math.max.apply(null, temps), span = Math.max(1, mx - mn);
    const n = list.length;
    const pts = list.map((h, i) => [((i + 0.5) * 1200) / 12, isNum(h.temp) ? 12 + (1 - (h.temp - mn) / span) * 76 : 50]);
    const line = smoothPath(pts);
    const area = line + ` L${pts[n - 1][0]} 100 L${pts[0][0]} 100 Z`;
    let html = `<svg class="spark" viewBox="0 0 1200 100" preserveAspectRatio="none" aria-hidden="true"><defs>
      <linearGradient id="sparkG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff9a4a"/><stop offset="1" stop-color="#7cc4ff"/></linearGradient>
      <linearGradient id="sparkA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="rgba(255,209,102,.28)"/><stop offset="1" stop-color="rgba(124,196,255,0)"/></linearGradient></defs>
      <path class="area" d="${area}"/><path class="line" d="${line}"/></svg>`;
    list.forEach((h, i) => {
      const p = isNum(h.precip) ? h.precip : null;
      const col = i + 1;
      html += `<div class="hcell"><div class="h${i === 0 ? " now" : ""}" style="grid-column:${col}">${esc(fmtHour(h.time))}</div>
        <div class="i" style="grid-column:${col}">${wicon(h.icon)}</div>
        <div class="tt" style="grid-column:${col}">${fi(h.temp)}°</div>
        <div class="p${!p ? " zero" : ""}" style="grid-column:${col}">${p === null ? "" : fi(p) + "%"}</div></div>`;
    });
    const sig = JSON.stringify(list.map((h) => [h.time, h.temp, h.icon, h.precip]));
    const el = $("hours");
    if (el.dataset.sig !== sig) {
      el.style.gridTemplateColumns = `repeat(${Math.max(list.length, 1)}, 1fr)`;
      el.innerHTML = html; el.dataset.sig = sig;
    }
  }

  function lightningActive(L) {
    return isNum(L.last_epoch) && Date.now() / 1000 - L.last_epoch < 1800;
  }
  function strikeWhen(ts) {
    if (!isNum(ts)) return "";
    if (dayKey(ts) === dayKey(Date.now() / 1000)) return "at " + fmtTime(ts);
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000)) + ", " + fmtTime(ts);
  }

  function flashLightning() {
    flashCard($("ltCard"));
    const b = $("strikeBadge");
    b.classList.remove("zap"); void b.offsetWidth; b.classList.add("zap");
  }
  function onStrikeCore(e) {
    if (!DATA || !isNum(e.epoch)) return;
    const L = DATA.lightning = DATA.lightning && typeof DATA.lightning === "object" ? DATA.lightning : {};
    if (!isNum(L.last_epoch) || e.epoch >= L.last_epoch) { L.last_epoch = e.epoch; L.last_distance = e.distance; }
    ["count_1h", "count_3h", "count_today", "count_month", "count_30m"].forEach((k) => { L[k] = (isNum(L[k]) ? L[k] : 0) + 1; });
    if (isNum(e.distance)) L.nearest_30m = isNum(L.nearest_30m) ? Math.min(L.nearest_30m, e.distance) : e.distance;
    if (Array.isArray(L.hourly) && L.hourly.length) {
      const hr = Math.floor(e.epoch / 3600) * 3600;
      let last = L.hourly[L.hourly.length - 1];
      for (let g = 0; last && isNum(last.time) && last.time < hr && g < 48; g++) { L.hourly.shift(); last = { time: last.time + 3600, count: 0, min_distance: null }; L.hourly.push(last); }
      if (last && last.time === hr) last.count = (isNum(last.count) ? last.count : 0) + 1;
    }
    renderLightning(L, DATA.units || {});
    updateStrikeBadge();
    flashLightning();
  }

    /* 1.5.5: the Lightning card is always on screen. Strike data is cleaned before drawing, a draw that
     fails falls back to the last good values (never a blank or missing card), and missing values show "—".
     The card's tap/strike highlight uses the class "lt-flash" ("flash" is the full-screen sky-flash
     layer in some themes; putting that class on the card hid it after the first live strike). */
  let ltLastGood = null;
  const fiD = (v) => (isNum(v) ? fi(v) : "\u2014");
  function cleanLightning(L) {
    const src = L && typeof L === "object" ? L : {}, n = (v) => (isNum(v) ? v : null), out = Object.assign({}, src);
    ["last_epoch", "last_distance", "count_1h", "count_3h", "count_today", "count_month", "count_30m", "nearest_30m"].forEach((k) => { out[k] = n(src[k]); });
    out.hourly = Array.isArray(src.hourly) ? src.hourly.map((b) => (b && typeof b === "object"
      ? { time: n(b.time), count: isNum(b.count) ? b.count : 0, min_distance: n(b.min_distance) } : { time: null, count: 0, min_distance: null })) : null;
    return out;
  }
  function renderLightning(L, U) {
    const card = $("ltCard"); if (!card) return;
    card.classList.remove("flash", "hidden");
    try { const c = cleanLightning(L); renderLightningCore(c, U || {}); ltLastGood = c; }
    catch (err) {
      try { console.info("wxdash: lightning draw failed, keeping the last good values", err); } catch (_) {}
      try { if (ltLastGood) renderLightningCore(ltLastGood, U || {}); } catch (_) {}
    }
  }
  function flashCard(c) {
    if (!c) return;
    c.classList.remove("flash", "lt-flash"); void c.offsetWidth; c.classList.add("lt-flash");
    clearTimeout(c._ltf); c._ltf = setTimeout(() => c.classList.remove("lt-flash"), 900);
  }
  function onStrike(e) {
    try { onStrikeCore(e && typeof e === "object" ? e : {}); }
    catch (err) {
      try { console.info("wxdash: strike update failed", err); } catch (_) {}
      if (DATA) renderLightning(DATA.lightning, DATA.units || {});
    }
  }
  function renderLightningCore(L, U) {
    const dist = U.distance || "mi";
    const has = isNum(L.last_epoch);
    const active = lightningActive(L);
    $("ltCard").classList.toggle("active", active);
    const near = isNum(L.nearest_30m) ? L.nearest_30m : L.last_distance;
    const noData = !has && !isNum(L.count_1h) && !isNum(L.count_3h) && !isNum(L.count_today);
    setText("ltStatusText", active ? (isNum(near) ? `Active \u2014 strikes within ${fiD(near)} ${dist}` : "Active") : noData ? "No data" : "No strikes nearby");
    setHTML("ltDist", has && isNum(L.last_distance) ? `${fiD(L.last_distance)}<span class="unit">${esc(dist)}</span>` : (has || noData ? "\u2014" : "None"));
    setText("ltAgo", has ? ago(L.last_epoch) : noData ? "\u2014" : "No strikes detected");
    setText("ltWhen", has ? strikeWhen(L.last_epoch) : "\u00a0");
    setText("ltC1", fiD(L.count_1h));
    setText("ltC3", fiD(L.count_3h));
    setText("ltCT", fiD(L.count_today));
    setText("ltCM", fiD(L.count_month));
    ["ltC1", "ltC3", "ltCT", "ltCM"].forEach((id) => { const v = $(id).textContent; $(id).classList.toggle("zero", v === "0"); });

    const hrs = Array.isArray(L.hourly) ? L.hourly : null;
    const el = $("ltBars");
    if (!hrs || !hrs.length) {
      setHTML("ltBars", `<div class="lt-none">Hourly history unavailable</div>`);
      setText("ltPeak", "");
      $("ltAxis").classList.add("hidden");
      el.dataset.sig = "";
      return;
    }
    $("ltAxis").classList.remove("hidden");
    const counts = hrs.map((b) => (isNum(b.count) ? b.count : 0));
    const mx = Math.max.apply(null, counts);
    const total = counts.reduce((a, b) => a + b, 0);
    setText("ltPeak", total ? `${total} in ${hrs.length}h` : `None in ${hrs.length}h`);
    $("ltPeak").title = total ? `Peak ${mx} strikes in one hour` : "";
    const n = hrs.length;
    const sig = JSON.stringify([counts, active]);
    if (el.dataset.sig === sig) return;
    let html = "";
    hrs.forEach((b, i) => {
      const c = counts[i];
      const h = c ? Math.max(10, Math.sqrt(c / Math.max(1, mx)) * 100) : 0;
      const cls = c ? (i === n - 1 && active ? "on now" : "on") : "";
      html += `<i class="${cls}" style="height:${h.toFixed(1)}%" title="${esc(fmtHour(b.time))}: ${c}"></i>`;
    });
    el.style.gridTemplateColumns = `repeat(${n}, 1fr)`;
    el.innerHTML = html;
    el.dataset.sig = sig;
    const axis = $("ltAxis").children;
    axis[0].textContent = n + "h ago";
    axis[1].textContent = Math.round(n / 2) + "h";
  }

  /* ---------------- status / errors ---------------- */
  function updateStatus() {
    const d = DATA;
    const pill = $("statusPill");
    let cls = "loading", txt = "Connecting…";
    if (serverDown) {
      cls = "error"; txt = "Dashboard server unreachable" + (lastFetchOk ? " · showing data from " + ago(lastFetchOk / 1000) : "");
    } else if (d) {
      if (d.mock) { cls = "mock"; txt = "Demo data"; }
      else if (d.status === "ok") { cls = "ok"; txt = "Live · updated " + ago(d.obs_time); }
      else if (d.status === "stale") { cls = "stale"; txt = "Stale · last obs " + ago(d.obs_time) + (d.error ? " · " + d.error : ""); }
      else if (d.status === "loading") { cls = "loading"; txt = d.error || "Loading…"; }
      else { cls = "error"; txt = "Offline · " + (d.error || "no data"); }
    }
    if (pill) {
      pill.className = "status " + cls;
      setText("statusText", txt);
    }
    const noData = !d || !isNum(d.obs_time);
    const showErr = noData && (serverDown || (d && (d.status === "error")));
    $("errorState").classList.toggle("hidden", !showErr);
    body.classList.toggle("has-error", cls === "error" || cls === "stale");
    if (showErr) setText("errorMsg", serverDown ? "The wxdash server on this Pi is not responding." : (d && d.error) || "Unknown error");
  }

  function updateStrikeBadge() {
    const L = (DATA && DATA.lightning) || {};
    const b = $("strikeBadge");
    const recent = lightningActive(L);
    b.classList.toggle("has", !!recent);
    if (DATA) renderLightningTick();
    const txt = $("strikeText");
    if (txt) setText("strikeText", recent
      ? `${fi(L.last_distance)} ${(DATA.units && DATA.units.distance) || "mi"} · ${ago(L.last_epoch)}`
      : "No strikes");
  }

  function renderLightningTick() {
    const L = (DATA && DATA.lightning) || {};
    const active = lightningActive(L);
    if ($("ltCard").classList.contains("active") !== active) renderLightning(L, DATA.units || {});
    else if (isNum(L.last_epoch)) { setText("ltAgo", ago(L.last_epoch)); setText("ltWhen", strikeWhen(L.last_epoch)); }
  }

  /* live indicator: green = WebSocket feed connected and pushing to this page */
  function updateLive() {
    const el = $("livePill");
    let cls = "off", txt = "Polling", title = "Live stream not connected; refreshing every 15 s";
    if (sseOpen && (wsState === "connected" || demoLive)) { cls = "on"; txt = "Live"; title = demoLive ? "Simulated live feed (demo)" : "WeatherFlow live feed connected"; }
    else if (sseOpen && wsState === "connecting") { cls = "wait"; txt = "Reconnecting"; title = "WeatherFlow live feed reconnecting; using REST updates"; }
    el.className = "ind live " + cls;
    el.title = title;
    setText("liveText", txt);
  }

  /* ---------------- theme (Classic / Industrial / Desert / Arctic; saved on the Pi via POST /api/settings) ---------------- */
  const THEME = "nixie";
  const THEMES = [["classic", "Classic"], ["industrial", "Industrial"], ["desert", "Desert"], ["arctic", "Arctic"], ["redwoods", "Redwoods"], ["nixie", "Nixie"]];
  let themeMsg = "";
  function themeHTML() {
    return `<div class="theme-pick"><div class="label">Theme</div><div class="theme-btns">` +
      THEMES.map(([k, n]) => `<button data-act="theme" data-theme="${k}" class="${k === THEME ? "on" : ""}" aria-pressed="${k === THEME}">` +
        `<span class="tn">${n}</span><span class="cur">${k === THEME ? "\u2713 Current" : "Tap to switch"}</span></button>`).join("") +
      `</div>${themeMsg ? `<div class="theme-msg">${esc(themeMsg)}</div>` : ""}</div>`;
  }
  function urlWithoutTheme() { const u = new URL(location.href); u.searchParams.delete("theme"); u.searchParams.delete("panel"); return u.toString(); }
  async function setTheme(t) {
    if (!t || t === THEME) { closePanel(); return; }
    themeMsg = "Switching\u2026"; showPanel("menu", true);
    try {
      const r = await fetch("/api/settings", { method: "POST", cache: "no-store",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({ theme: t }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      location.replace(urlWithoutTheme());   // the server now serves the new theme at "/"
    } catch (e) { themeMsg = "Couldn't switch theme: " + (e.message || e); showPanel("menu", true); }
  }
  // Another screen switched the theme: follow it (not for ?theme= previews).
  function onSettings(s) { if (s && s.feel && window.WXFeel) WXFeel.sync(s.feel); if (s && s.theme && s.theme !== THEME && !params.get("theme")) location.replace(urlWithoutTheme()); }
  fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()).then((s) => {
    if (s && s.saved === false) themeMsg = "Theme not saved on the Pi (run install.sh once); it resets when wxdash restarts.";
  }).catch(() => {});

  /* ---------------- overlays ---------------- */
  function showPanel(name, refresh) {
    const d = DATA || {};
    const U = d.units || {};
    let html = "";
    if (name === "sager") {
      const S = d.sager, P = d.pressure || {};
      html = `<h3>Sager-style outlook</h3><div class="lead">Barometric forecast for the next 12–24 hours</div>
        <div class="big">${esc(S ? S.outlook : "Not enough pressure history yet")}</div>
        <div class="grid3"><div><div class="label">Sea-level pressure</div><div class="v">${fx(P.slp)} <small>${esc(U.pressure)}</small></div></div>
        <div><div class="label">3-hour trend</div><div class="v">${signed(P.trend)} <small>${esc(U.pressure)}/hr</small></div></div>
        <div><div class="label">Tendency</div><div class="v" style="font-size:calc(var(--u)*1.3);white-space:normal">${esc(P.trend_text || "--")}</div></div></div>
        <div class="note">Computed on this Pi with the Zambretti barometer method (pressure, 3-hour trend and season).${P.tendency ? " Barometer tendency: " + esc(P.tendency) + "." : ""}</div>`;
    } else if (name === "menu") {
      const s = d.station || {};
      html = `<h3>${esc(s.name || "Weather Station")}</h3><div class="lead">Station ${esc(s.id || "--")} · Tempest ${esc(s.device || "--")} · ${isNum(s.lat) ? s.lat.toFixed(4) + ", " + s.lon.toFixed(4) : ""}</div>
        <div class="grid3"><div><div class="label">Data</div><div class="v" style="font-size:calc(var(--u)*1.4)">${esc(d.mock ? "Demo" : d.status || "--")}</div></div>
        <div><div class="label">Last observation</div><div class="v" style="font-size:calc(var(--u)*1.4)">${esc(fmtTime(d.obs_time))}</div></div>
        <div><div class="label">Version</div><div class="v" style="font-size:calc(var(--u)*1.4)">wxdash ${esc(d.version || "")}</div></div></div>
        ${d.error ? `<div class="note">${esc(d.error)}</div>` : ""}
        ${themeHTML()}
        <div class="rowbtn"><button data-act="refresh">Refresh now</button><button data-act="reload">Reload page</button>
        <button data-act="glass">${body.classList.contains("glass") ? "Glass blur: on" : "Glass blur: off (smooth)"}</button>
        <button data-act="lite">${body.classList.contains("lite") ? "Lite mode: on" : "Lite mode: off"}</button>
        ${window.WXFeel ? WXFeel.menuButton() : ""}<button data-act="cursor">${body.classList.contains("show-cursor") ? "Hide cursor" : "Show cursor"}</button></div>`;
    } else if (name === "feel" && window.WXFeel) {
      html = WXFeel.panelHTML(d);
    }
    if (!html) return;
    if (refresh && $("overlayBody").dataset.panel === name && $("overlayBody").innerHTML === html) return;
    $("overlayBody").innerHTML = html;
    $("overlayBody").dataset.panel = name;
    $("overlayBody").parentNode.classList.toggle("sheet-feel", name === "feel");
    $("overlay").classList.remove("hidden");
    openPanel = name;
    if (!refresh) { clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000); }
  }
  function closePanel() { $("overlay").classList.add("hidden"); openPanel = null; clearTimeout(overlayTimer); }

  document.querySelectorAll("[data-panel]").forEach((b) => b.addEventListener("click", () => showPanel(b.dataset.panel)));
  // The header badge just draws attention to the permanent Lightning card.
  $("strikeBadge").addEventListener("click", () => {
    flashCard($("ltCard"));
  });
  if (window.WXFeel) WXFeel.init({ show: (n) => showPanel(n),
    changed: () => { paintComfort(); if (openPanel === "feel" || openPanel === "menu") showPanel(openPanel, true); } });
  $("overlayClose").addEventListener("click", closePanel);
  $("overlay").addEventListener("click", (e) => { if (e.target === $("overlay")) closePanel(); });
  $("overlayBody").addEventListener("click", (e) => {
    const btn = e.target && e.target.closest ? e.target.closest("[data-act]") : null;
    const act = btn && btn.dataset.act;
    if (act && act.indexOf("feel-") === 0 && window.WXFeel) {   // Feels-like labels editor: keep the sheet open while tapping
      clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000);
      WXFeel.act(act, btn); return;
    }
    if (act === "theme") setTheme(btn.dataset.theme);
    else if (act === "refresh") { load(); closePanel(); }
    else if (act === "reload") location.reload();
    else if (act === "glass") { body.classList.toggle("glass"); localStorage.setItem("wxdash-glass", body.classList.contains("glass") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "lite") { body.classList.toggle("lite"); localStorage.setItem("wxdash-lite", body.classList.contains("lite") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "cursor") { body.classList.toggle("show-cursor"); localStorage.setItem("wxdash-cursor", body.classList.contains("show-cursor") ? "1" : "0"); showPanel("menu", true); }
  });

  /* ---------------- polling ---------------- */
  function dataQuery() {
    const q = new URLSearchParams();
    if (MOCK) q.set("mock", "1");
    if (params.get("lightning")) q.set("lightning", params.get("lightning"));
    const qs = q.toString();
    return qs ? "?" + qs : "";
  }
  function startStream() {
    if (!window.EventSource || params.get("stream") === "0") return;
    try { sse = new EventSource("/api/stream" + dataQuery()); } catch (e) { return; }
    const ok = () => { if (!sseOpen) { sseOpen = true; updateLive(); } };
    const parse = (ev, fn) => { try { fn(JSON.parse(ev.data)); ok(); } catch (e) { /* ignore bad event */ } };
    sse.addEventListener("open", ok);
    sse.addEventListener("error", () => { sseOpen = false; updateLive(); });  // EventSource auto-reconnects
    sse.addEventListener("data", (ev) => parse(ev, (d) => { serverDown = false; lastFetchOk = Date.now(); render(d); }));
    sse.addEventListener("wind", (ev) => parse(ev, onRapidWind));
    sse.addEventListener("strike", (ev) => parse(ev, onStrike));
    sse.addEventListener("settings", (ev) => parse(ev, onSettings));
    sse.addEventListener("live", (ev) => parse(ev, (l) => { wsState = l.ws || "off"; demoLive = !!l.demo; updateLive(); }));
  }

  async function load() {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch("/api/data" + dataQuery(), { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const d = await r.json();
      serverDown = false;
      lastFetchOk = Date.now();
      if (d.live) { wsState = d.live.ws || "off"; demoLive = !!d.live.demo; }
      render(d);
      updateLive();
    } catch (e) {
      serverDown = true;
      updateStatus();
    }
  }

  /* ---------------- night dimming (station clock 8 PM - 6 AM; ?mock=1&night=0|1) ---------------- */
  const NIGHT_FORCE = MOCK && params.has("night") ? params.get("night") === "1" : null;
  function localHour() {
    try { return +new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hourCycle: "h23" }).format(new Date()) % 24; }
    catch (e) { return new Date().getHours(); }
  }
  function isNightHour() { if (NIGHT_FORCE !== null) return NIGHT_FORCE; const h = localHour(); return h >= 20 || h < 6; }
  function updateNight() {
    const on = isNightHour();
    body.classList.toggle("night", on);
    body.classList.toggle("night-sky", on);
  }
  updateNight();
  setInterval(updateNight, 60000);
  function clockLoop() { tickClock(); setTimeout(clockLoop, 1000 - (Date.now() % 1000) + 15); }
  clockLoop();
  fitWindDial();
  setInterval(() => { updateStatus(); if (DATA) updateStrikeBadge(); }, 5000);
  load().then(() => { const p = params.get("panel"); if (p) showPanel(p); startStream(); });
  // Polling is the fallback; while the live stream is healthy it only runs once a minute.
  setInterval(() => { if (!sseOpen || Date.now() - lastFetchOk > 60000) load(); }, POLL_MS);
  // Self-update: when the server reports a different version than the one this page
  // loaded with, reload so the kiosk picks up the new UI without relaunching Chromium.
  let loadedVersion = null;
  async function checkVersion() {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 8000);
      const r = await fetch("/api/health", { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) return;
      const h = await r.json();
      if (!h || !h.ok || typeof h.version !== "string" || !h.version) return;
      if (loadedVersion === null) loadedVersion = h.version;
      else if (h.version !== loadedVersion) location.reload();
      else if (h.theme && h.theme !== THEME) onSettings({ theme: h.theme });   // backup if the SSE event was missed
    } catch (e) { /* server restarting or down; try again next minute */ }
  }
  checkVersion();
  setInterval(checkVersion, 60000);
  // Recover from long-running kiosk memory growth: reload once a day at ~3:30 AM.
  setInterval(() => { const h = new Date().getHours(), m = new Date().getMinutes(); if (h === 3 && m === 30) location.reload(); }, 60000);
})();
