/* wxdash front-end - ARCTIC theme (fourth theme, added in 1.4.0). Vanilla JS, no dependencies, works offline.
   Data plumbing (polling, live stream, menu, theme picker, night mode) follows the Desert/Industrial
   front ends; every gauge is new: aurora ice-crystal temperature arc with a snowflake marker,
   snowflake compass rose + icicle pointer, blowing-snow speed bar with a rolling snowball,
   ice-core barometer, frosted rain jars with floating ice cubes, frost-to-mist humidity,
   snow-glare UV crystals, moon over snowy peaks, snowy-ridge hourly line, ice-block strike chart.
   Animation layer: aurora ribbons, parallax snowfall, twinkling stars, shooting stars, wind-driven
   blowing snow, glints, storm flash. All continuous motion is CSS transform/opacity on HTML layers
   (compositor only); it pauses when the page is hidden and honours prefers-reduced-motion / Lite. */
(function () {
  "use strict";
  const POLL_MS = 15000;
  const params = new URLSearchParams(location.search);
  const MOCK = params.get("mock") === "1";
  if (MOCK) window.__wxstrike = (e) => onStrike(e);   // mock-only test hook: deliver a live evt_strike as if it came over SSE
  const $ = (id) => document.getElementById(id);
  const body = document.body;
  const SVGNS = "http://www.w3.org/2000/svg";
  let DATA = null, lastFetchOk = 0, serverDown = false;
  let tz = "America/Los_Angeles", h24 = false;
  let needleAngle = null, overlayTimer = null, openPanel = null;
  let sse = null, sseOpen = false, wsState = "off", demoLive = false;
  let windShown = null, windAnim = 0;

  if (params.get("lite") === "1" || localStorage.getItem("wxdash-lite") === "1") body.classList.add("lite");
  if (params.get("cursor") === "1" || localStorage.getItem("wxdash-cursor") === "1") body.classList.add("show-cursor");

  /* ---------------- mock-only clock override: ?mock=1&mock_time=13:30 ----------------
     Shifts the clock, night mode and the demo data's timestamps/day-night icons so a
     daytime preview can be rendered at any hour. Never active without mock=1. */
  const MOCK_TIME = MOCK && /^\d{1,2}:\d{2}$/.test(params.get("mock_time") || "") ? params.get("mock_time") : null;
  let OFFSET = 0;
  function computeOffset() {
    if (!MOCK_TIME) return;
    const [th, tm] = MOCK_TIME.split(":").map(Number);
    const p = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "numeric", second: "numeric", hourCycle: "h23" }).formatToParts(new Date());
    const g = (t) => +p.find((x) => x.type === t).value;
    OFFSET = ((th * 60 + tm) - ((g("hour") % 24) * 60 + g("minute"))) * 60000 - g("second") * 1000;
  }
  computeOffset();
  const nowMs = () => Date.now() + OFFSET;
  const nowS = () => nowMs() / 1000;

  /* ---------------- formatting ---------------- */
  const isNum = (v) => typeof v === "number" && isFinite(v);
  const fx = (v, d = 1) => (isNum(v) ? v.toFixed(d) : "--");
  const fi = (v) => (isNum(v) ? Math.round(v).toString() : "--");
  function signed(v, d = 1) { if (!isNum(v)) return "--"; const s = Math.abs(v).toFixed(d); return (v > 0 ? "+" : v < 0 ? "\u2212" : "") + s; }
  function fmtTime(ts, opts) {
    if (!isNum(ts)) return "--";
    return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: tz, hour: "numeric", minute: "2-digit", hour12: !h24 }, opts || {})).format(new Date(ts * 1000));
  }
  function fmtHour(ts) {
    if (!isNum(ts)) return "--";
    if (h24) return fmtTime(ts, { minute: "2-digit" });
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hour12: true }).format(new Date(ts * 1000)).replace(" ", "\u2009");
  }
  function dayKey(ts) { return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(ts * 1000)); }
  function fmtDay(ts) {
    if (!isNum(ts)) return "--";
    const now = nowS();
    if (dayKey(ts) === dayKey(now)) return "Today";
    if (dayKey(ts) === dayKey(now + 86400)) return "Tomorrow";
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000));
  }
  function ago(ts) {
    if (!isNum(ts)) return "--";
    const s = Math.max(0, nowS() - ts);
    if (s < 90) return Math.round(s) + "s ago";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " hr ago";
    return Math.round(s / 86400) + " days ago";
  }
  function setText(id, txt) { const el = $(id); if (el && el.textContent !== txt) el.textContent = txt; }
  function setHTML(id, html) { const el = $(id); if (el && el.innerHTML !== html) el.innerHTML = html; }
  function arrowFor(v, eps) { eps = eps || 0.05; if (!isNum(v)) return ["", ""]; if (v > eps) return ["\u25B2", "up"]; if (v < -eps) return ["\u25BC", "down"]; return ["\u25B6", "flat"]; }
  function setArrow(id, v, eps) { const [ch, cls] = arrowFor(v, eps); const el = $(id); el.textContent = ch; el.setAttribute("class", "arrow " + cls); }
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  /* 1.5.6: precipitation chance is drawn with an inline SVG raindrop, never the U+1F4A7 emoji
     (the Pi has no emoji font, so the emoji showed as an empty box) */
  const DROP_D = "M6 .6C6 .6 .9 6.9 .9 10.4a5.1 5.1 0 0 0 10.2 0C11.1 6.9 6 .6 6 .6Z";
  const DROP_SVG = `<svg class="drop-ic" viewBox="0 0 12 16" aria-hidden="true" focusable="false"><path d="${DROP_D}"/></svg>`;
  function setPct(id, pct, empty) {   // "<drop> 70%" chip / row; `empty` text when there is no value
    const el = $(id); if (!el) return;
    const key = isNum(pct) ? "p" + fi(pct) : "e" + empty;
    if (el.dataset.pct === key) return; el.dataset.pct = key;
    if (isNum(pct)) el.innerHTML = `${DROP_SVG}<span class="pct">${fi(pct)}%</span>`; else el.textContent = empty;
  }
  function dropLabel(x, y, fs, p) {   // SVG chart label: a drawn drop + "60%", centred on x (0% has no drop)
    if (!p) return `<text class="dp zero" x="${f1(x)}" y="${f1(y)}" font-size="${f1(fs)}">0%</text>`;
    const t = fi(p) + "%", tw = t.length * fs * 0.5, dw = fs * 0.6, gap = fs * 0.1, x0 = x - (dw + gap + tw) / 2;
    return `<path class="dp-drop" d="${DROP_D}" transform="translate(${f1(x0)} ${f1(y - fs * 0.76)}) scale(${(fs * 0.8 / 16).toFixed(3)})"/>` +
      `<text class="dp" x="${f1(x0 + dw + gap)}" y="${f1(y)}" font-size="${f1(fs)}" style="text-anchor:start">${t}</text>`;
  }
  const clamp01 = (k) => Math.max(0, Math.min(1, k));
  const f1 = (n) => n.toFixed(1);

  /* ---------------- weather icons (arctic palette: white sun with coral glow, snow-white clouds) ---------------- */
  document.body.insertAdjacentHTML("afterbegin", `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
    <radialGradient id="gSunGlow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffb8a0" stop-opacity=".9"/><stop offset=".55" stop-color="#ff9f86" stop-opacity=".32"/><stop offset="1" stop-color="#ff9f86" stop-opacity="0"/></radialGradient>
    <linearGradient id="gCloud" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#b9d2ea"/></linearGradient>
    <linearGradient id="gCloudD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#94a9c6"/><stop offset="1" stop-color="#4b6088"/></linearGradient>
    <linearGradient id="gMoonI" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#c9def2"/></linearGradient>
    <radialGradient id="gMoonLit" cx=".45" cy=".4" r=".65"><stop offset="0" stop-color="#ffffff"/><stop offset=".7" stop-color="#eaf3fb"/><stop offset="1" stop-color="#c3d6ea"/></radialGradient>
    <radialGradient id="gMoonDark" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#2a3a5e"/><stop offset="1" stop-color="#121d36"/></radialGradient>
    <radialGradient id="gHalo" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff" stop-opacity=".7"/><stop offset=".45" stop-color="#fff" stop-opacity=".2"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
  </defs></svg>`);
  const CLOUD = "M18 48h29a9.5 9.5 0 0 0 .8-19 13.5 13.5 0 0 0-25.8-3.4A10.5 10.5 0 0 0 18 48z";
  const SUN_BODY = `<circle cx="60" cy="60" r="36" fill="url(#gSunGlow)"/><circle class="sun-core" cx="60" cy="60" r="19" fill="#fff6f0" stroke="#ff9f86" stroke-width="3"/>` +
    `<g stroke="#ffc4ae" stroke-width="5" stroke-linecap="round"><line x1="60" y1="20" x2="60" y2="10"/><line x1="60" y1="110" x2="60" y2="100"/>` +
    `<line x1="20" y1="60" x2="10" y2="60"/><line x1="110" y1="60" x2="100" y2="60"/><line x1="32" y1="32" x2="25" y2="25"/><line x1="88" y1="88" x2="95" y2="95"/>` +
    `<line x1="88" y1="32" x2="95" y2="25"/><line x1="32" y1="88" x2="25" y2="95"/></g>`;
  const sunI = (x, y, s) => `<svg x="${x}" y="${y}" width="${s}" height="${s}" viewBox="0 0 120 120" overflow="visible">${SUN_BODY}</svg>`;
  const moonI = (tx, ty, s) => `<g transform="translate(${tx} ${ty}) scale(${s})"><path d="M38 10a22 22 0 1 0 17 34A18 18 0 0 1 38 10z" fill="url(#gMoonI)"/></g>`;
  const cloudI = (tx, ty, s, dark) => `<path transform="translate(${tx} ${ty}) scale(${s})" d="${CLOUD}" fill="url(#${dark ? "gCloudD" : "gCloud"})"/>`;
  const dropsI = (n, c) => `<g stroke="${c || "#5ec8ff"}" stroke-width="3" stroke-linecap="round">${(n === 2 ? [26, 38] : [22, 32, 42]).map((x) => `<line x1="${x}" y1="50" x2="${x - 2}" y2="55"/>`).join("")}</g>`;
  const boltI = () => `<path d="M34 40 26 53h6l-3 9 10-14h-6l3-8z" fill="#ffffff" stroke="#ff6f61" stroke-width="1.4" stroke-linejoin="round"/>`;
  const flakeI = (x, y, r) => `<g stroke="#fff" stroke-width="1.8" stroke-linecap="round"><path d="M${x} ${y - r}V${y + r}M${x - r * .87} ${y - r / 2}L${x + r * .87} ${y + r / 2}M${x - r * .87} ${y + r / 2}L${x + r * .87} ${y - r / 2}"/></g>`;
  function wicon(name) {
    const n = String(name || "cloudy"), night = n.indexOf("night") >= 0;
    const small = night ? moonI(4, 2, 0.55) : sunI(2, 0, 40);
    let g;
    if (n.startsWith("clear") && !night) return `<svg viewBox="0 0 120 120" aria-hidden="true">${SUN_BODY}</svg>`;
    if (n.startsWith("clear")) g = moonI(6, 4, 1);
    else if (n.startsWith("partly-cloudy")) g = small + cloudI(4, 6, 0.95);
    else if (n === "cloudy") g = cloudI(-6, -6, 0.8, true) + cloudI(4, 4, 0.95);
    else if (n === "foggy") g = cloudI(2, -4, 0.95) + `<g stroke="#dcecfa" stroke-width="3" stroke-linecap="round"><line x1="12" y1="50" x2="46" y2="50"/><line x1="20" y1="57" x2="54" y2="57"/></g>`;
    else if (n.startsWith("possibly-rainy")) g = small + cloudI(4, -2, 0.95) + dropsI(2);
    else if (n === "rainy") g = cloudI(2, -6, 0.95, true) + dropsI(3);
    else if (n.indexOf("sleet") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -6, 0.95, true) + dropsI(2, "#bfe8ff");
    else if (n.indexOf("snow") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -6, 0.95) + flakeI(24, 53, 5) + flakeI(40, 53, 5);
    else if (n.indexOf("thunderstorm") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -8, 0.95, true) + boltI();
    else if (n === "windy") g = `<g fill="none" stroke="#dcecfa" stroke-width="3.5" stroke-linecap="round"><path d="M8 24h30a7 7 0 1 0-7-7"/><path d="M8 34h42a7 7 0 1 1-7 7"/><path d="M8 44h20"/></g>`;
    else g = cloudI(2, 2, 0.95);
    return `<svg viewBox="0 0 64 64" aria-hidden="true">${g}</svg>`;
  }

  /* ---------------- moon phase (phase-accurate terminator) ---------------- */
  function moonArt(illumPct, waxing) {
    const k = clamp01((illumPct || 0) / 100), r = 52, cx = 60, cy = 60, top = cy - r, bot = cy + r;
    let lit = "";
    if (k >= 0.995) lit = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonLit)"/>`;
    else if (k > 0.005) {
      const rx = (r * Math.abs(1 - 2 * k)).toFixed(2), crescent = k < 0.5;
      const d = waxing ? `M${cx} ${top} A${r} ${r} 0 0 1 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 0 : 1} ${cx} ${top}Z`
        : `M${cx} ${top} A${r} ${r} 0 0 0 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 1 : 0} ${cx} ${top}Z`;
      lit = `<path d="${d}" fill="url(#gMoonLit)"/>`;
    }
    // earthshine rim keeps a new moon visible against the sky
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonDark)" stroke="rgba(220,236,255,.5)" stroke-width="2"/>${lit}` +
      `<g fill="#000" opacity=".07"><circle cx="44" cy="40" r="9"/><circle cx="74" cy="50" r="6"/><circle cx="62" cy="80" r="11"/><circle cx="36" cy="70" r="5"/></g>`;
  }

  /* ---------------- temperature: aurora ice-crystal arc ----------------
     45 ice tiles form a half-circle over the peaks; they are the multicolour cold-to-hot scale.
     Tiles light up (staggered sweep) from the cold end to the current temperature, where a glowing
     snowflake rides the arc (it rotates around the arc centre, so it travels along the curve).
     A teal band inside the arc is today's low-high range, with blue/coral markers. */
  const TEMP_SCALES = { f: { min: 0, max: 130, labels: [0, 20, 40, 60, 80, 100, 120] }, c: { min: -18, max: 54, labels: [-18, 0, 10, 20, 30, 40, 54] } };
  const HEAT = ["#7b5cff", "#6a74ff", "#4f93ff", "#3fb4ff", "#36d2ee", "#36e2c8", "#4eeea4", "#9cf0b8", "#e4eef8", "#ffc4ac", "#ff9a7f", "#ff6f61", "#e83f63", "#c42a72"];
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
  function heatColor(k) {
    const x = clamp01(k) * (HEAT.length - 1), i = Math.min(HEAT.length - 2, Math.floor(x)), t = x - i;
    const a = hex(HEAT[i]), b = hex(HEAT[i + 1]);
    return "rgb(" + a.map((v, j) => Math.round(v + (b[j] - v) * t)).join(",") + ")";
  }
  const AC = { cx: 450, cy: 372, r: 290 }, NT = 45;
  const pol = (cx, cy, r, a) => [cx + Math.sin(a * Math.PI / 180) * r, cy - Math.cos(a * Math.PI / 180) * r];
  function arcD(cx, cy, r, a0, a1) {
    const [x0, y0] = pol(cx, cy, r, a0), [x1, y1] = pol(cx, cy, r, a1);
    return `M${f1(x0)} ${f1(y0)} A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${f1(x1)} ${f1(y1)}`;
  }
  const angOf = (k) => -90 + clamp01(k) * 180;
  function tileD(i) {   // a faceted ice block: annular sector with a pointed outer edge
    const a0 = angOf(i / NT) + 0.45, a1 = angOf((i + 1) / NT) - 0.45, am = (a0 + a1) / 2, r0 = AC.r - 17, r1 = AC.r + 14, r2 = AC.r + 19;
    const P = (r, a) => pol(AC.cx, AC.cy, r, a).map(f1).join(" ");
    return `M${P(r0, a0)} L${P(r1, a0)} L${P(r2, am)} L${P(r1, a1)} L${P(r0, a1)} Z`;
  }
  let heroUnit = null, litN = -1;
  function buildHero(unit) {
    if (heroUnit === unit) return; heroUnit = unit; litN = -1;
    const S = TEMP_SCALES[unit];
    let base = "", heat = "";
    for (let i = 0; i < NT; i++) {
      const d = tileD(i), [hx1, hy1] = pol(AC.cx, AC.cy, AC.r - 10, angOf((i + 0.25) / NT)), [hx2, hy2] = pol(AC.cx, AC.cy, AC.r + 9, angOf((i + 0.25) / NT));
      base += `<path d="${d}"/>`;
      heat += `<g class="tile" data-i="${i}"><path d="${d}" fill="${heatColor((i + 0.5) / NT)}"/><path class="tile-hl" d="M${f1(hx1)} ${f1(hy1)} L${f1(hx2)} ${f1(hy2)}"/></g>`;
    }
    $("tScale").innerHTML = base; $("tHeat").innerHTML = heat;
    $("tBand").setAttribute("d", arcD(AC.cx, AC.cy, AC.r - 40, -90, 90));
    $("tLabels").innerHTML = S.labels.map((v) => { const [x, y] = pol(AC.cx, AC.cy, AC.r + 46, angOf((v - S.min) / (S.max - S.min))); return `<text x="${f1(x)}" y="${f1(y)}">${v}°</text>`; }).join("");
    // snowflake marker drawn at the top of the arc (rotated into place)
    const C = [450, 82]; let fl = "";
    for (let j = 0; j < 6; j++) {
      const a = j * 60, [x, y] = pol(C[0], C[1], 25, a), [bx, by] = pol(C[0], C[1], 14, a);
      const [l1x, l1y] = pol(bx, by, 9, a - 50), [r1x, r1y] = pol(bx, by, 9, a + 50);
      fl += `M${C[0]} ${C[1]} L${f1(x)} ${f1(y)} M${f1(bx)} ${f1(by)} L${f1(l1x)} ${f1(l1y)} M${f1(bx)} ${f1(by)} L${f1(r1x)} ${f1(r1y)} `;
    }
    $("tStarFlake").innerHTML = `<path class="fl-o" d="${fl}"/><path id="tFlakeIn" class="fl-i" d="${fl}"/><circle cx="450" cy="82" r="6.5" class="fl-c"/>`;
  }
  function rotArc(el, k) { el.style.transform = `rotate(${f1(angOf(k))}deg)`; }
  function fitBigTemp() {
    const t = $("tempNow"); if (!t || !t.getComputedTextLength) return;
    t.style.fontSize = "";
    const max = 430, len = t.getComputedTextLength();
    if (len > max) t.style.fontSize = (parseFloat(getComputedStyle(t).fontSize) * max / len).toFixed(1) + "px";
  }
  let tempShown = null, tempAnim = 0;
  function tweenTemp(to) {   // the big number counts to its new value
    cancelAnimationFrame(tempAnim);
    if (!isNum(to)) { tempShown = null; setText("tempNow", "--"); return; }
    const from = isNum(tempShown) ? tempShown : to, t0 = performance.now(), dur = 900;
    if (from === to || body.classList.contains("lite") || REDUCED) { tempShown = to; setText("tempNow", fx(to) + "°"); return; }
    const step = (t) => { const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); tempShown = from + (to - from) * e; setText("tempNow", tempShown.toFixed(1) + "°"); if (k < 1) tempAnim = requestAnimationFrame(step); else { tempShown = to; setText("tempNow", fx(to) + "°"); } };
    tempAnim = requestAnimationFrame(step);
  }
  function renderHero(T, U) {
    const unit = /C/i.test((U && U.temp) || "") ? "c" : "f", S = TEMP_SCALES[unit];
    buildHero(unit);
    const frac = (v) => clamp01((v - S.min) / (S.max - S.min));
    const now = T.now, lo = (T.low || {}).value, hi = (T.high || {}).value;
    const n = isNum(now) ? Math.max(1, Math.round(frac(now) * NT)) : 0, prev = litN < 0 ? 0 : litN;
    if (n !== litN) {
      document.querySelectorAll("#tHeat .tile").forEach((g) => { const i = +g.dataset.i, on = i < n;
        if (g.classList.contains("on") !== on) { g.style.transitionDelay = (Math.abs(i - (on ? prev : n)) * 22) + "ms"; g.classList.toggle("on", on); } });
      litN = n;
    }
    const star = $("tStar");
    if (isNum(now)) { rotArc(star, frac(now)); const c = heatColor(frac(now)); $("tFlakeIn").setAttribute("stroke", c); star.style.opacity = "1"; } else star.style.opacity = "0";
    if (isNum(lo) && isNum(hi)) {
      const a = frac(Math.min(lo, hi)) * 100, b = Math.max(a + 0.8, frac(Math.max(lo, hi)) * 100);
      $("tBand").setAttribute("stroke-dasharray", `0 ${a.toFixed(2)} ${(b - a).toFixed(2)} 200`);
    } else $("tBand").setAttribute("stroke-dasharray", "0 200");
    [["tLoMk", lo], ["tHiMk", hi]].forEach(([id, v]) => { const el = $(id); if (isNum(v)) { rotArc(el, frac(v)); el.style.opacity = "1"; } else el.style.opacity = "0"; });
    tweenTemp(now);
    fitBigTemp();
    setText("lowVal", isNum(lo) ? fx(lo) + "°" : "--");
    setText("highVal", isNum(hi) ? fx(hi) + "°" : "--");
    setText("lowTime", fmtTime((T.low || {}).time));
    setText("highTime", fmtTime((T.high || {}).time));
  }

  /* ---------------- wind: snowflake compass rose + icicle pointer ---------------- */
  (function buildRose() {
    const C = 150; let s = `<circle cx="${C}" cy="${C}" r="148" class="rose-disc"/><circle cx="${C}" cy="${C}" r="124" class="rose-field"/>`;
    const P = (r, a) => pol(C, C, r, a).map(f1).join(" ");
    // ring crystals on the 16 points (skipping the cardinal letters)
    for (let i = 0; i < 16; i++) { if (i % 4 === 0) continue; const a = i * 22.5, big = i % 2 === 0;
      s += `<path class="rose-tick" d="M${P(big ? 131 : 133, a)} L${P(127, a - (big ? 3 : 2))} L${P(big ? 119 : 123, a)} L${P(127, a + (big ? 3 : 2))} Z"/>`; }
    // snowflake: 8 dendrite arms, long cardinals and shorter intercardinals
    let arms = "", br = "";
    for (let i = 0; i < 8; i++) {
      const a = i * 45, card = i % 2 === 0, R = card ? 112 : 78;
      arms += `M${C} ${C} L${P(R, a)} `;
      (card ? [46, 70, 92] : [40, 60]).forEach((r, j) => { const L = card ? [16, 13, 9][j] : [11, 8][j], [bx, by] = pol(C, C, r, a);
        const [lx, ly] = pol(bx, by, L, a - 45), [rx, ry] = pol(bx, by, L, a + 45); br += `M${f1(bx)} ${f1(by)} L${f1(lx)} ${f1(ly)} M${f1(bx)} ${f1(by)} L${f1(rx)} ${f1(ry)} `; });
    }
    s += `<path class="rose-arm-o" d="${arms}${br}"/><path class="rose-arm" d="${arms}${br}"/>`;
    [["N", 0], ["E", 90], ["S", 180], ["W", 270]].forEach(([l, a]) => { const [x, y] = pol(C, C, 136, a); s += `<text x="${f1(x)}" y="${f1(y)}" class="rose-l${l === "N" ? " n" : ""}">${l}</text>`; });
    $("roseStatic").innerHTML = s;
    // icicle pointer: faceted shard pointing to where the wind comes from, small crystal tail
    $("needle").innerHTML = `<defs><linearGradient id="iceShard" x1="0" x2="1"><stop offset="0" stop-color="#eafffa"/><stop offset=".5" stop-color="#7ff0dc"/><stop offset="1" stop-color="#1fae96"/></linearGradient></defs>` +
      `<path class="sh-o" d="M150 14 L171 104 L150 121 L129 104 Z"/><path d="M150 14 L171 104 L150 121 L129 104 Z" fill="url(#iceShard)"/><path class="sh-f" d="M150 14 L150 121 L129 104 Z"/>` +
      `<path class="sh-t" d="M150 196 L160 212 L150 230 L140 212 Z"/>`;
  })();
  const SAND_MAX = { mph: 40, "km/h": 64, kph: 64, "m/s": 18, kts: 35, kn: 35 };
  function sandScaleFor(unit) { return SAND_MAX[unit] || 40; }
  let sandUnit = null;
  /* blowing snow: drift streak speed follows the live wind (quantised buckets with hysteresis so the
     CSS animation duration only changes occasionally), streak direction follows the wind direction */
  const DRIFT_B = [[1, 14], [3, 8], [6, 5.2], [10, 3.4], [15, 2.4], [22, 1.7], [30, 1.2]];
  let driftIdx = -2, driftDirRev = null;
  function setDriftRate(speed, dir) {
    let idx = -1; if (isNum(speed)) DRIFT_B.forEach(([s], i) => { if (speed >= s) idx = i; });
    if (driftIdx >= 0 && idx >= 0 && idx !== driftIdx && isNum(speed)) {   // hysteresis: need 0.8 past the boundary
      const edge = idx > driftIdx ? DRIFT_B[idx][0] : DRIFT_B[driftIdx][0];
      if (Math.abs(speed - edge) < 0.8) idx = driftIdx;
    }
    if (idx !== driftIdx) {
      driftIdx = idx;
      body.style.setProperty("--drift", (idx >= 0 ? DRIFT_B[idx][1] : 14) + "s");
      body.style.setProperty("--drift-o", idx < 0 ? "0" : (0.35 + 0.65 * idx / (DRIFT_B.length - 1)).toFixed(2));
      body.style.setProperty("--roll", (idx >= 0 ? DRIFT_B[idx][1] / 2.5 : 4).toFixed(2) + "s");
      body.classList.toggle("calm-air", idx < 0);
    }
    if (isNum(dir)) { const rev = dir > 0 && dir < 180; if (rev !== driftDirRev) { driftDirRev = rev; body.classList.toggle("drift-rev", rev); } }
  }
  function setSand(speed, gust, unit, dir) {
    if (MOCK && params.has("gust")) gust = parseFloat(params.get("gust"));   // mock-only: preview the gust marker
    const max = sandScaleFor(unit);
    if (sandUnit !== unit) { sandUnit = unit; $("sandScale").innerHTML = [0, .25, .5, .75, 1].map((k) => `<span>${Math.round(max * k)}</span>`).join(""); }
    const k = isNum(speed) ? clamp01(speed / max) : 0;
    $("driftMask").style.transform = `translateX(${((k - 1) * 100).toFixed(2)}%)`;
    $("driftIn").style.transform = `translateX(${((1 - k) * 100).toFixed(2)}%)`;
    $("ballMove").style.transform = `translateX(${(k * 100).toFixed(2)}%)`;
    $("ballMove").classList.toggle("rolling", isNum(speed) && speed >= 1);
    const gm = $("gustMove");
    if (isNum(gust) && gust > 0) { gm.style.transform = `translateX(${(clamp01(gust / max) * 100).toFixed(2)}%)`; gm.style.opacity = "1"; } else gm.style.opacity = "0";
    setDriftRate(speed, dir);
  }
  function tweenWind(to) {
    cancelAnimationFrame(windAnim);
    if (!isNum(to)) { windShown = null; setText("windNow", "--"); return; }
    const from = isNum(windShown) ? windShown : to, t0 = performance.now(), dur = 280;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      windShown = from + (to - from) * e; setText("windNow", windShown.toFixed(1));
      if (k < 1) windAnim = requestAnimationFrame(step); else windShown = to;
    };
    if (from === to || body.classList.contains("lite")) { windShown = to; setText("windNow", fx(to)); } else windAnim = requestAnimationFrame(step);
  }
  function setWind(speed, dir, dirCard, fallbackTxt, calm, unit, gust) {
    tweenWind(speed);
    setText("windNowUnit", unit || "mph");
    setHTML("windDir", isNum(dir) ? `${esc(dirCard || "--")}<span class="unit">${fi(dir)}°</span>` : esc(fallbackTxt || "--"));
    const f = $("needle");
    if (isNum(dir)) {
      if (needleAngle === null) needleAngle = dir;
      else { const delta = ((dir - needleAngle) % 360 + 540) % 360 - 180; needleAngle += delta; }
      f.style.transform = `rotate(${needleAngle}deg)`;
    }
    f.classList.toggle("calm", !!calm);
    f.style.opacity = isNum(dir) ? "" : "0";
    setSand(speed, gust, unit || "mph", dir);
  }
  const CARD16 = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  function onRapidWind(w) {
    if (!DATA || !isNum(w.speed)) return;
    const W = DATA.wind = DATA.wind || {};
    const calm = w.calm != null ? !!w.calm : w.speed < 1;
    const dir = isNum(w.dir) ? w.dir : W.dir;
    const card = w.dir_cardinal || (isNum(dir) ? CARD16[Math.round(dir / 22.5) % 16] : null);
    Object.assign(W, { speed: w.speed, dir: dir, calm: calm, dir_cardinal: card, cardinal: calm ? "Calm" : card });
    if (isNum(w.gust)) { W.gust = w.gust; setText("gustNow", fx(w.gust)); }
    setWind(w.speed, dir, card, W.cardinal, calm, (DATA.units && DATA.units.wind) || w.unit, W.gust);
  }

  /* ---------------- barometer: ice core ----------------
     A drilled ice-core sample: compressed layers are the pressure zones (stormy at the bottom,
     very dry at the top) with trapped air bubbles. An aurora-green ledge + arrow marks the current
     pressure, chevrons show the trend, dashed lines are today's low and high. */
  const BZ = [[1040, 1050, "#f2f9ff", "Very dry", "#0b2a52"], [1020, 1040, "#c3e2f7", "Fair", "#0b2a52"], [1000, 1020, "#84bae4", "Change", "#062042"],
    [980, 1000, "#3e7cbc", "Rain", "#ffffff"], [950, 980, "#26337a", "Stormy", "#ffffff"]];
  let baroP = null;
  function setBaro(P) { baroP = P; drawStrata(); }
  function drawStrata() {
    const box = $("strataBox"); if (!box || !baroP) return;
    const W = box.clientWidth, H = box.clientHeight; if (!W || !H) return;
    const P = baroP, isIn = (DATA && DATA.units && DATA.units.pressure) === "inHg", toMb = (v) => (isIn ? v * 33.8639 : v);
    const lmb = P.low && isNum(P.low.value) ? toMb(P.low.value) : null, hmb = P.high && isNum(P.high.value) ? toMb(P.high.value) : null;
    const sig = JSON.stringify([P.slp_mb, P.trend, lmb, hmb, W, H]);
    if (box.dataset.sig === sig) return;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    const aw = u * 2.0, X0 = aw + u * 0.35, X1 = W - 1, pad = 3, rx = Math.min(u * 0.9, (X1 - X0) * 0.12);
    const y = (mb) => pad + (1050 - Math.max(950, Math.min(1050, mb))) / 100 * (H - 2 * pad);
    const wav = (yy, k) => `M${f1(X0)} ${f1(yy)} C${f1(X0 + (X1 - X0) * 0.3)} ${f1(yy - k * u * 0.22)} ${f1(X0 + (X1 - X0) * 0.65)} ${f1(yy + k * u * 0.25)} ${f1(X1)} ${f1(yy - k * u * 0.1)}`;
    let g = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-label="pressure ice core"><defs><clipPath id="coreClip"><rect x="${f1(X0)}" y="${pad}" width="${f1(X1 - X0)}" height="${f1(H - 2 * pad)}" rx="${f1(rx)}"/></clipPath>` +
      `<linearGradient id="coreSh" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".0"/><stop offset=".12" stop-color="#fff" stop-opacity=".38"/><stop offset=".3" stop-color="#fff" stop-opacity=".05"/><stop offset=".8" stop-color="#001030" stop-opacity=".08"/><stop offset="1" stop-color="#001030" stop-opacity=".35"/></linearGradient></defs><g clip-path="url(#coreClip)">`;
    BZ.forEach(([lo, hi, col], i) => {
      const yt = y(hi), yb = y(lo), k = i % 2 ? 1 : -1;
      g += `<path d="${wav(yt, k)} L${f1(X1)} ${f1(yb + 2)} L${f1(X0)} ${f1(yb + 2)} Z" fill="${col}"/>`;
      g += `<path d="${wav(yt + (yb - yt) * 0.6, -k)}" stroke="${i < 3 ? "rgba(20,60,110,.16)" : "rgba(255,255,255,.14)"}" stroke-width="1.5" fill="none"/>`;
      for (let b = 0; b < 4; b++) { const bx = X0 + (X1 - X0) * (0.62 + ((i * 3 + b * 7) % 10) / 30), by = yt + (yb - yt) * (0.2 + ((i * 5 + b * 3) % 7) / 10), br = u * (0.1 + ((i + b) % 3) * 0.05);
        g += `<circle cx="${f1(bx)}" cy="${f1(by)}" r="${f1(br)}" class="bub${i < 3 ? "" : " lt"}"/>`; }
    });
    g += `<rect x="${f1(X0)}" y="${pad}" width="${f1(X1 - X0)}" height="${f1(H - 2 * pad)}" fill="url(#coreSh)"/></g>`;
    g += `<rect x="${f1(X0)}" y="${pad}" width="${f1(X1 - X0)}" height="${f1(H - 2 * pad)}" rx="${f1(rx)}" fill="none" stroke="rgba(220,240,255,.75)" stroke-width="1.6"/>`;
    const fz = Math.min(u * 0.82, (H - 2 * pad) / 5 * 0.62);
    BZ.forEach(([lo, hi, , name, tc]) => { g += `<text x="${f1(X0 + u * 0.55)}" y="${f1((y(lo) + y(hi)) / 2)}" class="z-l" fill="${tc}" font-size="${f1(fz)}">${name}</text>`; });
    [[lmb, "L"], [hmb, "H"]].forEach(([v]) => { if (isNum(v)) g += `<path class="bl-mk" d="M${f1(X0)} ${f1(y(v))} H${f1(X1)}"/>`; });
    if (isNum(P.slp_mb)) {
      const ym = y(P.slp_mb), ah = u * 0.75;
      g += `<path class="b-ledge-o" d="M${f1(aw * 0.6)} ${f1(ym)} H${f1(X1 - u * 0.1)}"/><path class="b-ledge" d="M${f1(aw * 0.6)} ${f1(ym)} H${f1(X1 - u * 0.1)}"/><path class="b-arrow" d="M1 ${f1(ym - ah)} L${f1(aw)} ${f1(ym)} L1 ${f1(ym + ah)} Z"/>`;
      const tr = P.trend, n = !isNum(tr) || Math.abs(tr) < 0.3 ? 0 : Math.abs(tr) < 1.5 ? 1 : 2, up = tr > 0, cw = aw * 0.38, cx = aw * 0.42;
      for (let i = 0; i < n; i++) {
        const yy = up ? ym - ah - u * 0.55 - i * u * 0.6 : ym + ah + u * 0.55 + i * u * 0.6, d = up ? -1 : 1;
        g += `<path class="b-chev ${up ? "up" : "down"}" d="M${f1(cx - cw)} ${f1(yy - d * cw * 0.6)} L${f1(cx)} ${f1(yy + d * cw * 0.4)} L${f1(cx + cw)} ${f1(yy - d * cw * 0.6)}"/>`;
      }
    }
    box.innerHTML = g + `</svg>`; box.dataset.sig = sig;
  }

  /* ---------------- humidity / UV ---------------- */
  let humK = 0;
  function placeHum() { const m = $("humMove"); if (m) m.style.transform = `translateX(${(humK * 100).toFixed(2)}%)`; }
  const UV_COL = ["#5ef0a0", "#5ef0a0", "#3fe0c5", "#36c8ec", "#4f93ff", "#7f7dff", "#a96bff", "#d85ad0", "#ff5a8a", "#ff4d4d", "#e0306a"];
  (function buildUV() {   // snow-glare crystals: six-point sparkles that light up with the UV index
    let s = "";
    for (let i = 0; i < 11; i++) {
      const cx = 20 + i * 40, cy = 20; let d = "";
      for (let j = 0; j < 3; j++) { const [x1, y1] = pol(cx, cy, 17, j * 60), [x2, y2] = pol(cx, cy, 17, j * 60 + 180); d += `M${f1(x1)} ${f1(y1)} L${f1(x2)} ${f1(y2)} `; }
      s += `<g class="uvg" data-i="${i}" style="--c:${UV_COL[i]}"><path d="${d}"/><path class="uvd" d="M${cx} ${cy - 7} L${cx + 5} ${cy} L${cx} ${cy + 7} L${cx - 5} ${cy} Z"/></g>`;
    }
    $("uvGlyphs").innerHTML = s;
  })();
  function humText(rh, dew, unit) {
    if (!isNum(rh)) return "--";
    let dp = dew; if (isNum(dp) && unit === "°C") dp = dp * 9 / 5 + 32;
    if (isNum(dp)) { if (dp < 50) return "Dry"; if (dp < 60) return "Comfortable"; if (dp < 65) return "Sticky"; if (dp < 70) return "Humid"; return "Oppressive"; }
    return rh < 30 ? "Dry" : rh < 60 ? "Comfortable" : "Humid";
  }
  const uvText = (uv) => (uv < 3 ? "Low" : uv < 6 ? "Moderate" : uv < 8 ? "High" : uv < 11 ? "Very high" : "Extreme");

  /* ---------------- next 12 hours: the snowy ridge ---------------- */
  function smoothPath(pts) {
    if (pts.length < 2) return "";
    let d = `M${f1(pts[0][0])} ${f1(pts[0][1])}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      d += ` C${f1(p1[0] + (p2[0] - p0[0]) / 6)} ${f1(p1[1] + (p2[1] - p0[1]) / 6)} ${f1(p2[0] - (p3[0] - p1[0]) / 6)} ${f1(p2[1] - (p3[1] - p1[1]) / 6)} ${f1(p2[0])} ${f1(p2[1])}`;
    }
    return d;
  }
  function ridgePath(pts, jag, phase) {   // straight snowy ridgeline with a small peak between each hour
    let d = `M${f1(pts[0][0])} ${f1(pts[0][1])}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const [x1, y1] = pts[i], [x2, y2] = pts[i + 1], j = ((i + phase) % 3 === 0 ? 1 : 0.5) * jag;
      d += ` L${f1((x1 + x2) / 2 + (i % 2 ? 4 : -4))} ${f1(Math.min(y1, y2) - j)} L${f1(x2)} ${f1(y2)}`;
    }
    return d;
  }
  let hourList = [];
  function renderHourly(hours) { hourList = hours.slice(0, 12); drawDunes(); }
  function drawDunes() {
    const el = $("hours"), W = el.clientWidth, H = el.clientHeight;
    const list = hourList;
    if (!W || !H) return;
    if (!list.length) { setHTML("hours", `<div class="label dunes-none">Hourly forecast unavailable</div>`); el.dataset.sig = ""; return; }
    const sig = JSON.stringify([list.map((h) => [h.time, h.temp, h.icon, h.precip]), W, H, h24]);
    if (el.dataset.sig === sig) return;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    const n = list.length, cw = W / 12;
    const temps = list.map((h) => h.temp).filter(isNum);
    const mn = Math.min.apply(null, temps), mx = Math.max.apply(null, temps), span = Math.max(1, mx - mn);
    const fsH = u * 1.05, fsT = u * 1.55, fsP = u * 0.95, ic = Math.min(cw * 0.62, H * 0.27);
    const yHour = fsH * 1.05;
    const crestTop = yHour + fsH * 0.5 + ic + fsT * 1.25;
    const crestBot = H - fsP * 2.2;
    const pts = list.map((h, i) => [(i + 0.5) * cw, isNum(h.temp) ? crestTop + (1 - (h.temp - mn) / span) * (crestBot - crestTop) : (crestTop + crestBot) / 2]);
    const ext = [[-cw * 0.5, pts[0][1] + 6], ...pts, [W + cw * 0.5, pts[n - 1][1] + 6]];
    const line = ridgePath(ext, fsT * 0.35, 0);
    const back = ridgePath(ext.map(([x, y], i) => [x + cw * 0.5, Math.min(H - 2, y + 10 + (i % 2 ? 7 : -3))]), fsT * 0.5, 1);
    let s = `<svg class="dune-svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-label="next 12 hours"><defs>
      <linearGradient id="ridgeG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".45" stop-color="#d9eaf8"/><stop offset="1" stop-color="#9dbfdf"/></linearGradient>
      <linearGradient id="ridgeB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7ea7cf"/><stop offset="1" stop-color="#3d6596"/></linearGradient></defs>`;
    s += `<path class="dune-back" d="${back} L${W + cw} ${H} L${-cw} ${H} Z"/>`;
    s += `<path class="dune-front" d="${line} L${W + cw} ${H} L${-cw} ${H} Z"/><path class="dune-crest" d="${line}"/>`;
    list.forEach((h, i) => {
      const [x, y] = pts[i];
      s += `<text class="dh${i === 0 ? " now" : ""}" x="${f1(x)}" y="${f1(yHour)}" font-size="${f1(fsH)}">${esc(i === 0 ? "Now" : fmtHour(h.time))}</text>`;
      const iy = y - fsT * 1.2 - ic;
      const wi = wicon(h.icon), vb = (wi.match(/viewBox="([^"]+)"/) || [0, "0 0 64 64"])[1];
      s += `<svg x="${f1(x - ic / 2)}" y="${f1(iy)}" width="${f1(ic)}" height="${f1(ic)}" viewBox="${vb}" overflow="visible">${wi.replace(/^<svg[^>]*>|<\/svg>$/g, "")}</svg>`;
      s += `<text class="dt" x="${f1(x)}" y="${f1(y - fsT * 0.3)}" font-size="${f1(fsT)}">${fi(h.temp)}°</text>`;
      const p = isNum(h.precip) ? h.precip : null;
      if (p !== null) s += dropLabel(x, Math.min(H - fsP * 0.4, y + fsP * 1.6), fsP, p);
    });
    s += `</svg>`;
    el.innerHTML = s; el.dataset.sig = sig;
  }
  const ro = window.ResizeObserver && new ResizeObserver(() => { drawDunes(); drawCairns(); drawStrata(); placeHum(); }); ["grid", "ltBars", "hours", "strataBox"].forEach((id) => { const e = document.getElementById(id); if (e && window.ResizeObserver) ro.observe(e); });

  /* ---------------- lightning: storm over the mesa, cairn chart ---------------- */
  function strikeRecentRed(L) { return isNum(L.last_epoch) && nowS() - L.last_epoch < 600; }
  function lightningActive(L) { return isNum(L.last_epoch) && nowS() - L.last_epoch < 1800; }
  function setLamp(el, color, blink) {
    if (!el) return;
    const sm = el.classList.contains("sm") ? " sm" : "", extra = el.classList.contains("lt-lamp") ? " lt-lamp" : "";
    const cls = "lamp" + sm + extra + (color ? " " + color : "") + (blink ? " blink" : "");
    if (el.className !== cls) el.className = cls;
  }
  function strikeWhen(ts) {
    if (!isNum(ts)) return "";
    if (dayKey(ts) === dayKey(nowS())) return "at " + fmtTime(ts);
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000)) + ", " + fmtTime(ts);
  }
  function flashLightning() {
    flashCard($("ltCard"));
    const b = $("strikeBadge"); b.classList.remove("zap"); void b.offsetWidth; b.classList.add("zap");
  }
  function onStrikeCore(e) {
    if (!DATA || !isNum(e.epoch)) return;
    const ep = e.epoch + OFFSET / 1000;
    const L = DATA.lightning = DATA.lightning && typeof DATA.lightning === "object" ? DATA.lightning : {};
    if (!isNum(L.last_epoch) || ep >= L.last_epoch) { L.last_epoch = ep; L.last_distance = e.distance; }
    ["count_1h", "count_3h", "count_today", "count_month", "count_30m"].forEach((k) => { L[k] = (isNum(L[k]) ? L[k] : 0) + 1; });
    if (isNum(e.distance)) L.nearest_30m = isNum(L.nearest_30m) ? Math.min(L.nearest_30m, e.distance) : e.distance;
    if (Array.isArray(L.hourly) && L.hourly.length) {
      const hr = Math.floor(ep / 3600) * 3600; let last = L.hourly[L.hourly.length - 1];
      for (let g = 0; last && isNum(last.time) && last.time < hr && g < 48; g++) { L.hourly.shift(); last = { time: last.time + 3600, count: 0, min_distance: null }; L.hourly.push(last); }
      if (last && last.time === hr) last.count = (isNum(last.count) ? last.count : 0) + 1;
    }
    renderLightning(L, DATA.units || {}); updateStrikeBadge(); flashLightning();
  }
  let cairnData = null;
  function drawCairns() {   // stacked ice blocks: one stack per hour
    const el = $("ltBars"); if (!cairnData || !el) return;
    const { counts, active } = cairnData, W = el.clientWidth, H = el.clientHeight;
    if (!W || !H) return;
    const sig = JSON.stringify([counts, active, W, H]);
    if (el.dataset.sig === sig) return;
    const n = counts.length, mx = Math.max(1, Math.max.apply(null, counts)), cw = W / n, MAXS = 6;
    const sh = (H - 3) / MAXS, sw = Math.min(cw * 0.8, sh * 1.5);
    let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-label="strikes per hour, last ${n} hours">`;
    s += `<path class="cairn-ground" d="M0 ${H - 1.5} H${W}"/>`;
    counts.forEach((c, i) => {
      if (!c) return;
      const k = Math.max(1, Math.round(Math.sqrt(c / mx) * MAXS)), now = i === n - 1 && active;
      let g = `<g class="cairn${now ? " now" : ""}"><title>${c} strikes</title>`;
      for (let j = 0; j < k; j++) {
        const x = (i + 0.5) * cw - sw / 2, y = H - 3 - (j + 1) * sh + 0.8, bh = sh - 1.6;
        g += `<rect class="st${(i + j) % 3}" x="${f1(x)}" y="${f1(y)}" width="${f1(sw)}" height="${f1(bh)}" rx="${f1(Math.min(2.5, bh * 0.25))}"/>` +
          `<path class="blk-hl" d="M${f1(x + 1.5)} ${f1(y + bh - 2)} V${f1(y + 1.5)} H${f1(x + sw - 1.5)}"/>`;
      }
      s += g + `</g>`;
    });
    el.innerHTML = s + `</svg>`; el.dataset.sig = sig;
  }
    /* 1.5.5: the Lightning card is always on screen. Strike data is cleaned before drawing, a draw that
     fails falls back to the last good values (never a blank or missing card), and missing values show "—".
     The card's tap/strike highlight uses the class "lt-flash" ("flash" is the full-screen sky-flash
     layer in some themes; putting that class on the card hid it after the first live strike). */
  let ltLastGood = null;
  const fiD = (v) => (isNum(v) ? fi(v) : "\u2014");
  function cleanLightning(L) {
    const src = L && typeof L === "object" ? L : {}, n = (v) => (isNum(v) ? v : null), out = Object.assign({}, src);
    ["last_epoch", "last_distance", "count_1h", "count_3h", "count_today", "count_month", "count_30m", "nearest_30m"].forEach((k) => { out[k] = n(src[k]); });
    out.hourly = Array.isArray(src.hourly) ? src.hourly.map((b) => (b && typeof b === "object"
      ? { time: n(b.time), count: isNum(b.count) ? b.count : 0, min_distance: n(b.min_distance) } : { time: null, count: 0, min_distance: null })) : null;
    return out;
  }
  function renderLightning(L, U) {
    const card = $("ltCard"); if (!card) return;
    card.classList.remove("flash", "hidden");
    try { const c = cleanLightning(L); renderLightningCore(c, U || {}); ltLastGood = c; }
    catch (err) {
      try { console.info("wxdash: lightning draw failed, keeping the last good values", err); } catch (_) {}
      try { if (ltLastGood) renderLightningCore(ltLastGood, U || {}); } catch (_) {}
    }
  }
  function flashCard(c) {
    if (!c) return;
    c.classList.remove("flash", "lt-flash"); void c.offsetWidth; c.classList.add("lt-flash");
    clearTimeout(c._ltf); c._ltf = setTimeout(() => c.classList.remove("lt-flash"), 900);
  }
  function onStrike(e) {
    try { onStrikeCore(e && typeof e === "object" ? e : {}); }
    catch (err) {
      try { console.info("wxdash: strike update failed", err); } catch (_) {}
      if (DATA) renderLightning(DATA.lightning, DATA.units || {});
    }
  }
  function renderLightningCore(L, U) {
    const dist = U.distance || "mi", has = isNum(L.last_epoch), active = lightningActive(L), red = active && strikeRecentRed(L);
    $("ltCard").classList.toggle("active", active);
    $("ltCard").classList.toggle("near", red);
    setLamp($("ltLamp"), active ? (red ? "red" : "amber") : "", active);
    const near = isNum(L.nearest_30m) ? L.nearest_30m : L.last_distance;
    body.classList.toggle("lt-storm", red && isNum(L.last_distance) && L.last_distance <= (dist === "km" ? 16 : 10));   // storm over the peaks + sky flash when a strike is close and recent
    const noData = !has && !isNum(L.count_1h) && !isNum(L.count_3h) && !isNum(L.count_today);
    setText("ltStatusText", active ? (isNum(near) ? `Active \u00b7 ${fiD(near)} ${dist}` : "Active") : noData ? "No data" : "No strikes nearby");
    setText("ltDist", has && isNum(L.last_distance) ? fiD(L.last_distance) : "\u2014");
    setText("ltUnit", dist);
    setText("ltAgo", has ? ago(L.last_epoch) : noData ? "\u2014" : "No strikes detected");
    setText("ltWhen", has ? strikeWhen(L.last_epoch) : "\u00a0");
    [["ltC1", L.count_1h], ["ltC3", L.count_3h], ["ltCT", L.count_today], ["ltCM", L.count_month]].forEach(([id, v]) => { setText(id, fiD(v)); $(id).classList.toggle("zero", fiD(v) === "0"); });
    const hrs = Array.isArray(L.hourly) ? L.hourly : null;
    if (!hrs || !hrs.length) { cairnData = null; setHTML("ltBars", `<div class="lt-none">Hourly history unavailable</div>`); $("ltBars").dataset.sig = ""; setText("ltPeak", ""); $("ltAxis").classList.add("hidden"); return; }
    $("ltAxis").classList.remove("hidden");
    const counts = hrs.map((b) => (isNum(b.count) ? b.count : 0)), total = counts.reduce((a, b) => a + b, 0);
    setText("ltPeak", total ? `${total} in ${hrs.length}h` : `None in ${hrs.length}h`);
    $("ltAxis").children[0].textContent = hrs.length + "h ago"; $("ltAxis").children[1].textContent = Math.round(hrs.length / 2) + "h";
    cairnData = { counts, active }; drawCairns();
  }

  /* ---------------- small text fitting helpers ---------------- */
  function fitOne(el, minK) {
    if (!el) return;
    const key = el.textContent + "|" + el.clientWidth; if (el.dataset.fit === key) return; el.dataset.fit = key;
    el.style.fontSize = ""; el.classList.remove("two");
    const base = parseFloat(getComputedStyle(el).fontSize);
    for (let f = base; el.scrollWidth > el.clientWidth + 0.5 && f > base * minK; ) { f *= 0.95; el.style.fontSize = f + "px"; }
    if (el.scrollWidth > el.clientWidth + 0.5) { el.style.fontSize = ""; el.classList.add("two"); }
  }
  const FIT = ["heroCond", "fcUntil", "moonName", "fcTmCond", "baroTendency"];
  function fitAll() { FIT.forEach((id) => fitOne($(id), 0.72)); document.querySelectorAll(".card-head .tag").forEach((t) => fitOne(t, 0.72)); fitBigTemp(); }
  window.addEventListener("resize", () => { FIT.forEach((id) => { const e = $(id); if (e) e.dataset.fit = ""; }); document.querySelectorAll(".card-head .tag").forEach((t) => { t.dataset.fit = ""; }); fitAll(); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { FIT.forEach((id) => { const e = $(id); if (e) e.dataset.fit = ""; }); fitAll(); if ($("hours")) $("hours").dataset.sig = ""; drawDunes(); });


  /* ---------------- animation layer ----------------
     Decorative textures are generated once as SVG data-URIs and painted as CSS backgrounds on HTML
     layers; CSS keyframes then move those layers with transform/opacity only (compositor thread).
     No JS runs per frame. Hidden page -> animations paused. */
  const REDUCED = !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);
  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const uri = (svg) => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
  function starsTex(n, w, h, maxY, rmax) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMin slice">`;
    for (let i = 0; i < n; i++) { const x = rnd() * w, y = rnd() * h * maxY, r = 0.6 + rnd() * rmax;
      s += `<circle cx="${f1(x)}" cy="${f1(y)}" r="${r.toFixed(2)}" fill="#eef6ff" opacity="${(0.55 + rnd() * 0.45).toFixed(2)}"/>`;
      if (r > rmax * 0.85) s += `<path d="M${f1(x - r * 3)} ${f1(y)} H${f1(x + r * 3)} M${f1(x)} ${f1(y - r * 3)} V${f1(y + r * 3)}" stroke="#eef6ff" stroke-width=".7" opacity=".7"/>`; }
    return uri(s + `</svg>`);
  }
  function snowTex(n, size, rmin, rmax, crystals) {   // seamless tile (flakes wrap at the edges)
    let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}">`;
    for (let i = 0; i < n; i++) { const x = rnd() * size, y = rnd() * size, r = rmin + rnd() * (rmax - rmin), o = (0.55 + rnd() * 0.45).toFixed(2);
      [[0, 0], [-size, 0], [size, 0], [0, -size], [0, size]].forEach(([dx, dy]) => {
        const cx = x + dx, cy = y + dy; if (cx < -8 || cx > size + 8 || cy < -8 || cy > size + 8) return;
        if (crystals && r > rmax * 0.7) { let d = ""; for (let j = 0; j < 3; j++) { const a = j * Math.PI / 3, ex = Math.cos(a) * r * 1.6, ey = Math.sin(a) * r * 1.6; d += `M${f1(cx - ex)} ${f1(cy - ey)} L${f1(cx + ex)} ${f1(cy + ey)} `; }
          s += `<path d="${d}" stroke="#fff" stroke-width="${(r * 0.45).toFixed(2)}" stroke-linecap="round" opacity="${o}"/>`; }
        else s += `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${r.toFixed(2)}" fill="#fff" opacity="${o}"/>`; }); }
    return uri(s + `</svg>`);
  }
  function driftTex(n) {   // horizontal blowing-snow streaks, tiles seamlessly in x
    let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 100" preserveAspectRatio="none">`;
    for (let i = 0; i < n; i++) { const x = rnd() * 400, y = 8 + rnd() * 84, L = 14 + rnd() * 46, w = 1 + rnd() * 1.8, o = (0.35 + rnd() * 0.5).toFixed(2);
      [0, -400, 400].forEach((dx) => { const x0 = x + dx; if (x0 > 400 || x0 + L < 0) return;
        s += `<path d="M${f1(x0)} ${f1(y)} h${f1(L)}" stroke="#fff" stroke-width="${w.toFixed(2)}" stroke-linecap="round" opacity="${o}"/>`;
        s += `<circle cx="${f1(x0 + L + 3)}" cy="${f1(y)}" r="${(w * 0.9).toFixed(2)}" fill="#fff" opacity="${o}"/>`; }); }
    return uri(s + `</svg>`);
  }
  function auroraTex(cols, base, amp, height, waves, seedN, rays) {
    seed = seedN;
    const W = 1000, H = 400, N = 40, lower = [], upper = [];
    const ph = rnd() * 6.28, ph2 = rnd() * 6.28;
    for (let i = 0; i <= N; i++) { const x = i / N * W, t = i / N;
      const yb = base + Math.sin(t * Math.PI * waves + ph) * amp + Math.sin(t * Math.PI * waves * 2.3 + ph2) * amp * 0.35;
      lower.push([x, yb]); upper.push([x, Math.max(4, yb - height * (0.7 + 0.3 * Math.sin(t * Math.PI * 3 + ph2)))]); }
    const path = (a) => a.map(([x, y], i) => (i ? "L" : "M") + f1(x) + " " + f1(y)).join(" ");
    const curtain = path(upper) + " " + path(lower.slice().reverse()).replace(/^M/, "L") + " Z";
    const skirt = path(lower) + " " + path(lower.slice().reverse().map(([x, y]) => [x, y + 26])).replace(/^M/, "L") + " Z";
    let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><defs>` +
      `<linearGradient id="c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${cols[2]}" stop-opacity="0"/><stop offset=".45" stop-color="${cols[2]}" stop-opacity=".28"/>` +
      `<stop offset=".78" stop-color="${cols[1]}" stop-opacity=".62"/><stop offset=".97" stop-color="${cols[0]}" stop-opacity=".95"/><stop offset="1" stop-color="${cols[0]}" stop-opacity="1"/></linearGradient>` +
      `<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${cols[0]}" stop-opacity=".35"/><stop offset="1" stop-color="${cols[0]}" stop-opacity="0"/></linearGradient>` +
      `<clipPath id="q"><path d="${curtain}"/></clipPath></defs>`;
    s += `<path d="${skirt}" fill="url(#k)"/><path d="${curtain}" fill="url(#c)"/><g clip-path="url(#q)">`;
    for (let i = 0; i < rays; i++) { const x = rnd() * W, w = 2 + rnd() * 9; s += `<rect x="${f1(x)}" y="0" width="${f1(w)}" height="${H}" fill="${rnd() > 0.5 ? "#ffffff" : cols[0]}" opacity="${(0.06 + rnd() * 0.2).toFixed(2)}"/>`; }
    s += `</g><path d="${path(lower)}" fill="none" stroke="${cols[0]}" stroke-width="2.5" opacity=".9"/></svg>`;
    return uri(s);
  }
  function glintTex(seedN) {
    seed = seedN; let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 440" preserveAspectRatio="xMidYMax slice">`;
    [[230, 300], [600, 316], [92, 322], [780, 328], [470, 268], [190, 256], [610, 246], [330, 276], [700, 312], [520, 330]].forEach(([x, y], i) => {
      if ((i + seedN) % 2) return; const r = 6 + rnd() * 6;
      s += `<path d="M${x - r} ${y} H${x + r} M${x} ${y - r} V${y + r}" stroke="#fff" stroke-width="2" stroke-linecap="round"/><circle cx="${x}" cy="${y}" r="2.6" fill="#fff"/>`; });
    return uri(s + `</svg>`);
  }
  (function buildAnimLayers() {
    const css = [];
    const A1 = auroraTex(["#5effa8", "#2fe3c8", "#8a7bff"], 300, 46, 230, 2.2, 11, 70);
    const A2 = auroraTex(["#36e6d6", "#6f8dff", "#c08cff"], 250, 56, 210, 1.6, 23, 60);
    const A3 = auroraTex(["#9d7bff", "#d07bff", "#5effa8"], 190, 40, 170, 2.8, 37, 50);
    css.push(`.aur1{background-image:${A1}}`, `.aur2{background-image:${A2}}`, `.aur3{background-image:${A3}}`);
    seed = 101; css.push(`#bg .tw1{background-image:${starsTex(46, 1920, 160, 1, 1.5)}}`);
    seed = 202; css.push(`#bg .tw2{background-image:${starsTex(30, 1920, 160, 1, 2.0)}}`);
    seed = 404; css.push(`.hs-tw.tw1{background-image:${starsTex(60, 900, 440, 0.72, 1.9)}}`);
    seed = 606; css.push(`.sn1{background-image:${snowTex(34, 400, 1.1, 2.2, false)}}`);
    seed = 707; css.push(`.sn2{background-image:${snowTex(14, 400, 2.4, 4.2, true)}}`);
    seed = 808; css.push(`.sn3{background-image:${snowTex(22, 400, 1.4, 3.2, true)}}`);
    seed = 909; css.push(`.drift-strip{background-image:${driftTex(26)}}`);
    css.push(`.hs-glint::before{background-image:${glintTex(1)}}`, `.hs-glint::after{background-image:${glintTex(2)}}`);
    css.push(`.hs-storm{background-image:${uri(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 440" preserveAspectRatio="xMidYMax slice"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1b2440"/><stop offset="1" stop-color="#3b4a72"/></linearGradient></defs>` +
      `<path d="M0 0 H900 V96 Q870 128 830 108 Q800 140 750 116 Q710 146 660 120 Q620 150 570 118 Q520 140 480 112 Q440 138 390 110 Q350 132 300 108 Q250 128 210 104 Q160 124 120 100 Q70 118 0 96 Z" fill="url(#g)" opacity=".93"/>` +
      `<path d="M0 96 Q70 118 120 100 Q160 124 210 104 Q250 128 300 108 Q350 132 390 110 Q440 138 480 112 Q520 140 570 118 Q620 150 660 120 Q710 146 750 116 Q800 140 830 108 Q870 128 900 96" fill="none" stroke="#7d8fb8" stroke-width="3" opacity=".7"/></svg>`)}}`);
    css.push(`.hs-bolt{background-image:${uri(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 440" preserveAspectRatio="xMidYMax slice"><g fill="none" stroke-linejoin="round" stroke-linecap="round">` +
      `<path d="M120 108 L100 160 L116 164 L92 216 L108 219 L86 306" stroke="#c9b8ff" stroke-width="20" opacity=".45"/><path d="M120 108 L100 160 L116 164 L92 216 L108 219 L86 306" stroke="#ffffff" stroke-width="6"/><path d="M100 160 L80 178 M92 216 L74 226" stroke="#fff" stroke-width="2.6" opacity=".9"/>` +
      `<path d="M832 104 L816 146 L830 150 L810 196 L822 198 L806 232" stroke="#c9b8ff" stroke-width="14" opacity=".35"/><path d="M832 104 L816 146 L830 150 L810 196 L822 198 L806 232" stroke="#ffffff" stroke-width="4"/></g></svg>`)}}`);
    const st = document.createElement("style"); st.textContent = css.join("\n"); document.head.appendChild(st);
    const fl = document.createElement("div"); fl.className = "flash hs-flash"; $("tWrap").insertBefore(fl, $("tScene"));
  })();
  document.addEventListener("visibilitychange", () => body.classList.toggle("paused", document.hidden));
  if (MOCK && params.get("still") === "1") body.classList.add("still");   // mock-only: freeze motion for static screenshots

  /* ---------------- clock ---------------- */
  let lastDateMin = -1;
  function tickClock() {
    const d = new Date(nowMs());
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", second: "2-digit", hour12: !h24 }).formatToParts(d);
    let h = "", m = "", sec = "", ap = "";
    parts.forEach((p) => { if (p.type === "hour") h = p.value; else if (p.type === "minute") m = p.value; else if (p.type === "second") sec = p.value; else if (p.type === "dayPeriod") ap = p.value; });
    if (h24 && h === "24") h = "00";
    setText("clock", h + ":" + m); setText("clockSec", ":" + sec); setText("ampm", ap);
    const minKey = Math.floor(d.getTime() / 60000);
    if (minKey !== lastDateMin) { lastDateMin = minKey; setText("date", new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric" }).format(d)); }
  }
  function clockLoop() { tickClock(); setTimeout(clockLoop, 1000 - (Date.now() % 1000) + 15); }

  /* ---------------- mock-only test values (same as Industrial) ---------------- */
  function applyMockOverrides(d) {
    if (!MOCK || !d) return d;
    d = JSON.parse(JSON.stringify(d));
    const F = d.forecast || {}, N = F.now || {};
    if (params.has("fc_until")) N.until = params.get("fc_until");
    if (params.has("fc_temp")) N.temp = parseFloat(params.get("fc_temp"));
    if (params.has("fc_wind")) N.wind = parseFloat(params.get("fc_wind"));
    if (params.has("fc_dir")) N.wind_dir = params.get("fc_dir");
    if (params.has("fc_icon")) N.icon = params.get("fc_icon");
    const M = (d.astro && d.astro.moon) || {};
    if (params.has("moon_illum")) M.illumination = parseFloat(params.get("moon_illum"));
    if (params.has("moon_waxing")) M.waxing = params.get("moon_waxing") === "1";
    if (params.has("moon_name")) M.name = params.get("moon_name");
    if (params.has("moon_set")) M.set = null;
    if (params.has("temp") && d.temp) {
      const raw = params.get("temp"), v = raw === "none" || raw === "" ? null : parseFloat(raw);
      d.temp.now = isNum(v) ? v : null;
      if (isNum(v)) { d.temp.feels = v; d.temp.high = Object.assign({}, d.temp.high, { value: Math.max(v, (d.temp.high || {}).value ?? v) }); d.temp.low = Object.assign({}, d.temp.low, { value: Math.min(v, (d.temp.low || {}).value ?? v) }); }
    }
    if (params.get("tunit") === "c" && d.temp) {
      const c = (f) => (isNum(f) ? Math.round((f - 32) / 1.8 * 10) / 10 : f), t = d.temp;
      t.now = c(t.now); t.feels = c(t.feels); t.dew = c(t.dew);
      if (t.high) t.high.value = c(t.high.value); if (t.low) t.low.value = c(t.low.value);
      d.units = Object.assign({}, d.units, { temp: "\u00B0C" });
    }
    if (MOCK_TIME) {   // shift the demo data to the overridden clock
      const off = OFFSET / 1000, A = d.astro || {}, now = nowS();
      const isDay = (t) => isNum(A.sunrise) && isNum(A.sunset) ? t >= A.sunrise && t < A.sunset : true;
      const dn = (ic, t) => String(ic || "").replace(isDay(t) ? "-night" : "-day", isDay(t) ? "-day" : "-night");
      ["obs_time", "server_time"].forEach((k) => { if (isNum(d[k])) d[k] += off; });
      const L = d.lightning || {};
      if (isNum(L.last_epoch)) L.last_epoch += off;
      if (Array.isArray(L.hourly)) L.hourly.forEach((b) => { if (isNum(b.time)) b.time += off; });
      const start = Math.ceil(now / 3600) * 3600;
      (F.hourly || []).forEach((h, i) => { h.time = start + i * 3600; h.icon = dn(h.icon, h.time); });
      if (N.icon) N.icon = dn(N.icon, now);
      A.is_day = isDay(now);
    }
    return d;
  }

  /* ---------------- render ---------------- */
  let DEMO_RAW = false;   // mock-only hook used by the animation recording: window.__wxdemo(fn) re-renders with edited data
  if (MOCK) window.__wxdemo = (fn) => { const d = JSON.parse(JSON.stringify(DATA)); fn(d); DEMO_RAW = true; render(d); };
  /* 1.5.8: the "Feeling …" chip uses the Menu > Feels-like labels cut-offs (static/feel.js); the server's text until they load */
  function paintComfort() {
    const T = (DATA && DATA.temp) || {};
    const c = (window.WXFeel && WXFeel.label(T.feels, ((DATA && DATA.units) || {}).temp)) || T.comfort;
    setText("comfort", c || "--"); $("comfort").classList.toggle("hidden", !c);
  }
  function render(d) {
    d = DEMO_RAW ? d : applyMockOverrides(d); DEMO_RAW = false;
    DATA = d;
    tz = (d.station && d.station.tz) || tz;
    h24 = d.station && d.station.time_format === "24";
    const U = d.units || {};
    const T = d.temp || {}, W = d.wind || {}, P = d.pressure || {}, R = d.rain || {}, H = d.humidity || {};
    const F = d.forecast || {}, FN = F.now || {}, FT = F.today || {}, A = d.astro || {}, M = A.moon || {};
    const hasData = isNum(d.obs_time);
    setText("stationName", (d.station && d.station.name) || "Weather Station");
    document.title = ((d.station && d.station.name) || "Weather") + " \u2014 " + fx(T.now) + "°";
    updateStatus();

    // hero
    const heroIcon = FN.icon || (hasData ? (A.is_day === false ? "clear-night" : "clear-day") : "cloudy");
    if ($("heroIcon").dataset.icon !== heroIcon) { $("heroIcon").innerHTML = wicon(heroIcon); $("heroIcon").dataset.icon = heroIcon; }
    setText("heroCond", FN.conditions || (hasData ? "Observed" : "--"));
    paintComfort();
    setArrow("trendArrow", T.trend); setText("trendVal", isNum(T.trend) ? signed(T.trend) + "°" : "--");
    setArrow("diffArrow", T.diff24, 0.5); setText("diffVal", isNum(T.diff24) ? signed(T.diff24) + "°" : "--");
    setText("feels", isNum(T.feels) ? fx(T.feels) + "°" : "--");
    setText("dewHero", isNum(T.dew) ? fx(T.dew) + "°" : "--");
    setText("humHero", isNum(H.now) ? fi(H.now) + "%" : "--");
    renderHero(T, U);

    // wind
    setText("windDesc", W.description || (W.calm ? "Calm" : "--"));
    setWind(W.speed, W.dir, W.dir_cardinal || (W.calm ? null : W.cardinal), W.cardinal, !!W.calm, U.wind || "mph", W.gust);
    setHTML("windAvg", isNum(W.avg_today) ? `${fx(W.avg_today)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setHTML("windGust", isNum(W.gust_max) ? `${fx(W.gust_max)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setText("gustNow", isNum(W.gust) ? fx(W.gust) : "--");

    // barometer
    setText("baroVal", isNum(P.slp) ? fx(P.slp, U.pressure === "inHg" ? 2 : 1) : "--");
    setText("baroUnit", U.pressure || "mb");
    setText("baroTrendText", P.trend_text || "--");
    setArrow("baroArrow", P.trend, 0.3);
    setText("baroTrend", isNum(P.trend) ? `${signed(P.trend)} ${U.pressure}/hr` : "--");
    setText("baroTendency", P.tendency || "--");
    setText("baroLow", P.low && isNum(P.low.value) ? fx(P.low.value) : "--");
    setText("baroHigh", P.high && isNum(P.high.value) ? fx(P.high.value) : "--");
    setText("baroLowT", P.low ? fmtTime(P.low.time) : "");
    setText("baroHighT", P.high ? fmtTime(P.high.time) : "");
    setBaro(P);

    // moon & sun
    const moonSig = `${M.illumination}|${M.waxing}`;
    if ($("moonSvg").dataset.sig !== moonSig) { $("moonSvg").innerHTML = moonArt(M.illumination, M.waxing); $("moonSvg").dataset.sig = moonSig; }
    setText("moonName", M.name || "--");
    setText("moonIllum", isNum(M.illumination) ? M.illumination + "% lit" : "--");
    setText("moonRise", fmtTime(M.rise)); setText("moonSet", fmtTime(M.set));
    setText("nextNew", fmtDay(M.next_new)); setText("nextFull", fmtDay(M.next_full));
    setText("sunRise", fmtTime(A.sunrise)); setText("sunSet", fmtTime(A.sunset));

    // humidity / uv / solar
    setText("humVal", fi(H.now));
    humK = isNum(H.now) ? clamp01(H.now / 100) : 0; placeHum();
    $("humPin").style.opacity = isNum(H.now) ? "1" : "0";
    setText("humDesc", humText(H.now, T.dew, U.temp));
    const uv = d.solar && d.solar.uv;
    setHTML("uv", isNum(uv) ? `${fx(uv)} <span class="unit">${uvText(uv)}</span>` : "--");
    const lit = isNum(uv) ? Math.max(1, Math.min(11, Math.round(uv))) : 0;
    document.querySelectorAll("#uvGlyphs .uvg").forEach((g) => g.classList.toggle("on", +g.dataset.i < lit));
    const rad = d.solar && d.solar.radiation;
    setHTML("solar", isNum(rad) ? `${fi(rad)}<span class="unit">W/m²</span>` : "--");

    // rain: frosted jars
    const pu = U.precip || "in", dec = pu === "mm" ? 1 : 2;
    const scales = pu === "mm" ? { today: 25, yesterday: 25, month: 125, year: 600 } : { today: 1, yesterday: 1, month: 5, year: 25 };
    document.querySelectorAll("#rainBars .pot").forEach((el) => {
      const k = el.dataset.k, v = R[k];
      const txt = isNum(v) ? (k === "year" && pu === "in" ? v.toFixed(1) : v.toFixed(dec)) : "--";
      const rv = el.querySelector(".rv");
      if (rv.dataset.v !== txt) { rv.dataset.v = txt; rv.innerHTML = esc(txt) + (isNum(v) ? `<span class="ru">${pu === "in" ? "\u2033" : " mm"}</span>` : ""); }
      const pct = isNum(v) ? Math.min(1, v / Math.max(scales[k], v)) : 0;
      const lev = v > 0 ? Math.max(0.05, pct) : 0;
      el.querySelector(".water").style.transform = `scaleY(${lev.toFixed(3)})`;
      const cube = el.querySelector(".cube");   // ice cube floats on the water surface (water spans y 24-104)
      cube.style.transform = `translateY(${f1(104 - lev * 80 - 23)}px)`; cube.style.opacity = lev > 0 ? "1" : "0";
    });
    setText("rainText", R.rate_text || "--");
    setText("rainRate", isNum(R.rate) ? `${fx(R.rate, dec)} ${U.rate || "in/hr"}` : "--");

    // forecast
    setText("fcUntil", FN.until || FN.conditions || "--");
    const fci = FN.icon || "cloudy";
    if ($("fcIcon").dataset.icon !== fci) { $("fcIcon").innerHTML = wicon(fci); $("fcIcon").dataset.icon = fci; }
    setText("fcTemp", isNum(FN.temp) ? fi(FN.temp) + "°" : "--");
    setText("fcLow", isNum(FT.low) ? fi(FT.low) + "°" : "--");
    setText("fcHigh", isNum(FT.high) ? fi(FT.high) + "°" : "--");
    const rainPct = isNum(FT.precip) ? FT.precip : FN.precip;
    setPct("fcRainPill", rainPct, "--");
    setText("fcWind", isNum(FN.wind) ? `${fi(FN.wind)} ${U.wind} ${FN.wind_dir || ""}`.trim() : "--");
    const DL = Array.isArray(F.daily) ? F.daily : [];
    const tmKey = dayKey(nowS() + 86400);
    const TM = DL.find((x) => x && isNum(x.time) && dayKey(x.time + 3600) === tmKey) || DL.find((x) => x && isNum(x.time) && x.time > nowS()) || null;
    $("fcTm").classList.toggle("empty", !TM);
    if (TM) {
      const tmi = String(TM.icon || "cloudy").replace("-night", "-day");
      if ($("fcTmIcon").dataset.icon !== tmi) { $("fcTmIcon").innerHTML = wicon(tmi); $("fcTmIcon").dataset.icon = tmi; }
      setText("fcTmDay", "Tomorrow \u00b7 " + new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(new Date((TM.time + 3600) * 1000)));
      setText("fcTmCond", TM.conditions || "--");
      setText("fcTmHigh", isNum(TM.high) ? fi(TM.high) + "°" : "--");
      setText("fcTmLow", isNum(TM.low) ? fi(TM.low) + "°" : "--");
      setPct("fcTmRain", TM.precip, "");
    } else {
      setText("fcTmDay", "Tomorrow"); setText("fcTmCond", "Forecast unavailable");
      setText("fcTmHigh", "--"); setText("fcTmLow", "--"); setPct("fcTmRain", null, "");
      $("fcTmIcon").innerHTML = ""; $("fcTmIcon").dataset.icon = "";
    }

    fitAll();
    renderHourly(F.hourly || []);
    renderLightning(d.lightning || {}, U);
    updateStrikeBadge();
    if (openPanel) showPanel(openPanel, true);
  }

  /* ---------------- status / live / strike badge ---------------- */
  function updateStatus() {
    const d = DATA, pill = $("statusPill");
    let cls = "loading", txt = "Connecting…";
    if (serverDown) { cls = "error"; txt = "Dashboard server unreachable" + (lastFetchOk ? " · showing data from " + ago(lastFetchOk / 1000 + OFFSET / 1000) : ""); }
    else if (d) {
      if (d.mock) { cls = "mock"; txt = "Demo data"; }
      else if (d.status === "ok") { cls = "ok"; txt = "Live · updated " + ago(d.obs_time); }
      else if (d.status === "stale") { cls = "stale"; txt = "Stale · last obs " + ago(d.obs_time) + (d.error ? " · " + d.error : ""); }
      else if (d.status === "loading") { cls = "loading"; txt = d.error || "Loading…"; }
      else { cls = "error"; txt = "Offline · " + (d.error || "no data"); }
    }
    pill.className = "status " + cls; setText("statusText", txt);
    const noData = !d || !isNum(d.obs_time), showErr = noData && (serverDown || (d && d.status === "error"));
    $("errorState").classList.toggle("hidden", !showErr);
    body.classList.toggle("has-error", cls === "error" || cls === "stale");
    if (showErr) setText("errorMsg", serverDown ? "The wxdash server on this Pi is not responding." : (d && d.error) || "Unknown error");
  }
  function updateStrikeBadge() {
    const L = (DATA && DATA.lightning) || {}, b = $("strikeBadge");
    const recent = lightningActive(L), red = recent && strikeRecentRed(L);
    b.classList.toggle("on", recent); b.classList.toggle("near", red);
    setLamp(b.querySelector(".lamp"), recent ? (red ? "red" : "amber") : "", recent);
    if (DATA) renderLightningTick();
    setText("strikeText", recent ? `\u26A1 ${fi(L.last_distance)} ${(DATA.units && DATA.units.distance) || "mi"} \u00b7 ${ago(L.last_epoch)}` : "No strikes");
  }
  function renderLightningTick() {
    const L = (DATA && DATA.lightning) || {}, active = lightningActive(L);
    if ($("ltCard").classList.contains("active") !== active || $("ltCard").classList.contains("near") !== (active && strikeRecentRed(L))) renderLightning(L, DATA.units || {});
    else if (isNum(L.last_epoch)) { setText("ltAgo", ago(L.last_epoch)); setText("ltWhen", strikeWhen(L.last_epoch)); }
  }
  function updateLive() {
    const el = $("livePill");
    let cls = "off", txt = "Polling", title = "Live stream not connected; refreshing every 15 s";
    if (sseOpen && (wsState === "connected" || demoLive)) { cls = "on"; txt = "Live"; title = demoLive ? "Simulated live feed (demo)" : "WeatherFlow live feed connected"; }
    else if (sseOpen && wsState === "connecting") { cls = "wait"; txt = "Reconnecting"; title = "WeatherFlow live feed reconnecting; using REST updates"; }
    el.className = "ind live " + cls;
    setLamp(el.querySelector(".lamp"), cls === "on" ? "green" : cls === "wait" ? "amber" : "", cls === "wait");
    el.title = title; setText("liveText", txt);
  }

  /* ---------------- theme picker (saved on the Pi via POST /api/settings) ---------------- */
  const THEME = "arctic";
  const THEMES = [["classic", "Classic"], ["industrial", "Industrial"], ["desert", "Desert"], ["arctic", "Arctic"], ["redwoods", "Redwoods"], ["nixie", "Nixie"]];
  let themeMsg = "";
  function themeHTML() {
    return `<div class="theme-pick"><div class="label">Theme</div><div class="theme-btns">` +
      THEMES.map(([k, n]) => `<button data-act="theme" data-theme="${k}" class="${k === THEME ? "on" : ""}" aria-pressed="${k === THEME}">` +
        `<span class="tn">${n}</span><span class="cur">${k === THEME ? "\u2713 Current" : "Tap to switch"}</span></button>`).join("") +
      `</div>${themeMsg ? `<div class="theme-msg">${esc(themeMsg)}</div>` : ""}</div>`;
  }
  function urlWithoutTheme() { const u = new URL(location.href); u.searchParams.delete("theme"); u.searchParams.delete("panel"); return u.toString(); }
  async function setTheme(t) {
    if (!t || t === THEME) { closePanel(); return; }
    themeMsg = "Switching\u2026"; showPanel("menu", true);
    try {
      const r = await fetch("/api/settings", { method: "POST", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ theme: t }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      location.replace(urlWithoutTheme());
    } catch (e) { themeMsg = "Couldn't switch theme: " + (e.message || e); showPanel("menu", true); }
  }
  // Another screen switched the theme: follow it (not for ?theme= previews).
  function onSettings(s) { if (s && s.feel && window.WXFeel) WXFeel.sync(s.feel); if (s && s.theme && s.theme !== THEME && !params.get("theme")) location.replace(urlWithoutTheme()); }
  fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()).then((s) => {
    if (s && s.saved === false) themeMsg = "Theme not saved on the Pi (run install.sh once); it resets when wxdash restarts.";
  }).catch(() => {});

  /* ---------------- overlays ---------------- */
  function showPanel(name, refresh) {
    const d = DATA || {}, U = d.units || {};
    let html = "";
    if (name === "sager") {
      const S = d.sager, P = d.pressure || {};
      html = `<h3>Sager-style outlook</h3><div class="lead">Barometric forecast for the next 12–24 hours</div>
        <div class="big">${esc(S ? S.outlook : "Not enough pressure history yet")}</div>
        <div class="grid3"><div><div class="label">Sea-level pressure</div><div class="v">${fx(P.slp)} <small>${esc(U.pressure)}</small></div></div>
        <div><div class="label">3-hour trend</div><div class="v">${signed(P.trend)} <small>${esc(U.pressure)}/hr</small></div></div>
        <div><div class="label">Tendency</div><div class="v sm">${esc(P.trend_text || "--")}</div></div></div>
        <div class="note">Computed on this Pi with the Zambretti barometer method (pressure, 3-hour trend and season).${P.tendency ? " Barometer tendency: " + esc(P.tendency) + "." : ""}</div>`;
    } else if (name === "menu") {
      const s = d.station || {};
      html = `<h3>${esc(s.name || "Weather Station")}</h3><div class="lead">Station ${esc(s.id || "--")} · Tempest ${esc(s.device || "--")} · ${isNum(s.lat) ? s.lat.toFixed(4) + ", " + s.lon.toFixed(4) : ""}</div>
        <div class="grid3"><div><div class="label">Data</div><div class="v sm">${esc(d.mock ? "Demo" : d.status || "--")}</div></div>
        <div><div class="label">Last observation</div><div class="v sm">${esc(fmtTime(d.obs_time))}</div></div>
        <div><div class="label">Version</div><div class="v sm">wxdash ${esc(d.version || "")}</div></div></div>
        ${d.error ? `<div class="note">${esc(d.error)}</div>` : ""}
        ${themeHTML()}
        <div class="rowbtn"><button data-act="refresh">Refresh now</button><button data-act="reload">Reload page</button>
        <button data-act="lite">${body.classList.contains("lite") ? "Lite mode: on" : "Lite mode: off"}</button>
        ${window.WXFeel ? WXFeel.menuButton() : ""}<button data-act="cursor">${body.classList.contains("show-cursor") ? "Hide cursor" : "Show cursor"}</button></div>`;
    } else if (name === "feel" && window.WXFeel) {
      html = WXFeel.panelHTML(d);
    }
    if (!html) return;
    if (refresh && $("overlayBody").dataset.panel === name && $("overlayBody").innerHTML === html) return;
    $("overlayBody").innerHTML = html; $("overlayBody").dataset.panel = name;
    $("overlayBody").parentNode.classList.toggle("sheet-feel", name === "feel");
    $("overlay").classList.remove("hidden"); openPanel = name;
    if (!refresh) { clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000); }
  }
  function closePanel() { $("overlay").classList.add("hidden"); openPanel = null; clearTimeout(overlayTimer); }
  document.querySelectorAll("[data-panel]").forEach((b) => b.addEventListener("click", () => showPanel(b.dataset.panel)));
  $("strikeBadge").addEventListener("click", () => { flashCard($("ltCard")); });
  if (window.WXFeel) WXFeel.init({ show: (n) => showPanel(n),
    changed: () => { paintComfort(); if (openPanel === "feel" || openPanel === "menu") showPanel(openPanel, true); } });
  $("overlayClose").addEventListener("click", closePanel);
  $("overlay").addEventListener("click", (e) => { if (e.target === $("overlay")) closePanel(); });
  $("overlayBody").addEventListener("click", (e) => {
    const btn = e.target && e.target.closest ? e.target.closest("[data-act]") : null, act = btn && btn.dataset.act;
    if (act && act.indexOf("feel-") === 0 && window.WXFeel) {   // Feels-like labels editor: keep the sheet open while tapping
      clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000);
      WXFeel.act(act, btn); return;
    }
    if (act === "theme") setTheme(btn.dataset.theme);
    else if (act === "refresh") { load(); closePanel(); }
    else if (act === "reload") location.reload();
    else if (act === "lite") { body.classList.toggle("lite"); localStorage.setItem("wxdash-lite", body.classList.contains("lite") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "cursor") { body.classList.toggle("show-cursor"); localStorage.setItem("wxdash-cursor", body.classList.contains("show-cursor") ? "1" : "0"); showPanel("menu", true); }
  });

  /* ---------------- polling / live stream ---------------- */
  function dataQuery() {
    const q = new URLSearchParams();
    if (MOCK) q.set("mock", "1");
    if (params.get("lightning")) q.set("lightning", params.get("lightning"));
    const qs = q.toString(); return qs ? "?" + qs : "";
  }
  function startStream() {
    if (!window.EventSource || params.get("stream") === "0") return;
    try { sse = new EventSource("/api/stream" + dataQuery()); } catch (e) { return; }
    const ok = () => { if (!sseOpen) { sseOpen = true; updateLive(); } };
    const parse = (ev, fn) => { try { fn(JSON.parse(ev.data)); ok(); } catch (e) { /* ignore bad event */ } };
    sse.addEventListener("open", ok);
    sse.addEventListener("error", () => { sseOpen = false; updateLive(); });
    sse.addEventListener("data", (ev) => parse(ev, (d) => { serverDown = false; lastFetchOk = Date.now(); render(d); }));
    sse.addEventListener("wind", (ev) => parse(ev, onRapidWind));
    sse.addEventListener("strike", (ev) => parse(ev, onStrike));
    sse.addEventListener("settings", (ev) => parse(ev, onSettings));
    sse.addEventListener("live", (ev) => parse(ev, (l) => { wsState = l.ws || "off"; demoLive = !!l.demo; updateLive(); }));
  }
  async function load() {
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch("/api/data" + dataQuery(), { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const d = await r.json();
      serverDown = false; lastFetchOk = Date.now();
      if (d.live) { wsState = d.live.ws || "off"; demoLive = !!d.live.demo; }
      render(d); updateLive();
    } catch (e) { serverDown = true; updateStatus(); }
  }

  /* ---------------- night mode (8 PM - 6 AM): polar night, aurora takes over ---------------- */
  const NIGHT_FORCE = MOCK && params.has("night") ? params.get("night") === "1" : null;
  function localHour() {
    try { return +new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hourCycle: "h23" }).format(new Date(nowMs())) % 24; }
    catch (e) { return new Date(nowMs()).getHours(); }
  }
  function isNightHour() { if (NIGHT_FORCE !== null) return NIGHT_FORCE; const h = localHour(); return h >= 20 || h < 6; }
  function updateNight() { body.classList.toggle("night", isNightHour()); }
  updateNight();
  setInterval(updateNight, 60000);
  clockLoop();
  setInterval(() => { updateStatus(); if (DATA) updateStrikeBadge(); }, 5000);
  load().then(() => { const p = params.get("panel"); if (p) showPanel(p); startStream(); });
  setInterval(() => { if (!sseOpen || Date.now() - lastFetchOk > 60000) load(); }, POLL_MS);
  let loadedVersion = null;
  async function checkVersion() {
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 8000);
      const r = await fetch("/api/health", { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) return;
      const h = await r.json();
      if (!h || !h.ok || typeof h.version !== "string" || !h.version) return;
      if (loadedVersion === null) loadedVersion = h.version;
      else if (h.version !== loadedVersion) location.reload();
      else if (h.theme && h.theme !== THEME) onSettings({ theme: h.theme });   // backup if the SSE event was missed
    } catch (e) { /* server restarting or down */ }
  }
  checkVersion();
  setInterval(checkVersion, 60000);
  setInterval(() => { const h = new Date().getHours(), m = new Date().getMinutes(); if (h === 3 && m === 30) location.reload(); }, 60000);
})();
