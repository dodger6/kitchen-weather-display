/* wxdash front-end — INDUSTRIAL theme test build. Vanilla JS, no dependencies, works offline. */
(function () {
  "use strict";
  const POLL_MS = 15000;
  const params = new URLSearchParams(location.search);
  const MOCK = params.get("mock") === "1";
  const $ = (id) => document.getElementById(id);
  const body = document.body;
  let DATA = null;
  let lastFetchOk = 0;
  let serverDown = false;
  let tz = "America/Los_Angeles";
  let h24 = false;
  let needleAngle = null;
  let overlayTimer = null;
  let openPanel = null;
  let sse = null, sseOpen = false, wsState = "off", demoLive = false;
  let windShown = null, windAnim = 0;

  // Smooth mode is the default (no backdrop blur, static background) because the Pi 5's
  // GPU re-blurs every glass card on every frame. ?glass=1 (or the menu) restores the
  // frosted glass + drifting background; ?glass=0 turns it back off. ?lite=1 is the
  // most minimal look (opaque cards, no wind-number tween).
  if (params.has("glass")) localStorage.setItem("wxdash-glass", params.get("glass") === "0" ? "0" : "1");
  if (localStorage.getItem("wxdash-glass") === "1") body.classList.add("glass");
  if (params.get("lite") === "1" || localStorage.getItem("wxdash-lite") === "1") body.classList.add("lite");
  if (params.get("cursor") === "1" || localStorage.getItem("wxdash-cursor") === "1") body.classList.add("show-cursor");

  /* ---------------- formatting ---------------- */
  const isNum = (v) => typeof v === "number" && isFinite(v);
  const fx = (v, d = 1) => (isNum(v) ? v.toFixed(d) : "--");
  const fi = (v) => (isNum(v) ? Math.round(v).toString() : "--");
  function signed(v, d = 1) {
    if (!isNum(v)) return "--";
    const s = Math.abs(v).toFixed(d);
    return (v > 0 ? "+" : v < 0 ? "\u2212" : "") + s;
  }
  function fmtTime(ts, opts) {
    if (!isNum(ts)) return "--";
    return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: tz, hour: "numeric", minute: "2-digit", hour12: !h24 }, opts || {})).format(new Date(ts * 1000));
  }
  function fmtHour(ts) {
    if (!isNum(ts)) return "--";
    if (h24) return fmtTime(ts, { minute: "2-digit" });
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hour12: true }).format(new Date(ts * 1000)).replace(" ", "\u2009");
  }
  function dayKey(ts) {
    return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(ts * 1000));
  }
  function fmtDay(ts) {
    if (!isNum(ts)) return "--";
    const now = Date.now() / 1000;
    if (dayKey(ts) === dayKey(now)) return "Today";
    if (dayKey(ts) === dayKey(now + 86400)) return "Tomorrow";
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000));
  }
  function ago(ts) {
    if (!isNum(ts)) return "--";
    const s = Math.max(0, Date.now() / 1000 - ts);
    if (s < 90) return Math.round(s) + "s ago";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " hr ago";
    return Math.round(s / 86400) + " days ago";
  }
  function setText(id, txt) { const el = $(id); if (el && el.textContent !== txt) el.textContent = txt; }
  function setHTML(id, html) { const el = $(id); if (el && el.innerHTML !== html) el.innerHTML = html; }
  function arrowFor(v, eps) {
    eps = eps || 0.05;
    if (!isNum(v)) return ["", ""];
    if (v > eps) return ["\u25B2", "up"];
    if (v < -eps) return ["\u25BC", "down"];
    return ["\u25B6", "flat"];
  }
  function setArrow(id, v, eps) {
    const [ch, cls] = arrowFor(v, eps);
    const el = $(id); el.textContent = ch; el.setAttribute("class", "arrow " + cls);
  }
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  /* ---------------- icons (inline SVG, viewBox 64) ---------------- */
  const DEFS = `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
    <radialGradient id="gSunGlow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffb000" stop-opacity=".95"/><stop offset=".5" stop-color="#ffb000" stop-opacity=".55"/><stop offset=".75" stop-color="#ffb000" stop-opacity=".16"/><stop offset="1" stop-color="#ffb000" stop-opacity="0"/></radialGradient>
    <linearGradient id="gCloud" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eef0f2"/><stop offset="1" stop-color="#a9b0b8"/></linearGradient>
    <linearGradient id="gCloudD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9ba2aa"/><stop offset="1" stop-color="#5d646c"/></linearGradient>
    <linearGradient id="gMoonI" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3d6"/><stop offset="1" stop-color="#d9c9a6"/></linearGradient>
    <radialGradient id="gMoonLit" cx=".45" cy=".4" r=".65"><stop offset="0" stop-color="#fffdf2"/><stop offset=".7" stop-color="#ecebe0"/><stop offset="1" stop-color="#c9cbd6"/></radialGradient>
    <radialGradient id="gMoonDark" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#2a2b2d"/><stop offset="1" stop-color="#151617"/></radialGradient>
  </defs></svg>`;
  document.body.insertAdjacentHTML("afterbegin", DEFS);

  const CLOUD = "M18 48h29a9.5 9.5 0 0 0 .8-19 13.5 13.5 0 0 0-25.8-3.4A10.5 10.5 0 0 0 18 48z";
  /* Sun: the exact drawing from the Home Assistant willows-weather-card (viewBox 120,
     colour #ffb000). The HA card animates a drop-shadow filter, which repaints every
     frame; here the glow is a pre-blurred radial-gradient circle (gSunGlow) behind the
     core, and only its opacity/transform animate, so the Pi just composites it. */
  const SUN_BODY = `<circle class="sun-glow" cx="60" cy="60" r="34" fill="url(#gSunGlow)"/>` +
    `<circle class="sun-core" cx="60" cy="60" r="18" fill="#ffb000"/>` +
    `<g class="sun-rays" stroke="#ffb000" stroke-width="4" stroke-linecap="round">` +
    `<line x1="60" y1="18" x2="60" y2="8"/><line x1="60" y1="112" x2="60" y2="102"/>` +
    `<line x1="18" y1="60" x2="8" y2="60"/><line x1="112" y1="60" x2="102" y2="60"/>` +
    `<line x1="30" y1="30" x2="22" y2="22"/><line x1="90" y1="90" x2="98" y2="98"/>` +
    `<line x1="90" y1="30" x2="98" y2="22"/><line x1="30" y1="90" x2="22" y2="98"/></g>`;
  // A sun inside a 64-unit icon: a nested 120-unit viewport, so transform-box:view-box
  // pivots on the sun's own centre (60,60) exactly like the HA card.
  function sun(x, y, size) {
    return `<svg class="wi-sun" x="${x}" y="${y}" width="${size}" height="${size}" viewBox="0 0 120 120" overflow="visible">${SUN_BODY}</svg>`;
  }
  function moonIcon(tx, ty, s) {
    return `<g transform="translate(${tx} ${ty}) scale(${s})"><path d="M38 10a22 22 0 1 0 17 34A18 18 0 0 1 38 10z" fill="url(#gMoonI)"/><circle cx="20" cy="18" r="1.4" fill="#fff" opacity=".9"/><circle cx="12" cy="30" r="1" fill="#fff" opacity=".7"/></g>`;
  }
  function cloud(tx, ty, s, dark) {
    return `<g class="wi-cloud"><path transform="translate(${tx} ${ty}) scale(${s})" d="${CLOUD}" fill="url(#${dark ? "gCloudD" : "gCloud"})"/></g>`;
  }
  function drops(n, color) {
    const xs = n === 2 ? [26, 38] : [22, 32, 42];
    return `<g stroke="${color || "#4fd3ff"}" stroke-width="3" stroke-linecap="round">${xs.map((x) => `<line class="wi-drop" x1="${x}" y1="50" x2="${x - 2}" y2="55"/>`).join("")}</g>`;
  }
  function flakes() {
    return `<g fill="#fff">${[22, 32, 42].map((x) => `<circle class="wi-flake" cx="${x}" cy="52" r="2.4"/>`).join("")}</g>`;
  }
  function bolt() { return `<path class="wi-bolt" d="M34 40 26 53h6l-3 9 10-14h-6l3-8z" fill="#ffc21a" stroke="#7a4a00" stroke-width="1" stroke-linejoin="round"/>`; }
  function wicon(name) {
    const n = String(name || "cloudy");
    const night = n.indexOf("night") >= 0;
    const small = night ? moonIcon(4, 2, 0.55) : sun(2, 0, 40);
    let g = "";
    if (n.startsWith("clear") && !night) return `<svg viewBox="0 0 120 120" class="cond-svg wi-sun" aria-hidden="true">${SUN_BODY}</svg>`;
    if (n.startsWith("clear")) g = moonIcon(6, 4, 1);
    else if (n.startsWith("partly-cloudy")) g = small + cloud(4, 6, 0.95);
    else if (n === "cloudy") g = cloud(-6, -6, 0.8, true) + cloud(4, 4, 0.95);
    else if (n === "foggy") g = cloud(2, -4, 0.95) + `<g class="wi-fog" stroke="#e2e8f0" stroke-width="3" stroke-linecap="round"><line x1="12" y1="50" x2="46" y2="50"/><line x1="20" y1="57" x2="54" y2="57"/></g>`;
    else if (n.startsWith("possibly-rainy")) g = small + cloud(4, -2, 0.95) + drops(2);
    else if (n === "rainy") g = cloud(2, -6, 0.95, true) + drops(3);
    else if (n.indexOf("sleet") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -6, 0.95, true) + drops(2, "#bae6fd") + `<circle class="wi-flake" cx="32" cy="54" r="2.2" fill="#fff"/>`;
    else if (n.indexOf("snow") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -6, 0.95) + flakes();
    else if (n.indexOf("thunderstorm") >= 0) g = (n.startsWith("possibly") ? small : "") + cloud(2, -8, 0.95, true) + bolt();
    else if (n === "windy") g = `<g fill="none" stroke="#e0f2fe" stroke-width="3.5" stroke-linecap="round" class="wi-fog"><path d="M8 24h30a7 7 0 1 0-7-7"/><path d="M8 34h42a7 7 0 1 1-7 7"/><path d="M8 44h20"/></g>`;
    else g = cloud(2, 2, 0.95);
    return `<svg viewBox="0 0 64 64" aria-hidden="true">${g}</svg>`;
  }

  /* ---------------- moon phase art ---------------- */
  function moonArt(illumPct, waxing) {
    const k = Math.max(0, Math.min(1, (illumPct || 0) / 100));
    const r = 52, cx = 60, cy = 60, top = cy - r, bot = cy + r;
    let lit = "";
    if (k >= 0.995) lit = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonLit)"/>`;
    else if (k > 0.005) {
      const rx = (r * Math.abs(1 - 2 * k)).toFixed(2);
      const crescent = k < 0.5;
      let d;
      if (waxing) d = `M${cx} ${top} A${r} ${r} 0 0 1 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 0 : 1} ${cx} ${top}Z`;
      else d = `M${cx} ${top} A${r} ${r} 0 0 0 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 1 : 0} ${cx} ${top}Z`;
      lit = `<path d="${d}" fill="url(#gMoonLit)"/>`;
    }
    const craters = `<g fill="#000" opacity=".07"><circle cx="44" cy="40" r="9"/><circle cx="74" cy="50" r="6"/><circle cx="62" cy="80" r="11"/><circle cx="36" cy="70" r="5"/><circle cx="82" cy="78" r="4"/></g>`;
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonDark)" stroke="rgba(0,0,0,.6)" stroke-width="1.5"/>${lit}${craters}`;
  }

  /* ---------------- static gauge furniture (built once) ---------------- */
  // angles in degrees, clockwise from 12 o'clock
  const pol = (cx, cy, r, a) => [cx + Math.sin(a * Math.PI / 180) * r, cy - Math.cos(a * Math.PI / 180) * r];
  const f1 = (n) => n.toFixed(1);
  function arcD(cx, cy, r, a0, a1) {
    const [x0, y0] = pol(cx, cy, r, a0), [x1, y1] = pol(cx, cy, r, a1);
    return `M${f1(x0)} ${f1(y0)} A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${f1(x1)} ${f1(y1)}`;
  }
  function tickLines(cx, cy, list) {
    return list.map(([a, r1, r2, cls]) => { const [x1, y1] = pol(cx, cy, r1, a), [x2, y2] = pol(cx, cy, r2, a);
      return `<line${cls ? ` class="${cls}"` : ""} x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}"/>`; }).join("");
  }
  // temperature: 180-degree arc, hub (260,262)
  const TG = { cx: 260, cy: 262, a0: -90, a1: 90 };
  let tScaleUnit = null;
  function buildTempGauge(unit) {
    if (tScaleUnit === unit) return; tScaleUnit = unit;
    const S = TEMP_SCALES[unit], span = S.max - S.min, ang = (v) => TG.a0 + (v - S.min) / span * (TG.a1 - TG.a0);
    const ticks = [], labels = [];
    const step = unit === "c" ? 1 : 2, mid = unit === "c" ? 5 : 10;
    for (let v = S.min; v <= S.max + 1e-9; v += step) {
      const isMid = Math.abs(v % mid) < 1e-9;
      ticks.push([ang(v), isMid ? 200 : 210, 230, isMid ? "major" : ""]);
    }
    const lstep = unit === "c" ? 9 : 10;
    for (let v = S.min; v <= S.max + 1e-9; v += lstep) {
      const [x, y] = pol(TG.cx, TG.cy, 180, ang(v));
      labels.push(`<text x="${f1(x)}" y="${f1(y)}">${v}</text>`);
    }
    $("tTicks").innerHTML = tickLines(TG.cx, TG.cy, ticks);
    $("tLabels").innerHTML = labels.join("");
    const cols = ["#4b6bff", "#4a8dff", "#3fb2ff", "#38d4e6", "#3fdcae", "#63e07a", "#a8e65a", "#e8e050", "#ffd34d", "#ffb040", "#ff8a3d", "#ff5a3d", "#f0365a"];
    let rim = "";
    cols.forEach((c, i) => { rim += `<path d="${arcD(TG.cx, TG.cy, 238, TG.a0 + i * 180 / 13, TG.a0 + (i + 1) * 180 / 13 + .2)}" stroke="${c}" stroke-width="7" fill="none"/>`; });
    $("tRim").innerHTML = rim;
    $("tUnitTxt").textContent = unit === "c" ? "°C" : "°F";
  }
  (function buildCompass() {
    const t = [];
    for (let d = 0; d < 360; d += 5) {
      if (d % 90 === 0) continue;
      t.push([d, d % 30 === 0 ? 80 : d % 10 === 0 ? 86 : 90, 96, d % 30 === 0 ? "major" : ""]);
    }
    $("cTicks").innerHTML = tickLines(110, 110, t);
  })();
  // barometer: 270-degree dial, 950-1050 mb
  const BG = { a0: -135, a1: 135, min: 950, max: 1050 };
  const baroAng = (mb) => BG.a0 + (Math.max(BG.min, Math.min(BG.max, mb)) - BG.min) / (BG.max - BG.min) * (BG.a1 - BG.a0);
  (function buildBaro() {
    const t = [];
    for (let v = 950; v <= 1050; v += 2) t.push([baroAng(v), v % 10 === 0 ? 76 : 83, 92, v % 10 === 0 ? "major" : ""]);
    $("bTicks").innerHTML = tickLines(110, 110, t);
    $("bLabels").innerHTML = [950, 975, 1000, 1025, 1050].map((v) => { const [x, y] = pol(110, 110, 62, baroAng(v)); return `<text x="${f1(x)}" y="${f1(y)}">${v}</text>`; }).join("");
    const zones = [[950, 980, "#ff4b1f"], [980, 1000, "#ff9a1a"], [1000, 1020, "#e8d050"], [1020, 1040, "#63e07a"], [1040, 1050, "#4fd3ff"]];
    $("bZones").innerHTML = zones.map(([a, b, c]) => `<path d="${arcD(110, 110, 96.5, baroAng(a), baroAng(b))}" stroke="${c}" stroke-width="4.5" fill="none" opacity=".9"/>`).join("");
  })();

  /* ---------------- LED helpers ---------------- */
  // ghost segments: every digit position shows a dim "8" behind the lit value
  function ghostFor(s, minDigits) {
    let g = String(s).replace(/[0-9\-]/g, "8").replace(/[^8.:]/g, "8");
    const digits = (g.match(/8/g) || []).length;
    for (let i = digits; i < (minDigits || 0); i++) g = "8" + g;
    return g;
  }
  function setLed(litId, ghostId, txt, minDigits) {
    setText(litId, txt);
    if (ghostId) setText(ghostId, ghostFor(txt, minDigits));
  }
  // shrink a LED readout (font-size) until it fits its window
  function fitLed(led, box, pad) {
    if (!led || !box) return;
    led.style.fontSize = "";
    const avail = box.clientWidth - (pad || 0);
    if (!avail) return;
    let fs = parseFloat(getComputedStyle(led).fontSize);
    for (let i = 0; i < 30 && led.offsetWidth > avail && fs > 10; i++) { fs = Math.max(10, Math.floor(fs * Math.min(.97, avail / led.offsetWidth))); led.style.fontSize = fs + "px"; }
  }

  /* ---------------- clock ---------------- */
  let lastDateMin = -1;
  function tickClock() {
    const d = new Date();
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", second: "2-digit", hour12: !h24 }).formatToParts(d);
    let h = "", m = "", sec = "", ap = "";
    parts.forEach((p) => { if (p.type === "hour") h = p.value; else if (p.type === "minute") m = p.value; else if (p.type === "second") sec = p.value; else if (p.type === "dayPeriod") ap = p.value; });
    if (h24 && h === "24") h = "00";
    setText("clock", h + ":" + m); setText("clockSec", ":" + sec); setText("ampm", ap);
    const minKey = Math.floor(d.getTime() / 60000);
    if (minKey !== lastDateMin) {   // date only needs checking once a minute
      lastDateMin = minKey;
      setText("date", new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric" }).format(d));
    }
  }
  // re-arm on each whole second so the display never drifts from the real clock
  function clockLoop() { tickClock(); setTimeout(clockLoop, 1000 - (Date.now() % 1000) + 15); }

  /* ---------------- theme ---------------- */
  function pickTheme(d) {
    const icon = (d.forecast && d.forecast.now && d.forecast.now.icon) || "";
    const a = d.astro || {};
    const alt = a.sun_altitude;
    const night = a.is_day === false || icon.indexOf("night") >= 0 && a.is_day !== true;
    if (icon.indexOf("thunder") >= 0) return "storm";
    if (icon.indexOf("rain") >= 0 || icon.indexOf("sleet") >= 0) return "rain";
    if (icon.indexOf("snow") >= 0) return "snow";
    if (icon === "cloudy" || icon === "foggy") return night ? "cloudy-night" : "cloudy-day";
    if (isNum(alt) && alt > -6 && alt < 6) return "dusk";
    return night ? "night" : "clear-day";
  }

  /* ---------------- render ---------------- */
  /* Shrink the hero temperature until the full value (degree sign included)
     fits the temperature card. CSS cqi sizing gives the first guess; this
     corrects for font metrics and never grows past the CSS maximum. */
  function fitTemp() {
    const led = $("bigLed"), win = led && led.parentNode;
    if (!led || !win) return;
    const deg = $("tempDeg"), cs = getComputedStyle(win);
    fitLed(led, win, (deg ? deg.offsetWidth + parseFloat(getComputedStyle(deg).marginLeft) : 0) + parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight) + 2);
  }
  let fitRaf = 0;
  const refit = () => { cancelAnimationFrame(fitRaf); fitRaf = requestAnimationFrame(fitTemp); };
  window.addEventListener("resize", refit);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(refit);
  if (window.ResizeObserver) { const ro = new ResizeObserver(refit); const r0 = document.querySelector(".big-win"); if (r0) ro.observe(r0); }

  /* v1.1.5 forecast card: the condition line shrinks a little to stay on one line,
     otherwise it is clamped to 2 lines by CSS; the big temperature (and icon) are
     sized to whatever height/width is left in the .fc-body grid row, so they can
     never spill onto the L/H + wind line. */
  function fitForecast() {
    const until = $("fcUntil"), bodyEl = document.querySelector(".fc-body"), t = $("fcTemp"), ic = $("fcIcon");
    const row = document.querySelector(".fc-row");
    if (!until || !bodyEl || !t || !row) return;
    const card = bodyEl.parentNode, wind = $("fcWind");
    const key = [until.textContent, t.textContent, wind && wind.textContent, $("fcTm") && $("fcTm").textContent, card.clientWidth, card.clientHeight].join("|");
    if (key === fitForecast.key) return;          // nothing changed: skip the relayout (render runs on every live tick)
    fitForecast.key = key;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    until.style.fontSize = ""; row.style.fontSize = ""; t.style.fontSize = ""; row.classList.remove("tight");
    // 1. L/H + wind always on one line: shrink that line (down to 75%) if it is too wide.
    const rowBase = parseFloat(getComputedStyle(row).fontSize);
    for (let f = rowBase; row.scrollWidth > row.clientWidth + 0.5 && f > rowBase * 0.75; ) {
      f = Math.max(rowBase * 0.75, f * Math.min(0.97, row.clientWidth / row.scrollWidth));
      row.style.fontSize = f + "px";
    }
    if (row.scrollWidth > row.clientWidth + 0.5) row.classList.add("tight");
    // 2. Condition: one line if a slightly smaller size (>= 82%) fits; otherwise two lines,
    //    shrunk (down to 75%) until the icon/temp row keeps at least minBody of height.
    const base = parseFloat(getComputedStyle(until).fontSize);
    const lines = (f) => until.scrollHeight / (f * 1.2);
    if (lines(base) > 1.5) {
      let f = base, one = false;
      while (f > base * 0.82) { f *= 0.96; until.style.fontSize = f + "px"; if (lines(f) <= 1.5) { one = true; break; } }
      if (!one) {
        f = base; until.style.fontSize = "";
        const minBody = u * 3.6;
        while (bodyEl.clientHeight < minBody && f > base * 0.75) { f *= 0.96; until.style.fontSize = f + "px"; }
      }
    }
    // 3. Big temperature: fit the height and the width left next to the icon.
    const h = bodyEl.clientHeight, w = bodyEl.clientWidth;
    if (!h || !w) return;
    const gap = parseFloat(getComputedStyle(bodyEl).columnGap) || 0;
    const icW = () => (ic && ic.offsetWidth) || 0;
    let fs = parseFloat(getComputedStyle(t).fontSize);
    for (let i = 0; i < 60 && fs > 10 && (t.offsetHeight > h || t.scrollWidth + icW() + gap > w); i++) {
      fs = Math.max(10, Math.floor(i < 3 ? fs * Math.min(h / t.offsetHeight, (w - icW() - gap) / t.scrollWidth, 0.99) : fs - 1));
      t.style.fontSize = fs + "px";
    }
  }
  let fcRaf = 0;
  const refitFc = () => { cancelAnimationFrame(fcRaf); fcRaf = requestAnimationFrame(fitForecast); };
  window.addEventListener("resize", refitFc);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(refitFc);
  if (window.ResizeObserver) { const fb = document.querySelector(".fc-body"); if (fb) new ResizeObserver(refitFc).observe(fb); }

  /* Hero condition: shrink to 72% on one line, else two smaller lines (clamped). */
  function fitCond() {
    const el = $("heroCond"); if (!el) return;
    const key = el.textContent + "|" + el.parentNode.clientWidth;
    if (el.dataset.fit === key) return; el.dataset.fit = key;
    el.style.fontSize = ""; el.classList.remove("two");
    const base = parseFloat(getComputedStyle(el).fontSize);
    for (let f = base; el.scrollWidth > el.clientWidth + 0.5 && f > base * 0.72; ) { f *= 0.95; el.style.fontSize = f + "px"; }
    if (el.scrollWidth > el.clientWidth + 0.5) { el.style.fontSize = ""; el.classList.add("two"); }
  }
  window.addEventListener("resize", () => { const el = $("heroCond"); if (el) { el.dataset.fit = ""; fitCond(); } });

  /* Card-head tags (e.g. "Falling rapidly") shrink a little (down to 78%) before they would be cut off. */
  function fitTags() {
    document.querySelectorAll(".card-head .tag").forEach((t) => {
      const key = t.textContent + "|" + t.parentNode.clientWidth;
      if (t.dataset.fit === key) return;
      t.dataset.fit = key; t.style.fontSize = "";
      const base = parseFloat(getComputedStyle(t).fontSize);
      for (let f = base; t.scrollWidth > t.clientWidth + 0.5 && f > base * 0.78; ) { f *= 0.95; t.style.fontSize = f + "px"; }
    });
  }
  window.addEventListener("resize", () => document.querySelectorAll(".card-head .tag").forEach((t) => { t.dataset.fit = ""; }));

  /* Mock-only forecast test values: ?mock=1&fc_until=...&fc_temp=104&fc_wind=25&fc_dir=WNW&fc_icon=thunderstorm */
  function applyMockForecast(d) {
    if (!MOCK || !d || !d.forecast || !["fc_until", "fc_temp", "fc_wind", "fc_dir", "fc_icon"].some((k) => params.has(k))) return d;
    const n = Object.assign({}, d.forecast.now);
    if (params.has("fc_until")) n.until = params.get("fc_until");
    if (params.has("fc_temp")) n.temp = parseFloat(params.get("fc_temp"));
    if (params.has("fc_wind")) n.wind = parseFloat(params.get("fc_wind"));
    if (params.has("fc_dir")) n.wind_dir = params.get("fc_dir");
    if (params.has("fc_icon")) n.icon = params.get("fc_icon");
    return Object.assign({}, d, { forecast: Object.assign({}, d.forecast, { now: n }) });
  }

  /* Mock-only test values: ?mock=1&temp=104.5 (or temp=none for "no data"). */
  function applyMockOverrides(d) {
    d = applyMockForecast(d);
    if (!MOCK || !(params.has("temp") || params.has("tunit")) || !d || !d.temp) return d;
    const raw = params.get("temp");
    const v = raw === "none" || raw === "" ? null : parseFloat(raw);
    const t = Object.assign({}, d.temp);
    if (params.has("temp")) t.now = isNum(v) ? v : null;
    if (isNum(v)) {
      t.feels = v;
      t.high = Object.assign({}, t.high, { value: Math.max(v, (t.high && t.high.value) ?? v) });
      t.low = Object.assign({}, t.low, { value: Math.min(v, (t.low && t.low.value) ?? v) });
    }
    let out = Object.assign({}, d, { temp: t });
    if (params.get("tunit") === "c") {  // mock-only: preview the Celsius scale
      const c = (f) => (isNum(f) ? Math.round((f - 32) / 1.8 * 10) / 10 : f);
      t.now = c(t.now); t.feels = c(t.feels); t.dew = c(t.dew);
      if (t.high) t.high = Object.assign({}, t.high, { value: c(t.high.value) });
      if (t.low) t.low = Object.assign({}, t.low, { value: c(t.low.value) });
      out.units = Object.assign({}, d.units, { temp: "\u00B0C" });
    }
    return out;
  }

  /* Temperature bar on a fixed absolute scale: 0–130 °F, or -18–54 °C. */
  const TEMP_SCALES = {
    f: { min: 0, max: 130, ticks: [0, 32, 65, 100, 130] },
    c: { min: -18, max: 54, ticks: [-18, 0, 18, 38, 54] },
  };
  function renderTempRange(T, U) {
    const unit = /C/i.test((U && U.temp) || "") ? "c" : "f";
    const S = TEMP_SCALES[unit];
    buildTempGauge(unit);
    const frac = (v) => Math.max(0, Math.min(1, (v - S.min) / (S.max - S.min)));
    const lo = (T.low || {}).value, hi = (T.high || {}).value;
    if (isNum(lo) && isNum(hi)) {
      const a = frac(Math.min(lo, hi)) * 100, b = Math.max(a + .8, frac(Math.max(lo, hi)) * 100);
      $("tBand").style.strokeDasharray = `0 ${a.toFixed(2)} ${(b - a).toFixed(2)} 200`;
    } else $("tBand").style.strokeDasharray = "0 200";
    const nd = $("tNeedle");
    if (isNum(T.now)) nd.style.transform = `rotate(${(TG.a0 + frac(T.now) * (TG.a1 - TG.a0)).toFixed(2)}deg)`;
    nd.style.opacity = isNum(T.now) ? "1" : "0";
    $("tGauge").setAttribute("aria-label", `Temperature gauge ${S.min} to ${S.max}°`);
  }

  function render(d) {
    d = applyMockOverrides(d);
    DATA = d;
    tz = (d.station && d.station.tz) || tz;
    h24 = d.station && d.station.time_format === "24";
    const U = d.units || {};
    const T = d.temp || {}, W = d.wind || {}, P = d.pressure || {}, R = d.rain || {}, H = d.humidity || {};
    const F = d.forecast || {}, FN = F.now || {}, FT = F.today || {}, A = d.astro || {}, M = A.moon || {};
    const hasData = isNum(d.obs_time);

    setText("stationName", (d.station && d.station.name) || "Weather Station");
    document.title = ((d.station && d.station.name) || "Weather") + " — " + fx(T.now) + "°";
    body.dataset.theme = pickTheme(d);
    updateStatus();

    // hero
    const heroIcon = FN.icon || (hasData ? (A.is_day === false ? "clear-night" : "clear-day") : "cloudy");
    if ($("heroIcon").dataset.icon !== heroIcon) { $("heroIcon").innerHTML = wicon(heroIcon); $("heroIcon").dataset.icon = heroIcon; }
    setText("heroCond", FN.conditions || (hasData ? "Observed" : "--"));
    fitCond();
    setText("comfort", T.comfort || "--");
    $("comfort").classList.toggle("hidden", !T.comfort);
    setLed("tempNow", "tempGhost", fx(T.now), 3);
    setText("tempDeg", /C/i.test(U.temp || "") ? "°C" : "°F");
    fitTemp();
    setArrow("trendArrow", T.trend);
    setText("trendVal", isNum(T.trend) ? signed(T.trend) + "°" : "--");
    setArrow("diffArrow", T.diff24, 0.5);
    setText("diffVal", isNum(T.diff24) ? signed(T.diff24) + "°" : "--");
    setText("feels", isNum(T.feels) ? fx(T.feels) + "°" : "--");
    setText("dewHero", isNum(T.dew) ? fx(T.dew) + "°" : "--");
    setText("humHero", isNum(H.now) ? fi(H.now) + "%" : "--");
    const lo = T.low || {}, hi = T.high || {};
    setText("lowVal", isNum(lo.value) ? fx(lo.value) + "°" : "--");
    setText("highVal", isNum(hi.value) ? fx(hi.value) + "°" : "--");
    setText("lowTime", fmtTime(lo.time));
    setText("highTime", fmtTime(hi.time));
    renderTempRange(T, U);

    // wind
    setText("windDesc", W.description || (W.calm ? "Calm" : "--"));
    setWind(W.speed, W.dir, W.dir_cardinal || (W.calm ? null : W.cardinal), W.cardinal, !!W.calm, U.wind || "mph");
    setHTML("windAvg", isNum(W.avg_today) ? `${fx(W.avg_today)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setHTML("windGust", isNum(W.gust_max) ? `${fx(W.gust_max)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setText("gustNow", isNum(W.gust) ? fx(W.gust) : "--");

    // barometer
    const slpMb = P.slp_mb;
    setLed("baroVal", "baroGhost", isNum(P.slp) ? fx(P.slp, U.pressure === "inHg" ? 2 : 1) : "--", 4);
    setText("baroUnitDial", String(U.pressure || "mb").toUpperCase());
    setText("baroTrendText", P.trend_text || "--");
    setArrow("baroArrow", P.trend, 0.3);
    setText("baroTrend", isNum(P.trend) ? `${signed(P.trend)} ${U.pressure}/hr` : "--");
    setText("baroTendency", P.tendency || "--");
    setText("baroLow", P.low && isNum(P.low.value) ? fx(P.low.value) : "--");
    setText("baroHigh", P.high && isNum(P.high.value) ? fx(P.high.value) : "--");
    setText("baroLowT", P.low ? fmtTime(P.low.time) : "");
    setText("baroHighT", P.high ? fmtTime(P.high.time) : "");
    if (isNum(slpMb)) $("baroMarker").style.transform = `rotate(${baroAng(slpMb).toFixed(2)}deg)`;
    $("baroMarker").style.opacity = isNum(slpMb) ? "1" : "0";

    // moon & sun
    // Compare a signature, not innerHTML (the browser re-serialises SVG differently, which
    // made every render rewrite the moon and repaint its card).
    const moonSig = `${M.illumination}|${M.waxing}`;
    if ($("moonSvg").dataset.sig !== moonSig) { $("moonSvg").innerHTML = moonArt(M.illumination, M.waxing); $("moonSvg").dataset.sig = moonSig; }
    setText("moonName", M.name || "--");
    setText("moonIllum", isNum(M.illumination) ? M.illumination + "% lit" : "--");
    setText("moonRise", fmtTime(M.rise));
    setText("moonSet", fmtTime(M.set));
    setText("nextNew", fmtDay(M.next_new));
    setText("nextFull", fmtDay(M.next_full));
    setText("sunRise", fmtTime(A.sunrise));
    setText("sunSet", fmtTime(A.sunset));

    // humidity
    setText("humVal", fi(H.now));
    const hseg = isNum(H.now) ? Math.round(Math.max(0, Math.min(100, H.now)) / 5) : 0;
    $("humCover").style.transform = `translateX(${(hseg * 5).toFixed(0)}%)`;
    setText("humDesc", humText(H.now, T.dew, U.temp));
    setText("dew", isNum(H.dew) ? fx(H.dew) + "°" : "--");
    const uv = d.solar && d.solar.uv;
    setHTML("uv", isNum(uv) ? `${fx(uv)} <span class="unit">${uvText(uv)}</span>` : "--");
    const useg = isNum(uv) ? Math.max(0, Math.min(11, Math.round(uv))) : 0;
    $("uvCover").style.transform = `translateX(${(useg / 11 * 100).toFixed(2)}%)`;
    const rad = d.solar && d.solar.radiation;
    setHTML("solar", isNum(rad) ? `${fi(rad)}<span class="unit">W/m²</span>` : "--");

    // rain
    const pu = U.precip || "in", dec = pu === "mm" ? 1 : 2;
    const scales = pu === "mm" ? { today: 25, yesterday: 25, month: 125, year: 600 } : { today: 1, yesterday: 1, month: 5, year: 25 };
    document.querySelectorAll("#rainBars .rb").forEach((el) => {
      const k = el.dataset.k, v = R[k];
      const rvTxt = isNum(v) ? (k === "year" && pu === "in" ? v.toFixed(1) : v.toFixed(dec)) : "--";
      const rvEl = el.querySelector(".rv");
      if (rvEl.dataset.v !== rvTxt) { rvEl.dataset.v = rvTxt; rvEl.innerHTML = esc(rvTxt) + (isNum(v) && pu === "in" ? '<span class="ru">\u2033</span>' : ""); }
      const pct = isNum(v) ? Math.min(1, v / Math.max(scales[k], v)) : 0;
      el.querySelector(".tube i").style.transform = `scaleY(${(v > 0 ? Math.max(.03, pct) : 0).toFixed(3)})`;
    });
    setText("rainText", R.rate_text || "--");
    setText("rainRate", isNum(R.rate) ? `${fx(R.rate, dec)} ${U.rate || "in/hr"}` : "--");

    // forecast now
    setText("fcUntil", FN.until || FN.conditions || "--");
    const fci = FN.icon || "cloudy";
    if ($("fcIcon").dataset.icon !== fci) { $("fcIcon").innerHTML = wicon(fci); $("fcIcon").dataset.icon = fci; }
    setText("fcTemp", isNum(FN.temp) ? fi(FN.temp) + "°" : "--");
    setText("fcLow", isNum(FT.low) ? fi(FT.low) + "°" : "--");
    setText("fcHigh", isNum(FT.high) ? fi(FT.high) + "°" : "--");
    const rainPct = isNum(FT.precip) ? FT.precip : FN.precip;
    setText("fcRainPill", isNum(rainPct) ? `\u{1F4A7} ${fi(rainPct)}%` : "--");
    setText("fcWind", isNum(FN.wind) ? `${fi(FN.wind)} ${U.wind} ${FN.wind_dir || ""}`.trim() : "--");
    refitFc();
    // tomorrow: forecast.daily starts at tomorrow; skip an entry that is already today/past
    // (stale feed just after midnight) by matching on the local calendar day.
    const DL = Array.isArray(F.daily) ? F.daily : [];
    const tmKey = dayKey(Date.now() / 1000 + 86400);
    const TM = DL.find((x) => x && isNum(x.time) && dayKey(x.time + 3600) === tmKey) || DL.find((x) => x && isNum(x.time) && x.time > Date.now() / 1000) || null;
    $("fcTm").classList.toggle("empty", !TM);
    if (TM) {
      const tmi = String(TM.icon || "cloudy").replace("-night", "-day");
      if ($("fcTmIcon").dataset.icon !== tmi) { $("fcTmIcon").innerHTML = wicon(tmi); $("fcTmIcon").dataset.icon = tmi; }
      setText("fcTmDay", "Tomorrow \u00b7 " + new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(new Date((TM.time + 3600) * 1000)));
      setText("fcTmCond", TM.conditions || "--");
      setText("fcTmHigh", isNum(TM.high) ? fi(TM.high) + "°" : "--");
      setText("fcTmLow", isNum(TM.low) ? fi(TM.low) + "°" : "--");
      setText("fcTmRain", isNum(TM.precip) ? `\u{1F4A7} ${fi(TM.precip)}%` : "");
    } else {
      setText("fcTmDay", "Tomorrow"); setText("fcTmCond", "Forecast unavailable");
      setText("fcTmHigh", "--"); setText("fcTmLow", "--"); setText("fcTmRain", "");
      $("fcTmIcon").innerHTML = ""; $("fcTmIcon").dataset.icon = "";
    }

    fitTags();
    renderHourly(F.hourly || []);
    renderLightning(d.lightning || {}, U);
    updateStrikeBadge();
    if (openPanel) showPanel(openPanel, true);
  }

  /* wind: shared by full renders and 3-second rapid_wind pushes */
  function tweenWind(to) {
    cancelAnimationFrame(windAnim);
    if (!isNum(to)) { windShown = null; setLed("windNow", "windGhost", "--", 3); return; }
    const from = isNum(windShown) ? windShown : to;
    const t0 = performance.now(), dur = 280;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      windShown = from + (to - from) * e;
      setLed("windNow", "windGhost", windShown.toFixed(1), 3);
      if (k < 1) windAnim = requestAnimationFrame(step);
      else windShown = to;
    };
    if (from === to || body.classList.contains("lite")) { windShown = to; setLed("windNow", "windGhost", fx(to), 3); }
    else windAnim = requestAnimationFrame(step);
  }
  function setWind(speed, dir, dirCard, fallbackTxt, calm, unit) {
    tweenWind(speed);
    setText("windNowUnit", unit || "mph");
    setHTML("windDir", isNum(dir) ? `${esc(dirCard || "--")}<span class="unit">${fi(dir)}°</span>` : esc(fallbackTxt || "--"));
    if (isNum(dir)) {
      if (needleAngle === null) needleAngle = dir;
      else { const delta = ((dir - needleAngle) % 360 + 540) % 360 - 180; needleAngle += delta; }
      $("needle").style.transform = `rotate(${needleAngle}deg)`;
    }
    $("needle").classList.toggle("calm", !!calm);
    $("needle").style.opacity = isNum(dir) ? "" : "0";
  }
  const CARD16 = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  function onRapidWind(w) {
    if (!DATA || !isNum(w.speed)) return;
    const W = DATA.wind = DATA.wind || {};
    const calm = w.calm != null ? !!w.calm : w.speed < 1;
    const dir = isNum(w.dir) ? w.dir : W.dir;
    const card = w.dir_cardinal || (isNum(dir) ? CARD16[Math.round(dir / 22.5) % 16] : null);
    Object.assign(W, { speed: w.speed, dir: dir, calm: calm, dir_cardinal: card, cardinal: calm ? "Calm" : card });
    if (isNum(w.gust)) { W.gust = w.gust; setText("gustNow", fx(w.gust)); }
    setWind(w.speed, dir, card, W.cardinal, calm, (DATA.units && DATA.units.wind) || w.unit);
    const c = document.querySelector(".card.wind");
    c.classList.remove("tick"); void c.offsetWidth; c.classList.add("tick");
  }

  function humText(rh, dew, unit) {
    if (!isNum(rh)) return "--";
    let dp = dew;
    if (isNum(dp) && unit === "°C") dp = dp * 9 / 5 + 32;
    if (isNum(dp)) {
      if (dp < 50) return "Dry";
      if (dp < 60) return "Comfortable";
      if (dp < 65) return "Sticky";
      if (dp < 70) return "Humid";
      return "Oppressive";
    }
    return rh < 30 ? "Dry" : rh < 60 ? "Comfortable" : "Humid";
  }
  function uvText(uv) {
    return uv < 3 ? "Low" : uv < 6 ? "Moderate" : uv < 8 ? "High" : uv < 11 ? "Very high" : "Extreme";
  }

  function smoothPath(pts) {
    if (pts.length < 2) return "";
    let d = `M${pts[0][0]} ${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)} ${c2x.toFixed(1)} ${c2y.toFixed(1)} ${p2[0]} ${p2[1].toFixed(1)}`;
    }
    return d;
  }

  function renderHourly(hours) {
    const list = hours.slice(0, 12);
    if (!list.length) { setHTML("hours", `<div class="label" style="grid-column:1/-1;grid-row:1/-1;align-self:center;text-align:center">Hourly forecast unavailable</div>`); return; }
    const temps = list.map((h) => h.temp).filter(isNum);
    const mn = Math.min.apply(null, temps), mx = Math.max.apply(null, temps), span = Math.max(1, mx - mn);
    const n = list.length;
    const pts = list.map((h, i) => [((i + 0.5) * 1200) / 12, isNum(h.temp) ? 12 + (1 - (h.temp - mn) / span) * 76 : 50]);
    const line = smoothPath(pts);
    const area = line + ` L${pts[n - 1][0]} 100 L${pts[0][0]} 100 Z`;
    let html = `<div class="spark-win"><svg class="spark" viewBox="0 0 1200 100" preserveAspectRatio="none" aria-hidden="true">
      <path class="area" d="${area}"/><path class="line" d="${line}"/></svg></div>`;
    list.forEach((h, i) => {
      const p = isNum(h.precip) ? h.precip : null;
      html += `<div class="hcell"><div class="h${i === 0 ? " now" : ""}" style="grid-column:${i + 1}">${esc(fmtHour(h.time))}</div>
        <div class="i" style="grid-column:${i + 1}">${wicon(h.icon)}</div>
        <div class="tt" style="grid-column:${i + 1}">${fi(h.temp)}°</div>
        <div class="p${!p ? " zero" : ""}" style="grid-column:${i + 1}">${p === null ? "" : fi(p) + "%"}</div></div>`;
    });
    const sig = JSON.stringify(list.map((h) => [h.time, h.temp, h.icon, h.precip]));
    const el = $("hours");
    if (el.dataset.sig !== sig) { el.innerHTML = html; el.dataset.sig = sig; }
  }

  // lamp state: red for the first 10 min after a strike, amber until 30 min
  function strikeRecentRed(L) { return isNum(L.last_epoch) && Date.now() / 1000 - L.last_epoch < 600; }
  function setLamp(el, color, blink) {
    if (!el) return;
    const sm = el.classList.contains("sm") ? " sm" : "", extra = el.classList.contains("lt-lamp") ? " lt-lamp" : "";
    const cls = "lamp" + sm + extra + (color ? " " + color : "") + (blink ? " blink" : "");
    if (el.className !== cls) el.className = cls;
  }
  function lightningActive(L) {
    return isNum(L.last_epoch) && Date.now() / 1000 - L.last_epoch < 1800;
  }
  function strikeWhen(ts) {
    if (!isNum(ts)) return "";
    if (dayKey(ts) === dayKey(Date.now() / 1000)) return "at " + fmtTime(ts);
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000)) + ", " + fmtTime(ts);
  }

  function flashLightning() {
    const c = $("ltCard");
    c.classList.remove("flash"); void c.offsetWidth; c.classList.add("flash");
    const b = $("strikeBadge");
    b.classList.remove("zap"); void b.offsetWidth; b.classList.add("zap");
  }
  function onStrike(e) {
    if (!DATA || !isNum(e.epoch)) return;
    const L = DATA.lightning = DATA.lightning || {};
    if (!isNum(L.last_epoch) || e.epoch >= L.last_epoch) { L.last_epoch = e.epoch; L.last_distance = e.distance; }
    ["count_1h", "count_3h", "count_today", "count_month", "count_30m"].forEach((k) => { L[k] = (isNum(L[k]) ? L[k] : 0) + 1; });
    if (isNum(e.distance)) L.nearest_30m = isNum(L.nearest_30m) ? Math.min(L.nearest_30m, e.distance) : e.distance;
    if (Array.isArray(L.hourly) && L.hourly.length) {
      const hr = Math.floor(e.epoch / 3600) * 3600;
      let last = L.hourly[L.hourly.length - 1];
      while (last.time < hr) { L.hourly.shift(); last = { time: last.time + 3600, count: 0, min_distance: null }; L.hourly.push(last); }
      if (last.time === hr) last.count += 1;
    }
    renderLightning(L, DATA.units || {});
    updateStrikeBadge();
    flashLightning();
  }

  function renderLightning(L, U) {
    const dist = U.distance || "mi";
    const has = isNum(L.last_epoch);
    const active = lightningActive(L);
    $("ltCard").classList.toggle("active", active);
    $("ltCard").classList.toggle("near", active && strikeRecentRed(L));
    setLamp($("ltLamp"), active ? (strikeRecentRed(L) ? "red" : "amber") : "", active);
    const near = isNum(L.nearest_30m) ? L.nearest_30m : L.last_distance;
    const noData = !has && !isNum(L.count_1h) && !isNum(L.count_3h) && !isNum(L.count_today);
    setText("ltStatusText", active ? `Active \u2014 strikes within ${fi(near)} ${dist}` : noData ? "No data" : "No strikes nearby");
    setLed("ltDist", "ltGhost", has && isNum(L.last_distance) ? fi(L.last_distance) : "--", 2);
    setText("ltUnit", dist);
    setText("ltAgo", has ? ago(L.last_epoch) : noData ? "--" : "No strikes detected");
    setText("ltWhen", has ? strikeWhen(L.last_epoch) : "\u00a0");
    setText("ltC1", fi(L.count_1h));
    setText("ltC3", fi(L.count_3h));
    setText("ltCT", fi(L.count_today));
    setText("ltCM", fi(L.count_month));
    ["ltC1", "ltC3", "ltCT", "ltCM"].forEach((id) => { const v = $(id).textContent; $(id).classList.toggle("zero", v === "0"); });

    const hrs = Array.isArray(L.hourly) ? L.hourly : null;
    const el = $("ltBars");
    if (!hrs || !hrs.length) {
      setHTML("ltBars", `<div class="lt-none">Hourly history unavailable</div>`);
      setText("ltPeak", "");
      $("ltAxis").classList.add("hidden");
      el.dataset.sig = "";
      return;
    }
    $("ltAxis").classList.remove("hidden");
    const counts = hrs.map((b) => (isNum(b.count) ? b.count : 0));
    const mx = Math.max.apply(null, counts);
    const total = counts.reduce((a, b) => a + b, 0);
    setText("ltPeak", total ? `${total} in ${hrs.length}h` : `None in ${hrs.length}h`);
    $("ltPeak").title = total ? `Peak ${mx} strikes in one hour` : "";
    const n = hrs.length;
    const sig = JSON.stringify([counts, active]);
    if (el.dataset.sig === sig) return;
    let html = "";
    hrs.forEach((b, i) => {
      const c = counts[i];
      const h = c ? Math.max(10, Math.sqrt(c / Math.max(1, mx)) * 100) : 0;
      const cls = c ? (i === n - 1 && active ? "on now" : "on") : "";
      html += `<i class="${cls}" style="height:${h.toFixed(1)}%" title="${esc(fmtHour(b.time))}: ${c}"></i>`;
    });
    el.style.gridTemplateColumns = `repeat(${n}, 1fr)`;
    el.innerHTML = html;
    el.dataset.sig = sig;
    const axis = $("ltAxis").children;
    axis[0].textContent = n + "h ago";
    axis[1].textContent = Math.round(n / 2) + "h";
  }

  /* ---------------- status / errors ---------------- */
  function updateStatus() {
    const d = DATA;
    const pill = $("statusPill");
    let cls = "loading", txt = "Connecting…";
    if (serverDown) {
      cls = "error"; txt = "Dashboard server unreachable" + (lastFetchOk ? " · showing data from " + ago(lastFetchOk / 1000) : "");
    } else if (d) {
      if (d.mock) { cls = "mock"; txt = "Demo data"; }
      else if (d.status === "ok") { cls = "ok"; txt = "Live · updated " + ago(d.obs_time); }
      else if (d.status === "stale") { cls = "stale"; txt = "Stale · last obs " + ago(d.obs_time) + (d.error ? " · " + d.error : ""); }
      else if (d.status === "loading") { cls = "loading"; txt = d.error || "Loading…"; }
      else { cls = "error"; txt = "Offline · " + (d.error || "no data"); }
    }
    pill.className = "status " + cls;
    setText("statusText", txt);
    const noData = !d || !isNum(d.obs_time);
    const showErr = noData && (serverDown || (d && (d.status === "error")));
    $("errorState").classList.toggle("hidden", !showErr);
    body.classList.toggle("has-error", cls === "error" || cls === "stale");
    if (showErr) setText("errorMsg", serverDown ? "The wxdash server on this Pi is not responding." : (d && d.error) || "Unknown error");
  }

  function updateStrikeBadge() {
    const L = (DATA && DATA.lightning) || {};
    const b = $("strikeBadge");
    const recent = lightningActive(L), red = recent && strikeRecentRed(L);
    b.classList.toggle("on", recent);
    b.classList.toggle("near", red);
    setLamp(b.querySelector(".lamp"), recent ? (red ? "red" : "amber") : "", recent);
    if (DATA) renderLightningTick();
    setText("strikeText", recent ? `\u26A1 ${fi(L.last_distance)} ${(DATA.units && DATA.units.distance) || "mi"} \u00b7 ${ago(L.last_epoch)}` : "No strikes");
  }

  function renderLightningTick() {
    const L = (DATA && DATA.lightning) || {};
    const active = lightningActive(L);
    if ($("ltCard").classList.contains("active") !== active || $("ltCard").classList.contains("near") !== (active && strikeRecentRed(L))) renderLightning(L, DATA.units || {});
    else if (isNum(L.last_epoch)) { setText("ltAgo", ago(L.last_epoch)); setText("ltWhen", strikeWhen(L.last_epoch)); }
  }

  /* live indicator: green = WebSocket feed connected and pushing to this page */
  function updateLive() {
    const el = $("livePill");
    let cls = "off", txt = "Polling", title = "Live stream not connected; refreshing every 15 s";
    if (sseOpen && (wsState === "connected" || demoLive)) { cls = "on"; txt = "Live"; title = demoLive ? "Simulated live feed (demo)" : "WeatherFlow live feed connected"; }
    else if (sseOpen && wsState === "connecting") { cls = "wait"; txt = "Reconnecting"; title = "WeatherFlow live feed reconnecting; using REST updates"; }
    el.className = "ind live " + cls;
    setLamp(el.querySelector(".lamp"), cls === "on" ? "green" : cls === "wait" ? "amber" : "", cls === "wait");
    el.title = title;
    setText("liveText", txt);
  }

  /* ---------------- theme (Classic / Industrial; saved on the Pi via POST /api/settings) ---------------- */
  const THEME = "industrial";
  const THEMES = [["classic", "Classic"], ["industrial", "Industrial"]];
  let themeMsg = "";
  function themeHTML() {
    return `<div class="theme-pick"><div class="label">Theme</div><div class="theme-btns">` +
      THEMES.map(([k, n]) => `<button data-act="theme" data-theme="${k}" class="${k === THEME ? "on" : ""}" aria-pressed="${k === THEME}">` +
        `<span class="tn">${n}</span><span class="cur">${k === THEME ? "\u2713 Current" : "Tap to switch"}</span></button>`).join("") +
      `</div>${themeMsg ? `<div class="theme-msg">${esc(themeMsg)}</div>` : ""}</div>`;
  }
  function urlWithoutTheme() { const u = new URL(location.href); u.searchParams.delete("theme"); u.searchParams.delete("panel"); return u.toString(); }
  async function setTheme(t) {
    if (!t || t === THEME) { closePanel(); return; }
    themeMsg = "Switching\u2026"; showPanel("menu", true);
    try {
      const r = await fetch("/api/settings", { method: "POST", cache: "no-store",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({ theme: t }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      location.replace(urlWithoutTheme());   // the server now serves the new theme at "/"
    } catch (e) { themeMsg = "Couldn't switch theme: " + (e.message || e); showPanel("menu", true); }
  }
  // Another screen switched the theme: follow it (not for ?theme= previews).
  function onSettings(s) { if (s && s.theme && s.theme !== THEME && !params.get("theme")) location.replace(urlWithoutTheme()); }
  fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()).then((s) => {
    if (s && s.saved === false) themeMsg = "Theme not saved on the Pi (run install.sh once); it resets when wxdash restarts.";
  }).catch(() => {});

  /* ---------------- overlays ---------------- */
  function showPanel(name, refresh) {
    const d = DATA || {};
    const U = d.units || {};
    let html = "";
    if (name === "sager") {
      const S = d.sager, P = d.pressure || {};
      html = `<h3>Sager-style outlook</h3><div class="lead">Barometric forecast for the next 12–24 hours</div>
        <div class="big">${esc(S ? S.outlook : "Not enough pressure history yet")}</div>
        <div class="grid3"><div><div class="label">Sea-level pressure</div><div class="v">${fx(P.slp)} <small>${esc(U.pressure)}</small></div></div>
        <div><div class="label">3-hour trend</div><div class="v">${signed(P.trend)} <small>${esc(U.pressure)}/hr</small></div></div>
        <div><div class="label">Tendency</div><div class="v" style="font-size:calc(var(--u)*1.3);white-space:normal">${esc(P.trend_text || "--")}</div></div></div>
        <div class="note">Computed on this Pi with the Zambretti barometer method (pressure, 3-hour trend and season).${P.tendency ? " Barometer tendency: " + esc(P.tendency) + "." : ""}</div>`;
    } else if (name === "menu") {
      const s = d.station || {};
      html = `<h3>${esc(s.name || "Weather Station")}</h3><div class="lead">Station ${esc(s.id || "--")} · Tempest ${esc(s.device || "--")} · ${isNum(s.lat) ? s.lat.toFixed(4) + ", " + s.lon.toFixed(4) : ""}</div>
        <div class="grid3"><div><div class="label">Data</div><div class="v" style="font-size:calc(var(--u)*1.4)">${esc(d.mock ? "Demo" : d.status || "--")}</div></div>
        <div><div class="label">Last observation</div><div class="v" style="font-size:calc(var(--u)*1.4)">${esc(fmtTime(d.obs_time))}</div></div>
        <div><div class="label">Version</div><div class="v" style="font-size:calc(var(--u)*1.4)">wxdash ${esc(d.version || "")}</div></div></div>
        ${d.error ? `<div class="note">${esc(d.error)}</div>` : ""}
        ${themeHTML()}
        <div class="rowbtn"><button data-act="refresh">Refresh now</button><button data-act="reload">Reload page</button>
        <button data-act="lite">${body.classList.contains("lite") ? "Lite mode: on" : "Lite mode: off"}</button>
        <button data-act="cursor">${body.classList.contains("show-cursor") ? "Hide cursor" : "Show cursor"}</button></div>`;
    }
    if (!html) return;
    if (refresh && $("overlayBody").dataset.panel === name && $("overlayBody").innerHTML === html) return;
    $("overlayBody").innerHTML = html;
    $("overlayBody").dataset.panel = name;
    $("overlay").classList.remove("hidden");
    openPanel = name;
    if (!refresh) { clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000); }
  }
  function closePanel() { $("overlay").classList.add("hidden"); openPanel = null; clearTimeout(overlayTimer); }

  document.querySelectorAll("[data-panel]").forEach((b) => b.addEventListener("click", () => showPanel(b.dataset.panel)));
  // The header badge just draws attention to the permanent Lightning card.
  $("strikeBadge").addEventListener("click", () => {
    const c = $("ltCard"); c.classList.remove("flash"); void c.offsetWidth; c.classList.add("flash");
  });
  $("overlayClose").addEventListener("click", closePanel);
  $("overlay").addEventListener("click", (e) => { if (e.target === $("overlay")) closePanel(); });
  $("overlayBody").addEventListener("click", (e) => {
    const btn = e.target && e.target.closest ? e.target.closest("[data-act]") : null;
    const act = btn && btn.dataset.act;
    if (act === "theme") setTheme(btn.dataset.theme);
    else if (act === "refresh") { load(); closePanel(); }
    else if (act === "reload") location.reload();
    else if (act === "glass") { body.classList.toggle("glass"); localStorage.setItem("wxdash-glass", body.classList.contains("glass") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "lite") { body.classList.toggle("lite"); localStorage.setItem("wxdash-lite", body.classList.contains("lite") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "cursor") { body.classList.toggle("show-cursor"); localStorage.setItem("wxdash-cursor", body.classList.contains("show-cursor") ? "1" : "0"); showPanel("menu", true); }
  });

  /* ---------------- polling ---------------- */
  function dataQuery() {
    const q = new URLSearchParams();
    if (MOCK) q.set("mock", "1");
    if (params.get("lightning")) q.set("lightning", params.get("lightning"));
    const qs = q.toString();
    return qs ? "?" + qs : "";
  }
  function startStream() {
    if (!window.EventSource || params.get("stream") === "0") return;
    try { sse = new EventSource("/api/stream" + dataQuery()); } catch (e) { return; }
    const ok = () => { if (!sseOpen) { sseOpen = true; updateLive(); } };
    const parse = (ev, fn) => { try { fn(JSON.parse(ev.data)); ok(); } catch (e) { /* ignore bad event */ } };
    sse.addEventListener("open", ok);
    sse.addEventListener("error", () => { sseOpen = false; updateLive(); });  // EventSource auto-reconnects
    sse.addEventListener("data", (ev) => parse(ev, (d) => { serverDown = false; lastFetchOk = Date.now(); render(d); }));
    sse.addEventListener("wind", (ev) => parse(ev, onRapidWind));
    sse.addEventListener("strike", (ev) => parse(ev, onStrike));
    sse.addEventListener("settings", (ev) => parse(ev, onSettings));
    sse.addEventListener("live", (ev) => parse(ev, (l) => { wsState = l.ws || "off"; demoLive = !!l.demo; updateLive(); }));
  }

  async function load() {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch("/api/data" + dataQuery(), { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const d = await r.json();
      serverDown = false;
      lastFetchOk = Date.now();
      if (d.live) { wsState = d.live.ws || "off"; demoLive = !!d.live.demo; }
      render(d);
      updateLive();
    } catch (e) {
      serverDown = true;
      updateStatus();
    }
  }

  /* ---------------- night mode (8 PM - 6 AM, Pi clock) ----------------
     Industrial theme: panels dim and the LED readouts / lamps / dial faces are back-lit.
     ?mock=1&night=1 / night=0 forces it for previews. */
  const NIGHT_FORCE = MOCK && params.has("night") ? params.get("night") === "1" : null;
  function localHour() {
    try { return +new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hourCycle: "h23" }).format(new Date()) % 24; }
    catch (e) { return new Date().getHours(); }
  }
  function isNightHour() { if (NIGHT_FORCE !== null) return NIGHT_FORCE; const h = localHour(); return h >= 20 || h < 6; }
  function updateNight() { body.classList.toggle("night", isNightHour()); }
  updateNight();
  setInterval(updateNight, 60000);
  clockLoop();
  setInterval(() => { updateStatus(); if (DATA) updateStrikeBadge(); }, 5000);
  load().then(() => { const p = params.get("panel"); if (p) showPanel(p); startStream(); });
  // Polling is the fallback; while the live stream is healthy it only runs once a minute.
  setInterval(() => { if (!sseOpen || Date.now() - lastFetchOk > 60000) load(); }, POLL_MS);
  // Self-update: when the server reports a different version than the one this page
  // loaded with, reload so the kiosk picks up the new UI without relaunching Chromium.
  let loadedVersion = null;
  async function checkVersion() {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 8000);
      const r = await fetch("/api/health", { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) return;
      const h = await r.json();
      if (!h || !h.ok || typeof h.version !== "string" || !h.version) return;
      if (loadedVersion === null) loadedVersion = h.version;
      else if (h.version !== loadedVersion) location.reload();
      else if (h.theme && h.theme !== THEME) onSettings({ theme: h.theme });   // backup if the SSE event was missed
    } catch (e) { /* server restarting or down; try again next minute */ }
  }
  checkVersion();
  setInterval(checkVersion, 60000);
  // Recover from long-running kiosk memory growth: reload once a day at ~3:30 AM.
  setInterval(() => { const h = new Date().getHours(), m = new Date().getMinutes(); if (h === 3 && m === 30) location.reload(); }, 60000);
})();
