/* wxdash 1.5.8: Menu > Feels-like labels (shared by every theme).
   The temperature card's "Feeling …" chip is chosen from the feels-like temperature with 8 cut-offs
   (°F, coldest first): cutoffs[i] is where label i+1 starts. They come from GET /api/settings
   ("feel"), are edited here with −/+ (1° per tap, always strictly increasing, -40..140 °F) and are
   saved with POST /api/settings {"feel_thresholds": [{label, min}, …]} (null = defaults).
   The theme calls WXFeel.init({ show(name), changed() }) and uses WXFeel.label(), menuButton(),
   panelHTML(d) and act(name, button). */
(function () {
  "use strict";
  var LABELS = ["Feeling extremely cold", "Feeling freezing cold", "Feeling very cold", "Feeling cold",
    "Feeling mild", "Feeling warm", "Feeling hot", "Feeling very hot", "Feeling extremely hot"];
  var MIN = -40, MAX = 140, SAVE_MS = 700;
  var cut = null, dflt = null, custom = false, msg = "", saveTimer = 0, busy = false, opts = {};

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return "&#" + c.charCodeAt(0) + ";"; }); }
  function short(l) { var s = String(l).replace(/^Feeling\s+/i, ""); return s.charAt(0).toUpperCase() + s.slice(1); }
  function fmt(v) { return (Math.round(v * 10) / 10).toString().replace("-", "\u2212") + "\u00B0F"; }
  function nums(list) { return (list || []).map(function (t) { return typeof t === "number" ? t : t && t.min; }); }
  function valid(a) {
    if (!a || a.length !== LABELS.length - 1) return false;
    for (var i = 0; i < a.length; i++) {
      if (typeof a[i] !== "number" || !isFinite(a[i]) || a[i] < MIN || a[i] > MAX || (i && a[i] <= a[i - 1])) return false;
    }
    return true;
  }
  function toF(v, unit) { return /C/.test(unit || "") ? v * 9 / 5 + 32 : v; }
  function index(f) { var i = 0; while (i < cut.length && f >= cut[i]) i++; return i; }

  /* label for a feels-like value in the page's display unit; null until the cut-offs are known */
  function label(feels, unit) {
    if (!cut || typeof feels !== "number" || !isFinite(feels)) return null;
    return LABELS[index(Math.round(toF(feels, unit) * 10) / 10)];
  }

  function sync(f) {                     // from GET /api/settings, a POST reply or the "settings" event
    if (!f || saveTimer || busy) return;  // our own edit is still on its way: keep what's on screen
    var c = nums(f.thresholds), d = nums(f.defaults);
    if (!valid(c)) return;
    var same = cut && c.join() === cut.join();
    cut = c; if (valid(d)) dflt = d; custom = !!f.custom;
    if (!same) changed();
  }
  function changed() { try { if (opts.changed) opts.changed(); } catch (e) { /* theme redraw */ } }

  function save(value) {
    clearTimeout(saveTimer); saveTimer = 0; busy = true; msg = "Saving\u2026"; changed();
    var payload = value === null ? null : value.map(function (v, i) { return { label: LABELS[i + 1], min: v }; });
    fetch("/api/settings", { method: "POST", cache: "no-store", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feel_thresholds: payload }) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return [r, j]; }); })
      .then(function (rj) {
        var r = rj[0], j = rj[1]; busy = false;
        if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
        msg = j.saved === false ? "Applied, but not saved on the Pi (" + (j.error || "settings file not writable") + ")" : "Saved";
        cut = null; sync(j.feel); changed();
      })
      .catch(function (e) { busy = false; msg = "Couldn't save: " + (e.message || e); changed(); });
  }
  function queueSave() { clearTimeout(saveTimer); msg = "Saving\u2026"; saveTimer = setTimeout(function () { saveTimer = 0; save(cut.slice()); }, SAVE_MS); }

  /* step boundary i (0..7) by +1/-1; returns false when blocked by a neighbour or the range */
  function step(i, dir) {
    if (!cut || i < 0 || i >= cut.length) return false;
    var lo = i ? cut[i - 1] : MIN - 1, hi = i < cut.length - 1 ? cut[i + 1] : MAX + 1;
    var v = dir > 0 ? Math.floor(cut[i] + 1e-9) + 1 : Math.ceil(cut[i] - 1e-9) - 1;
    if (v <= lo || v >= hi || v < MIN || v > MAX) return false;
    cut[i] = v; custom = true; queueSave(); changed(); return true;
  }
  function canStep(i, dir) {
    var lo = i ? cut[i - 1] : MIN - 1, hi = i < cut.length - 1 ? cut[i + 1] : MAX + 1;
    var v = dir > 0 ? Math.floor(cut[i] + 1e-9) + 1 : Math.ceil(cut[i] - 1e-9) - 1;
    return v > lo && v < hi && v >= MIN && v <= MAX;
  }

  function menuButton() { return cut ? '<button data-act="feel-open">Feels-like labels \u203A</button>' : ""; }

  function panelHTML(d) {
    if (!cut) return '<h3>Feels-like labels</h3><div class="lead">Loading\u2026</div>';
    var T = (d && d.temp) || {}, U = (d && d.units) || {};
    var nowF = typeof T.feels === "number" ? Math.round(toF(T.feels, U.temp) * 10) / 10 : null;
    var cur = nowF === null ? -1 : index(nowF);
    var rows = LABELS.map(function (l, k) {
      var on = k === cur ? " now" : "";
      if (k === 0) {
        return '<div class="feel-row' + on + '" data-k="0"><div class="feel-name">' + esc(short(l)) + '</div>' +
          '<div class="feel-from"><span class="feel-w">below</span> <b>' + fmt(cut[0]) + '</b></div><div class="feel-fix">set by the next row</div></div>';
      }
      var i = k - 1;
      return '<div class="feel-row' + on + '" data-k="' + k + '"><div class="feel-name">' + esc(short(l)) + '</div>' +
        '<div class="feel-from"><span class="feel-w">from</span> <b data-feel-val="' + i + '">' + fmt(cut[i]) + '</b></div>' +
        '<div class="feel-btns"><button data-act="feel-dn" data-i="' + i + '" aria-label="' + esc(short(l)) + ' colder"' + (canStep(i, -1) ? "" : " disabled") + '>\u2212</button>' +
        '<button data-act="feel-up" data-i="' + i + '" aria-label="' + esc(short(l)) + ' warmer"' + (canStep(i, 1) ? "" : " disabled") + '>+</button></div></div>';
    }).join("");
    var isDefault = dflt && cut.join() === dflt.join();
    return '<h3>Feels-like labels</h3><div class="lead">' +
      (nowF === null ? "" : "Feels like " + fmt(nowF) + " now \u2192 <b>" + esc(short(LABELS[cur])) + "</b>. ") +
      "Each label starts at its \u201Cfrom\u201D temperature; \u2212 / + moves it 1\u00B0.</div>" +
      '<div class="feel-grid">' + rows + "</div>" +
      '<div class="rowbtn"><button data-act="feel-back">\u2039 Menu</button>' +
      '<button data-act="feel-reset"' + (isDefault && !custom ? " disabled" : "") + ">Reset to defaults</button>" +
      (msg ? '<span class="feel-msg">' + esc(msg) + "</span>" : "") + "</div>";
  }

  function act(name, btn) {
    if (name === "feel-open") { msg = ""; if (opts.show) opts.show("feel"); return true; }
    if (name === "feel-back") { if (opts.show) opts.show("menu"); return true; }
    if (name === "feel-reset") { if (cut) { if (dflt) cut = dflt.slice(); custom = false; save(null); } return true; }
    if (name === "feel-up" || name === "feel-dn") { step(parseInt(btn && btn.dataset.i, 10), name === "feel-up" ? 1 : -1); return true; }
    return false;
  }

  function init(o) {
    opts = o || {};
    fetch("/api/settings", { cache: "no-store" }).then(function (r) { return r.json(); })
      .then(function (s) { if (s && s.feel) sync(s.feel); }).catch(function () { /* server labels stay */ });
  }

  window.WXFeel = { init: init, label: label, sync: sync, menuButton: menuButton, panelHTML: panelHTML, act: act,
    get thresholds() { return cut ? cut.slice() : null; } };
})();
