/* wxdash 1.5.7: auto-hiding mouse pointer (shared by every theme).
   The page starts with body.cursor-hidden. A real mouse move, mouse button or wheel shows the pointer;
   it hides again after 3 s with no mouse activity. Touch and pen input never show it.
   One passive listener per event type, at most one class change per event, and a single idle timer
   that re-arms itself for the remaining time instead of being recreated on every move.
   "Show cursor" in the menu (body.show-cursor) keeps the pointer visible all the time. */
(function () {
  "use strict";
  var IDLE = 3000, body = document.body;
  if (!body) return;
  var hidden = true, last = 0, timer = 0, lx = null, ly = null;
  body.classList.add("cursor-hidden");
  function hide() {
    timer = 0;
    var left = IDLE - (Date.now() - last);
    if (left > 25) { timer = setTimeout(hide, left); return; }
    if (!hidden) { hidden = true; body.classList.add("cursor-hidden"); }
  }
  function wake(e) {
    if (e.pointerType && e.pointerType !== "mouse") return;          // touch / pen: stay hidden
    if (e.type === "pointermove") {                                   // ignore synthetic moves that don't move
      if (e.screenX === lx && e.screenY === ly) return;
      lx = e.screenX; ly = e.screenY;
    }
    last = Date.now();
    if (hidden) { hidden = false; body.classList.remove("cursor-hidden"); }
    if (!timer) timer = setTimeout(hide, IDLE);
  }
  var opt = { passive: true };
  var moveEv = window.PointerEvent ? "pointermove" : "mousemove", downEv = window.PointerEvent ? "pointerdown" : "mousedown";
  window.addEventListener(moveEv, wake, opt);
  window.addEventListener(downEv, wake, opt);
  window.addEventListener("wheel", wake, opt);
})();
