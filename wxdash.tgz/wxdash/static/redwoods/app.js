/* wxdash front-end - REDWOODS theme (fifth theme, added in 1.5.0). Vanilla JS, no dependencies, works offline.
   Data plumbing (polling, live stream, menu, theme picker, night mode) follows the Arctic/Desert front
   ends; the look is naturalistic: a procedurally generated redwood grove (static photos), oiled-wood
   and slate cards, and instruments in real materials: a temperature arc of inlaid enamel
   segments with a bronze index over the open grove, a bronze survey compass, a speed rule with a bronze slider, a soil
   core-sample barometer, glass rain gauges with bronze caps, dry-bark-to-fog humidity, UV sun discs,
   moon over the grove, a treeline for the next 12 hours and a river-stone strike chart.
   Animation layer: always-on rain at three depths (heavier when it is really raining, slanted by the
   live wind), drips off the branches, creek ripples, drifting fog and a storm flash. All continuous
   motion is CSS transform/opacity on HTML layers (compositor only); it pauses when the page is
   hidden and honours prefers-reduced-motion / Lite. */
(function () {
  "use strict";
  const POLL_MS = 15000;
  const params = new URLSearchParams(location.search);
  const MOCK = params.get("mock") === "1";
  const $ = (id) => document.getElementById(id);
  const body = document.body;
  const SVGNS = "http://www.w3.org/2000/svg";
  let DATA = null, lastFetchOk = 0, serverDown = false;
  let tz = "America/Los_Angeles", h24 = false;
  let needleAngle = null, overlayTimer = null, openPanel = null;
  let sse = null, sseOpen = false, wsState = "off", demoLive = false;
  let windShown = null, windAnim = 0;

  if (params.get("lite") === "1" || localStorage.getItem("wxdash-lite") === "1") body.classList.add("lite");
  if (params.get("cursor") === "1" || localStorage.getItem("wxdash-cursor") === "1") body.classList.add("show-cursor");

  /* ---------------- mock-only clock override: ?mock=1&mock_time=13:30 ----------------
     Shifts the clock, night mode and the demo data's timestamps/day-night icons so a
     daytime preview can be rendered at any hour. Never active without mock=1. */
  const MOCK_TIME = MOCK && /^\d{1,2}:\d{2}$/.test(params.get("mock_time") || "") ? params.get("mock_time") : null;
  let OFFSET = 0;
  function computeOffset() {
    if (!MOCK_TIME) return;
    const [th, tm] = MOCK_TIME.split(":").map(Number);
    const p = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "numeric", second: "numeric", hourCycle: "h23" }).formatToParts(new Date());
    const g = (t) => +p.find((x) => x.type === t).value;
    OFFSET = ((th * 60 + tm) - ((g("hour") % 24) * 60 + g("minute"))) * 60000 - g("second") * 1000;
  }
  computeOffset();
  const nowMs = () => Date.now() + OFFSET;
  const nowS = () => nowMs() / 1000;

  /* ---------------- formatting ---------------- */
  const isNum = (v) => typeof v === "number" && isFinite(v);
  const fx = (v, d = 1) => (isNum(v) ? v.toFixed(d) : "--");
  const fi = (v) => (isNum(v) ? Math.round(v).toString() : "--");
  function signed(v, d = 1) { if (!isNum(v)) return "--"; const s = Math.abs(v).toFixed(d); return (v > 0 ? "+" : v < 0 ? "\u2212" : "") + s; }
  function fmtTime(ts, opts) {
    if (!isNum(ts)) return "--";
    return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: tz, hour: "numeric", minute: "2-digit", hour12: !h24 }, opts || {})).format(new Date(ts * 1000));
  }
  function fmtHour(ts) {
    if (!isNum(ts)) return "--";
    if (h24) return fmtTime(ts, { minute: "2-digit" });
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hour12: true }).format(new Date(ts * 1000)).replace(" ", "\u2009");
  }
  function dayKey(ts) { return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(ts * 1000)); }
  function fmtDay(ts) {
    if (!isNum(ts)) return "--";
    const now = nowS();
    if (dayKey(ts) === dayKey(now)) return "Today";
    if (dayKey(ts) === dayKey(now + 86400)) return "Tomorrow";
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000));
  }
  function ago(ts) {
    if (!isNum(ts)) return "--";
    const s = Math.max(0, nowS() - ts);
    if (s < 90) return Math.round(s) + "s ago";
    if (s < 5400) return Math.round(s / 60) + " min ago";
    if (s < 172800) return Math.round(s / 3600) + " hr ago";
    return Math.round(s / 86400) + " days ago";
  }
  function setText(id, txt) { const el = $(id); if (el && el.textContent !== txt) el.textContent = txt; }
  function setHTML(id, html) { const el = $(id); if (el && el.innerHTML !== html) el.innerHTML = html; }
  function arrowFor(v, eps) { eps = eps || 0.05; if (!isNum(v)) return ["", ""]; if (v > eps) return ["\u25B2", "up"]; if (v < -eps) return ["\u25BC", "down"]; return ["\u25B6", "flat"]; }
  function setArrow(id, v, eps) { const [ch, cls] = arrowFor(v, eps); const el = $(id); el.textContent = ch; el.setAttribute("class", "arrow " + cls); }
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const clamp01 = (k) => Math.max(0, Math.min(1, k));
  const f1 = (n) => n.toFixed(1);

  /* ---------------- weather icons (filled, muted: ivory sun with a soft copper halo, fog-grey clouds; no outlines) ---------------- */
  document.body.insertAdjacentHTML("afterbegin", `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
    <radialGradient id="gSunGlow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#f3dcc0" stop-opacity=".95"/><stop offset=".42" stop-color="#d9a77f" stop-opacity=".38"/><stop offset="1" stop-color="#d9a77f" stop-opacity="0"/></radialGradient>
    <radialGradient id="gSunCore" cx=".42" cy=".38" r=".7"><stop offset="0" stop-color="#fffaf1"/><stop offset=".7" stop-color="#f4e6d0"/><stop offset="1" stop-color="#dcc3a3"/></radialGradient>
    <linearGradient id="gCloud" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f1f1ec"/><stop offset=".6" stop-color="#cdd1cc"/><stop offset="1" stop-color="#9ea6a3"/></linearGradient>
    <linearGradient id="gCloudD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8d9592"/><stop offset="1" stop-color="#4a5250"/></linearGradient>
    <linearGradient id="gMoonI" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbf6ec"/><stop offset="1" stop-color="#cfc6b6"/></linearGradient>
    <radialGradient id="gMoonLit" cx=".45" cy=".4" r=".65"><stop offset="0" stop-color="#fbf7ef"/><stop offset=".7" stop-color="#e9e2d5"/><stop offset="1" stop-color="#c9bfae"/></radialGradient>
    <radialGradient id="gMoonDark" cx=".5" cy=".5" r=".55"><stop offset="0" stop-color="#2f3534"/><stop offset="1" stop-color="#171b1b"/></radialGradient>
    <linearGradient id="gDrop" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b9cdd2" stop-opacity="0"/><stop offset="1" stop-color="#c9dbe0"/></linearGradient>
  </defs></svg>`);
  const CLOUD = "M18 48h29a9.5 9.5 0 0 0 .8-19 13.5 13.5 0 0 0-25.8-3.4A10.5 10.5 0 0 0 18 48z";
  const SUN_BODY = `<circle cx="60" cy="60" r="50" fill="url(#gSunGlow)"/><circle class="sun-core" cx="60" cy="60" r="21" fill="url(#gSunCore)"/>`;
  const sunI = (x, y, s) => `<svg x="${x}" y="${y}" width="${s}" height="${s}" viewBox="0 0 120 120" overflow="visible">${SUN_BODY}</svg>`;
  const moonI = (tx, ty, s) => `<g transform="translate(${tx} ${ty}) scale(${s})"><path d="M38 10a22 22 0 1 0 17 34A18 18 0 0 1 38 10z" fill="url(#gMoonI)"/></g>`;
  const cloudI = (tx, ty, s, dark) => `<path transform="translate(${tx} ${ty}) scale(${s})" d="${CLOUD}" fill="url(#${dark ? "gCloudD" : "gCloud"})"/>`;
  const dropsI = (n) => (n === 2 ? [26, 38] : [21, 31, 41]).map((x) => `<path d="M${x} 49 l-3.2 10 h2.2 l3.2 -10 z" fill="url(#gDrop)"/>`).join("");
  const boltI = () => `<path d="M34 40 26 53h6l-3 9 10-14h-6l3-8z" fill="#f4efe6"/>`;
  const flakeI = (x, y, r) => `<circle cx="${x}" cy="${y}" r="${r * 0.55}" fill="#f2f2ee"/><circle cx="${x}" cy="${y}" r="${r}" fill="#f2f2ee" opacity=".3"/>`;
  function wicon(name) {
    const n = String(name || "cloudy"), night = n.indexOf("night") >= 0;
    const small = night ? moonI(4, 2, 0.55) : sunI(0, -2, 44);
    let g;
    if (n.startsWith("clear") && !night) return `<svg viewBox="0 0 120 120" aria-hidden="true">${SUN_BODY}</svg>`;
    if (n.startsWith("clear")) g = moonI(6, 4, 1);
    else if (n.startsWith("partly-cloudy")) g = small + cloudI(4, 6, 0.95);
    else if (n === "cloudy") g = cloudI(-6, -6, 0.8, true) + cloudI(4, 4, 0.95);
    else if (n === "foggy") g = cloudI(2, -6, 0.95) + `<rect x="10" y="47" width="38" height="3.4" rx="1.7" fill="#cfd4d0" opacity=".85"/><rect x="18" y="54" width="36" height="3.4" rx="1.7" fill="#cfd4d0" opacity=".6"/>`;
    else if (n.startsWith("possibly-rainy")) g = small + cloudI(4, -2, 0.95) + dropsI(2);
    else if (n === "rainy") g = cloudI(2, -6, 0.95, true) + dropsI(3);
    else if (n.indexOf("sleet") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -6, 0.95, true) + dropsI(2);
    else if (n.indexOf("snow") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -6, 0.95) + flakeI(24, 54, 4) + flakeI(40, 54, 4);
    else if (n.indexOf("thunderstorm") >= 0) g = (n.startsWith("possibly") ? small : "") + cloudI(2, -8, 0.95, true) + boltI();
    else if (n === "windy") g = `<g fill="none" stroke="#d6dad5" stroke-width="3.2" stroke-linecap="round"><path d="M8 24h30a7 7 0 1 0-7-7"/><path d="M8 34h42a7 7 0 1 1-7 7"/><path d="M8 44h20"/></g>`;
    else g = cloudI(2, 2, 0.95);
    return `<svg viewBox="0 0 64 64" aria-hidden="true">${g}</svg>`;
  }

  /* ---------------- moon phase (phase-accurate terminator) ---------------- */
  function moonArt(illumPct, waxing) {
    const k = clamp01((illumPct || 0) / 100), r = 52, cx = 60, cy = 60, top = cy - r, bot = cy + r;
    let lit = "";
    if (k >= 0.995) lit = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonLit)"/>`;
    else if (k > 0.005) {
      const rx = (r * Math.abs(1 - 2 * k)).toFixed(2), crescent = k < 0.5;
      const d = waxing ? `M${cx} ${top} A${r} ${r} 0 0 1 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 0 : 1} ${cx} ${top}Z`
        : `M${cx} ${top} A${r} ${r} 0 0 0 ${cx} ${bot} A${rx} ${r} 0 0 ${crescent ? 1 : 0} ${cx} ${top}Z`;
      lit = `<path d="${d}" fill="url(#gMoonLit)"/>`;
    }
    // earthshine rim keeps a new moon visible against the sky
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#gMoonDark)" stroke="rgba(240,232,218,.45)" stroke-width="2"/>${lit}` +
      `<g fill="#000" opacity=".07"><circle cx="44" cy="40" r="9"/><circle cx="74" cy="50" r="6"/><circle cx="62" cy="80" r="11"/><circle cx="36" cy="70" r="5"/></g>`;
  }

  /* ---------------- temperature: arc over the grove ----------------
     (1.5.1: the tree-ring log slab was removed; the forest shows through inside the arc.) An
     inlaid scale of 45 muted enamel segments (cold slate blue -> sage -> moss -> burnt orange -> brick);
     segments light from the cold end to the current temperature, where a bronze index pin rides the
     arc (it rotates about the arc centre). A copper arc just inside the scale is today's low-high. */
  const TEMP_SCALES = { f: { min: 0, max: 130, labels: [0, 20, 40, 60, 80, 100, 120] }, c: { min: -18, max: 54, labels: [-18, 0, 10, 20, 30, 40, 54] } };
  const HEAT = ["#5d6c8a", "#5b7896", "#5f879c", "#64949a", "#6c9c8e", "#7aa27f", "#8da674", "#a5a778", "#bfa07c", "#c98f68", "#c47a52", "#b5603f", "#9e4a3a", "#843a3c"];
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
  function heatColor(k) {
    const x = clamp01(k) * (HEAT.length - 1), i = Math.min(HEAT.length - 2, Math.floor(x)), t = x - i;
    const a = hex(HEAT[i]), b = hex(HEAT[i + 1]);
    return "rgb(" + a.map((v, j) => Math.round(v + (b[j] - v) * t)).join(",") + ")";
  }
  const AC = { cx: 450, cy: 372, r: 300 }, NT = 45;
  const pol = (cx, cy, r, a) => [cx + Math.sin(a * Math.PI / 180) * r, cy - Math.cos(a * Math.PI / 180) * r];
  function arcD(cx, cy, r, a0, a1) {
    const [x0, y0] = pol(cx, cy, r, a0), [x1, y1] = pol(cx, cy, r, a1);
    return `M${f1(x0)} ${f1(y0)} A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${f1(x1)} ${f1(y1)}`;
  }
  const angOf = (k) => -90 + clamp01(k) * 180;
  function tileD(i) {   // one inlaid enamel segment (annular sector)
    const a0 = angOf(i / NT) + 0.35, a1 = angOf((i + 1) / NT) - 0.35, r0 = AC.r - 11, r1 = AC.r + 12;
    const P = (r, a) => pol(AC.cx, AC.cy, r, a).map(f1).join(" ");
    return `M${P(r0, a0)} L${P(r1, a0)} A${r1} ${r1} 0 0 1 ${P(r1, a1)} L${P(r0, a1)} A${r0} ${r0} 0 0 0 ${P(r0, a0)} Z`;
  }
  let heroUnit = null, litN = -1;
  function buildHero(unit) {
    if (heroUnit === unit) return; heroUnit = unit; litN = -1;
    const S = TEMP_SCALES[unit];
    let base = "", heat = "";
    for (let i = 0; i < NT; i++) {
      const d = tileD(i), [hx1, hy1] = pol(AC.cx, AC.cy, AC.r + 10, angOf((i + 0.12) / NT)), [hx2, hy2] = pol(AC.cx, AC.cy, AC.r + 10, angOf((i + 0.88) / NT));
      base += `<path d="${d}"/>`;
      heat += `<g class="tile" data-i="${i}"><path d="${d}" fill="${heatColor((i + 0.5) / NT)}"/><path class="tile-hl" d="M${f1(hx1)} ${f1(hy1)} L${f1(hx2)} ${f1(hy2)}"/></g>`;
    }
    $("tScale").innerHTML = `<path class="scale-bed" d="${arcD(AC.cx, AC.cy, AC.r, -90.6, 90.6)}"/>` + base;
    $("tHeat").innerHTML = heat;
    $("tBand").setAttribute("d", arcD(AC.cx, AC.cy, AC.r - 21, -90, 90));
    $("tLabels").innerHTML = S.labels.map((v) => { const [x, y] = pol(AC.cx, AC.cy, AC.r + 38, angOf((v - S.min) / (S.max - S.min))); return `<text x="${f1(x)}" y="${f1(y)}">${v}°</text>`; }).join("");
  }
  function rotArc(el, k) { el.style.transform = `rotate(${f1(angOf(k))}deg)`; }
  function fitBigTemp() {
    const t = $("tempNow"); if (!t || !t.getComputedTextLength) return;
    t.style.fontSize = "";
    const max = 430, len = t.getComputedTextLength();
    if (len > max) t.style.fontSize = (parseFloat(getComputedStyle(t).fontSize) * max / len).toFixed(1) + "px";
  }
  let tempShown = null, tempAnim = 0;
  function tweenTemp(to) {   // the big number counts to its new value
    cancelAnimationFrame(tempAnim);
    if (!isNum(to)) { tempShown = null; setText("tempNow", "--"); return; }
    const from = isNum(tempShown) ? tempShown : to, t0 = performance.now(), dur = 900;
    if (from === to || body.classList.contains("lite") || REDUCED) { tempShown = to; setText("tempNow", fx(to) + "°"); return; }
    const step = (t) => { const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); tempShown = from + (to - from) * e; setText("tempNow", tempShown.toFixed(1) + "°"); if (k < 1) tempAnim = requestAnimationFrame(step); else { tempShown = to; setText("tempNow", fx(to) + "°"); } };
    tempAnim = requestAnimationFrame(step);
  }
  function renderHero(T, U) {
    const unit = /C/i.test((U && U.temp) || "") ? "c" : "f", S = TEMP_SCALES[unit];
    buildHero(unit);
    const frac = (v) => clamp01((v - S.min) / (S.max - S.min));
    const now = T.now, lo = (T.low || {}).value, hi = (T.high || {}).value;
    const n = isNum(now) ? Math.max(1, Math.round(frac(now) * NT)) : 0, prev = litN < 0 ? 0 : litN;
    if (n !== litN) {
      document.querySelectorAll("#tHeat .tile").forEach((g) => { const i = +g.dataset.i, on = i < n;
        if (g.classList.contains("on") !== on) { g.style.transitionDelay = (Math.abs(i - (on ? prev : n)) * 22) + "ms"; g.classList.toggle("on", on); } });
      litN = n;
    }
    const star = $("tStar");
    if (isNum(now)) { rotArc(star, frac(now)); $("tFlakeIn").setAttribute("fill", heatColor(frac(now))); star.style.opacity = "1"; } else star.style.opacity = "0";
    if (isNum(lo) && isNum(hi)) {
      const a = frac(Math.min(lo, hi)) * 100, b = Math.max(a + 0.8, frac(Math.max(lo, hi)) * 100);
      $("tBand").setAttribute("stroke-dasharray", `${(b - a).toFixed(2)} 200`); $("tBand").setAttribute("stroke-dashoffset", (-a).toFixed(2)); $("tBand").style.opacity = "";
    } else $("tBand").style.opacity = "0";   // (a zero-length dash would still paint a round cap)
    [["tLoMk", lo], ["tHiMk", hi]].forEach(([id, v]) => { const el = $(id); if (isNum(v)) { rotArc(el, frac(v)); el.style.opacity = "1"; } else el.style.opacity = "0"; });
    tweenTemp(now);
    fitBigTemp();
    setText("lowVal", isNum(lo) ? fx(lo) + "°" : "--");
    setText("highVal", isNum(hi) ? fx(hi) + "°" : "--");
    setText("lowTime", fmtTime((T.low || {}).time));
    setText("highTime", fmtTime((T.high || {}).time));
  }

  /* ---------------- wind: bronze survey compass ---------------- */
  (function buildRose() {
    const C = 150; const P = (r, a) => pol(C, C, r, a).map(f1).join(" ");
    let s = `<defs><radialGradient id="faceG" cx=".5" cy=".42" r=".6"><stop offset="0" stop-color="#2b3130"/><stop offset=".8" stop-color="#1a1e1e"/><stop offset="1" stop-color="#121515"/></radialGradient>` +
      `<linearGradient id="needleG" x1="0" x2="1"><stop offset="0" stop-color="#6b452b"/><stop offset=".45" stop-color="#e2bb94"/><stop offset=".55" stop-color="#b17d55"/><stop offset="1" stop-color="#5a3a24"/></linearGradient>` +
      `<linearGradient id="bezelG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d8ad86"/><stop offset=".3" stop-color="#8f6040"/><stop offset=".55" stop-color="#5c3c26"/><stop offset=".8" stop-color="#a77650"/><stop offset="1" stop-color="#6b472d"/></linearGradient></defs>`;
    s += `<circle cx="${C}" cy="${C}" r="148" fill="url(#bezelG)" stroke="#1a100a" stroke-width="2"/><circle cx="${C}" cy="${C}" r="137" fill="url(#faceG)" stroke="#120c08" stroke-width="2.5"/>`;
    let tk = "";
    for (let i = 0; i < 72; i++) { const a = i * 5, big = i % 9 === 0, mid = i % 3 === 0; if (i % 18 === 0) continue;
      tk += `M${P(134, a)} L${P(big ? 120 : mid ? 125 : 129, a)} `; }
    s += `<path class="rose-tick" d="${tk}"/>`;
    // engraved 8-point compass star: alternating light/dark facets
    let star = "";
    for (let i = 0; i < 8; i++) { const a = i * 45, R = i % 2 ? 60 : 96, w = i % 2 ? 9 : 13;
      star += `<path class="rs-l" d="M${C} ${C} L${P(R, a)} L${P(w, a + 45)} Z"/><path class="rs-d" d="M${C} ${C} L${P(R, a)} L${P(w, a - 45)} Z"/>`; }
    s += star + `<circle cx="${C}" cy="${C}" r="100" class="rose-arm"/>`;
    [["N", 0], ["E", 90], ["S", 180], ["W", 270]].forEach(([l, a]) => { const [x, y] = pol(C, C, 112, a); s += `<text x="${f1(x)}" y="${f1(y)}" class="rose-l${l === "N" ? " n" : ""}">${l}</text>`; });
    $("roseStatic").innerHTML = s;
    // slim bronze needle points to where the wind comes from; ivory tail
    $("needle").innerHTML = `<path class="sh-o" d="M150 18 L159 112 L150 124 L141 112 Z"/><path d="M150 18 L159 112 L150 124 L141 112 Z" fill="url(#needleG)"/>` +
      `<path class="sh-t" d="M150 194 L156 234 L150 252 L144 234 Z"/>`;
  })();
  const SAND_MAX = { mph: 40, "km/h": 64, kph: 64, "m/s": 18, kts: 35, kn: 35 };
  function sandScaleFor(unit) { return SAND_MAX[unit] || 40; }
  let sandUnit = null;
  /* wind-blown rain in the speed rule: streak speed follows the live wind (quantised buckets with hysteresis so the
     CSS animation duration only changes occasionally), streak direction follows the wind direction */
  const DRIFT_B = [[1, 14], [3, 8], [6, 5.2], [10, 3.4], [15, 2.4], [22, 1.7], [30, 1.2]];
  let driftIdx = -2, driftDirRev = null;
  function setDriftRate(speed, dir) {
    let idx = -1; if (isNum(speed)) DRIFT_B.forEach(([s], i) => { if (speed >= s) idx = i; });
    if (driftIdx >= 0 && idx >= 0 && idx !== driftIdx && isNum(speed)) {   // hysteresis: need 0.8 past the boundary
      const edge = idx > driftIdx ? DRIFT_B[idx][0] : DRIFT_B[driftIdx][0];
      if (Math.abs(speed - edge) < 0.8) idx = driftIdx;
    }
    if (idx !== driftIdx) {
      driftIdx = idx;
      body.style.setProperty("--drift", (idx >= 0 ? DRIFT_B[idx][1] : 14) + "s");
      body.style.setProperty("--drift-o", idx < 0 ? "0" : (0.35 + 0.65 * idx / (DRIFT_B.length - 1)).toFixed(2));
      body.style.setProperty("--roll", (idx >= 0 ? DRIFT_B[idx][1] / 2.5 : 4).toFixed(2) + "s");
      body.classList.toggle("calm-air", idx < 0);
    }
    if (isNum(dir)) { const rev = dir > 0 && dir < 180; if (rev !== driftDirRev) { driftDirRev = rev; body.classList.toggle("drift-rev", rev); } }
  }
  function setSand(speed, gust, unit, dir) {
    const max = sandScaleFor(unit);
    if (sandUnit !== unit) { sandUnit = unit; $("sandScale").innerHTML = [0, .25, .5, .75, 1].map((k) => `<span>${Math.round(max * k)}</span>`).join(""); }
    const k = isNum(speed) ? clamp01(speed / max) : 0;
    $("driftMask").style.transform = `translateX(${((k - 1) * 100).toFixed(2)}%)`;
    $("driftIn").style.transform = `translateX(${((1 - k) * 100).toFixed(2)}%)`;
    $("ballMove").style.transform = `translateX(${(k * 100).toFixed(2)}%)`;
    $("ballMove").classList.toggle("rolling", isNum(speed) && speed >= 1);
    const gm = $("gustMove");
    if (isNum(gust) && gust > 0) { gm.style.transform = `translateX(${(clamp01(gust / max) * 100).toFixed(2)}%)`; gm.style.opacity = "1"; } else gm.style.opacity = "0";
    setDriftRate(speed, dir);
  }
  function tweenWind(to) {
    cancelAnimationFrame(windAnim);
    if (!isNum(to)) { windShown = null; setText("windNow", "--"); return; }
    const from = isNum(windShown) ? windShown : to, t0 = performance.now(), dur = 280;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      windShown = from + (to - from) * e; setText("windNow", windShown.toFixed(1));
      if (k < 1) windAnim = requestAnimationFrame(step); else windShown = to;
    };
    if (from === to || body.classList.contains("lite")) { windShown = to; setText("windNow", fx(to)); } else windAnim = requestAnimationFrame(step);
  }
  function setWind(speed, dir, dirCard, fallbackTxt, calm, unit, gust) {
    tweenWind(speed);
    setText("windNowUnit", unit || "mph");
    setHTML("windDir", isNum(dir) ? `${esc(dirCard || "--")}<span class="unit">${fi(dir)}°</span>` : esc(fallbackTxt || "--"));
    const f = $("needle");
    if (isNum(dir)) {
      if (needleAngle === null) needleAngle = dir;
      else { const delta = ((dir - needleAngle) % 360 + 540) % 360 - 180; needleAngle += delta; }
      f.style.transform = `rotate(${needleAngle}deg)`;
    }
    f.classList.toggle("calm", !!calm);
    f.style.opacity = isNum(dir) ? "" : "0";
    setSand(speed, gust, unit || "mph", dir);
    setRainTilt(speed, dir);
  }
  /* rain slant: streaks lean downwind (east wind component -> lean right), up to ~24 degrees */
  let tiltShown = null;
  function setRainTilt(speed, dir) {
    let t = 0;
    if (isNum(speed) && isNum(dir) && speed >= 1) t = -Math.sin(dir * Math.PI / 180) * Math.min(24, speed * 1.6);
    t = Math.round(t);
    if (t !== tiltShown) { tiltShown = t; body.style.setProperty("--tilt", (-t) + "deg"); }
  }
  const CARD16 = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  function onRapidWind(w) {
    if (!DATA || !isNum(w.speed)) return;
    const W = DATA.wind = DATA.wind || {};
    const calm = w.calm != null ? !!w.calm : w.speed < 1;
    const dir = isNum(w.dir) ? w.dir : W.dir;
    const card = w.dir_cardinal || (isNum(dir) ? CARD16[Math.round(dir / 22.5) % 16] : null);
    Object.assign(W, { speed: w.speed, dir: dir, calm: calm, dir_cardinal: card, cardinal: calm ? "Calm" : card });
    if (isNum(w.gust)) { W.gust = w.gust; setText("gustNow", fx(w.gust)); }
    setWind(w.speed, dir, card, W.cardinal, calm, (DATA.units && DATA.units.wind) || w.unit, W.gust);
  }

  /* ---------------- barometer: soil core sample ----------------
     A core pulled from the forest floor: the layers are the pressure zones (sandstone "very dry" at
     the top, wet clay "rain", slate "stormy" at the bottom) with pebbles and grain. A sage ledge +
     bronze arrow marks the current pressure, chevrons show the trend, dashed lines are today's low/high. */
  const BZ = [[1040, 1050, "#c9bb9f", "Very dry", "#2a2018"], [1020, 1040, "#a68b69", "Fair", "#1f170f"], [1000, 1020, "#7b5f45", "Change", "#f4ece0"],
    [980, 1000, "#4d3b2e", "Rain", "#f4ece0"], [950, 980, "#323b42", "Stormy", "#f4ece0"]];
  let baroP = null;
  function setBaro(P) { baroP = P; drawStrata(); }
  function drawStrata() {
    const box = $("strataBox"); if (!box || !baroP) return;
    const W = box.clientWidth, H = box.clientHeight; if (!W || !H) return;
    const P = baroP, isIn = (DATA && DATA.units && DATA.units.pressure) === "inHg", toMb = (v) => (isIn ? v * 33.8639 : v);
    const lmb = P.low && isNum(P.low.value) ? toMb(P.low.value) : null, hmb = P.high && isNum(P.high.value) ? toMb(P.high.value) : null;
    const sig = JSON.stringify([P.slp_mb, P.trend, lmb, hmb, W, H]);
    if (box.dataset.sig === sig) return;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    const aw = u * 2.0, X0 = aw + u * 0.35, X1 = W - 1, pad = 3, rx = Math.min(u * 0.9, (X1 - X0) * 0.12);
    const y = (mb) => pad + (1050 - Math.max(950, Math.min(1050, mb))) / 100 * (H - 2 * pad);
    const wav = (yy, k) => `M${f1(X0)} ${f1(yy)} C${f1(X0 + (X1 - X0) * 0.3)} ${f1(yy - k * u * 0.22)} ${f1(X0 + (X1 - X0) * 0.65)} ${f1(yy + k * u * 0.25)} ${f1(X1)} ${f1(yy - k * u * 0.1)}`;
    let g = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-label="pressure soil core"><defs><clipPath id="coreClip"><rect x="${f1(X0)}" y="${pad}" width="${f1(X1 - X0)}" height="${f1(H - 2 * pad)}" rx="${f1(rx)}"/></clipPath>` +
      `<linearGradient id="coreSh" x1="0" x2="1"><stop offset="0" stop-color="#000" stop-opacity=".35"/><stop offset=".14" stop-color="#fff" stop-opacity=".16"/><stop offset=".32" stop-color="#fff" stop-opacity=".02"/><stop offset=".8" stop-color="#000" stop-opacity=".12"/><stop offset="1" stop-color="#000" stop-opacity=".45"/></linearGradient></defs><g clip-path="url(#coreClip)">`;
    BZ.forEach(([lo, hi, col], i) => {
      const yt = y(hi), yb = y(lo), k = i % 2 ? 1 : -1;
      g += `<path d="${wav(yt, k)} L${f1(X1)} ${f1(yb + 2)} L${f1(X0)} ${f1(yb + 2)} Z" fill="${col}"/>`;
      g += `<path d="${wav(yt + (yb - yt) * 0.6, -k)}" stroke="${i < 2 ? "rgba(60,40,20,.22)" : "rgba(255,240,220,.10)"}" stroke-width="1.5" fill="none"/>`;
      for (let b = 0; b < 4; b++) { const bx = X0 + (X1 - X0) * (0.62 + ((i * 3 + b * 7) % 10) / 30), by = yt + (yb - yt) * (0.2 + ((i * 5 + b * 3) % 7) / 10), br = u * (0.1 + ((i + b) % 3) * 0.05);
        g += `<ellipse cx="${f1(bx)}" cy="${f1(by)}" rx="${f1(br * 1.5)}" ry="${f1(br)}" class="bub${i < 2 ? "" : " lt"}"/>`; }
    });
    g += `<rect x="${f1(X0)}" y="${pad}" width="${f1(X1 - X0)}" height="${f1(H - 2 * pad)}" fill="url(#grainPat)" opacity=".55"/><rect x="${f1(X0)}" y="${pad}" width="${f1(X1 - X0)}" height="${f1(H - 2 * pad)}" fill="url(#coreSh)"/></g>`;
    g += `<rect x="${f1(X0)}" y="${pad}" width="${f1(X1 - X0)}" height="${f1(H - 2 * pad)}" rx="${f1(rx)}" fill="none" stroke="rgba(0,0,0,.6)" stroke-width="2"/>`;
    const fz = Math.min(u * 0.82, (H - 2 * pad) / 5 * 0.62);
    BZ.forEach(([lo, hi, , name, tc]) => { g += `<text x="${f1(X0 + u * 0.55)}" y="${f1((y(lo) + y(hi)) / 2)}" class="z-l" fill="${tc}" font-size="${f1(fz)}">${name}</text>`; });
    [[lmb, "L"], [hmb, "H"]].forEach(([v]) => { if (isNum(v)) g += `<path class="bl-mk" d="M${f1(X0)} ${f1(y(v))} H${f1(X1)}"/>`; });
    if (isNum(P.slp_mb)) {
      const ym = y(P.slp_mb), ah = u * 0.75;
      g += `<path class="b-ledge-o" d="M${f1(aw * 0.6)} ${f1(ym)} H${f1(X1 - u * 0.1)}"/><path class="b-ledge" d="M${f1(aw * 0.6)} ${f1(ym)} H${f1(X1 - u * 0.1)}"/><path class="b-arrow" d="M1 ${f1(ym - ah)} L${f1(aw)} ${f1(ym)} L1 ${f1(ym + ah)} Z"/>`;
      const tr = P.trend, n = !isNum(tr) || Math.abs(tr) < 0.3 ? 0 : Math.abs(tr) < 1.5 ? 1 : 2, up = tr > 0, cw = aw * 0.38, cx = aw * 0.42;
      for (let i = 0; i < n; i++) {
        const yy = up ? ym - ah - u * 0.55 - i * u * 0.6 : ym + ah + u * 0.55 + i * u * 0.6, d = up ? -1 : 1;
        g += `<path class="b-chev ${up ? "up" : "down"}" d="M${f1(cx - cw)} ${f1(yy - d * cw * 0.6)} L${f1(cx)} ${f1(yy + d * cw * 0.4)} L${f1(cx + cw)} ${f1(yy - d * cw * 0.6)}"/>`;
      }
    }
    box.innerHTML = g + `</svg>`; box.dataset.sig = sig;
  }

  /* ---------------- humidity / UV ---------------- */
  let humK = 0;
  function placeHum() { const m = $("humMove"); if (m) m.style.transform = `translateX(${(humK * 100).toFixed(2)}%)`; }
  const UV_COL = ["#6f9a6c", "#6f9a6c", "#7c9a70", "#b98a5e", "#c27d52", "#c4704a", "#b85c3e", "#a94c3a", "#9a3e3c", "#883346", "#6e3156"];
  (function buildUV() {   // eleven sun discs (enamel inlays) light up with the UV index
    let s = "";
    for (let i = 0; i < 11; i++) { const cx = 20 + i * 40, cy = 20;
      s += `<g class="uvg" data-i="${i}" style="--c:${UV_COL[i]}"><circle class="uvr" cx="${cx}" cy="${cy}" r="15"/><circle class="uvd" cx="${cx}" cy="${cy}" r="10"/><circle class="uvh" cx="${cx - 3}" cy="${cy - 3.5}" r="3.2"/></g>`; }
    $("uvGlyphs").innerHTML = s;
  })();
  function humText(rh, dew, unit) {
    if (!isNum(rh)) return "--";
    let dp = dew; if (isNum(dp) && unit === "°C") dp = dp * 9 / 5 + 32;
    if (isNum(dp)) { if (dp < 50) return "Dry"; if (dp < 60) return "Comfortable"; if (dp < 65) return "Sticky"; if (dp < 70) return "Humid"; return "Oppressive"; }
    return rh < 30 ? "Dry" : rh < 60 ? "Comfortable" : "Humid";
  }
  const uvText = (uv) => (uv < 3 ? "Low" : uv < 6 ? "Moderate" : uv < 8 ? "High" : uv < 11 ? "Very high" : "Extreme");

  /* ---------------- next 12 hours: the treeline ---------------- */
  function smoothPath(pts) {
    if (pts.length < 2) return "";
    let d = `M${f1(pts[0][0])} ${f1(pts[0][1])}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      d += ` C${f1(p1[0] + (p2[0] - p0[0]) / 6)} ${f1(p1[1] + (p2[1] - p0[1]) / 6)} ${f1(p2[0] - (p3[0] - p1[0]) / 6)} ${f1(p2[1] - (p3[1] - p1[1]) / 6)} ${f1(p2[0])} ${f1(p2[1])}`;
    }
    return d;
  }
  function treeline(W, H, base, seed0) {   // distant conifer skyline: many narrow spires on a soft base line
    let sd = seed0; const r = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
    let d = `M-10 ${H}`, x = -10;
    while (x < W + 10) {
      const y0 = base(x), h = 6 + r() * 16, w = 5 + r() * 7;
      d += ` L${f1(x)} ${f1(y0)} L${f1(x + w * 0.5)} ${f1(y0 - h)} L${f1(x + w)} ${f1(y0)}`;
      x += w * (0.55 + r() * 0.5);
    }
    return d + ` L${W + 10} ${H} Z`;
  }
  let hourList = [];
  function renderHourly(hours) { hourList = hours.slice(0, 12); drawDunes(); }
  function drawDunes() {
    const el = $("hours"), W = el.clientWidth, H = el.clientHeight;
    const list = hourList;
    if (!W || !H) return;
    if (!list.length) { setHTML("hours", `<div class="label dunes-none">Hourly forecast unavailable</div>`); el.dataset.sig = ""; return; }
    const sig = JSON.stringify([list.map((h) => [h.time, h.temp, h.icon, h.precip]), W, H, h24]);
    if (el.dataset.sig === sig) return;
    const u = Math.min(window.innerWidth / 100, window.innerHeight * 1.7778 / 100);
    const n = list.length, cw = W / 12;
    const temps = list.map((h) => h.temp).filter(isNum);
    const mn = Math.min.apply(null, temps), mx = Math.max.apply(null, temps), span = Math.max(1, mx - mn);
    const fsH = u * 1.05, fsT = u * 1.55, fsP = u * 0.95, ic = Math.min(cw * 0.62, H * 0.27);
    const yHour = fsH * 1.05;
    const crestTop = yHour + fsH * 0.5 + ic + fsT * 1.25;
    const crestBot = H - fsP * 2.2;
    const pts = list.map((h, i) => [(i + 0.5) * cw, isNum(h.temp) ? crestTop + (1 - (h.temp - mn) / span) * (crestBot - crestTop) : (crestTop + crestBot) / 2]);
    const ext = [[-cw * 0.5, pts[0][1] + 6], ...pts, [W + cw * 0.5, pts[n - 1][1] + 6]];
    const line = smoothPath(ext);
    const yAt = (x) => { const i = Math.max(0, Math.min(n - 1, Math.floor(x / cw))); const j = Math.min(n - 1, i + 1), t = clamp01((x - (i + 0.5) * cw) / cw); return pts[i][1] + (pts[j][1] - pts[i][1]) * t; };
    const back = treeline(W, H, (x) => Math.min(H - 4, yAt(x) - fsT * 0.15), 1234);
    let s = `<svg class="dune-svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-label="next 12 hours"><defs>
      <linearGradient id="ridgeG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a4a36"/><stop offset=".5" stop-color="#26321f"/><stop offset="1" stop-color="#161d14"/></linearGradient>
      <linearGradient id="ridgeB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6c7b6c"/><stop offset="1" stop-color="#3e4a40"/></linearGradient></defs>`;
    s += `<path class="dune-back" d="${back}"/>`;
    s += `<path class="dune-front" d="${line} L${W + cw} ${H} L${-cw} ${H} Z"/><path class="dune-crest" d="${line}"/>`;
    list.forEach((h, i) => {
      const [x, y] = pts[i];
      s += `<text class="dh${i === 0 ? " now" : ""}" x="${f1(x)}" y="${f1(yHour)}" font-size="${f1(fsH)}">${esc(i === 0 ? "Now" : fmtHour(h.time))}</text>`;
      const iy = y - fsT * 1.2 - ic;
      const wi = wicon(h.icon), vb = (wi.match(/viewBox="([^"]+)"/) || [0, "0 0 64 64"])[1];
      s += `<svg x="${f1(x - ic / 2)}" y="${f1(iy)}" width="${f1(ic)}" height="${f1(ic)}" viewBox="${vb}" overflow="visible">${wi.replace(/^<svg[^>]*>|<\/svg>$/g, "")}</svg>`;
      s += `<text class="dt" x="${f1(x)}" y="${f1(y - fsT * 0.3)}" font-size="${f1(fsT)}">${fi(h.temp)}°</text>`;
      const p = isNum(h.precip) ? h.precip : null;
      if (p !== null) s += `<text class="dp${p ? "" : " zero"}" x="${f1(x)}" y="${f1(Math.min(H - fsP * 0.4, y + fsP * 1.6))}" font-size="${f1(fsP)}">${p ? "\u{1F4A7}" + fi(p) + "%" : "0%"}</text>`;
    });
    s += `</svg>`;
    el.innerHTML = s; el.dataset.sig = sig;
  }
  const ro = window.ResizeObserver && new ResizeObserver(() => { drawDunes(); drawCairns(); drawStrata(); placeHum(); }); ["grid", "ltBars", "hours", "strataBox"].forEach((id) => { const e = document.getElementById(id); if (e && window.ResizeObserver) ro.observe(e); });

  /* ---------------- lightning: storm over the grove, river-stone chart ---------------- */
  function strikeRecentRed(L) { return isNum(L.last_epoch) && nowS() - L.last_epoch < 600; }
  function lightningActive(L) { return isNum(L.last_epoch) && nowS() - L.last_epoch < 1800; }
  function setLamp(el, color, blink) {
    if (!el) return;
    const sm = el.classList.contains("sm") ? " sm" : "", extra = el.classList.contains("lt-lamp") ? " lt-lamp" : "";
    const cls = "lamp" + sm + extra + (color ? " " + color : "") + (blink ? " blink" : "");
    if (el.className !== cls) el.className = cls;
  }
  function strikeWhen(ts) {
    if (!isNum(ts)) return "";
    if (dayKey(ts) === dayKey(nowS())) return "at " + fmtTime(ts);
    return new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short", day: "numeric" }).format(new Date(ts * 1000)) + ", " + fmtTime(ts);
  }
  function flashLightning() {
    const c = $("ltCard"); c.classList.remove("flash"); void c.offsetWidth; c.classList.add("flash");
    const b = $("strikeBadge"); b.classList.remove("zap"); void b.offsetWidth; b.classList.add("zap");
  }
  function onStrike(e) {
    if (!DATA || !isNum(e.epoch)) return;
    const ep = e.epoch + OFFSET / 1000;
    const L = DATA.lightning = DATA.lightning || {};
    if (!isNum(L.last_epoch) || ep >= L.last_epoch) { L.last_epoch = ep; L.last_distance = e.distance; }
    ["count_1h", "count_3h", "count_today", "count_month", "count_30m"].forEach((k) => { L[k] = (isNum(L[k]) ? L[k] : 0) + 1; });
    if (isNum(e.distance)) L.nearest_30m = isNum(L.nearest_30m) ? Math.min(L.nearest_30m, e.distance) : e.distance;
    if (Array.isArray(L.hourly) && L.hourly.length) {
      const hr = Math.floor(ep / 3600) * 3600; let last = L.hourly[L.hourly.length - 1];
      while (last.time < hr) { L.hourly.shift(); last = { time: last.time + 3600, count: 0, min_distance: null }; L.hourly.push(last); }
      if (last.time === hr) last.count += 1;
    }
    renderLightning(L, DATA.units || {}); updateStrikeBadge(); flashLightning();
  }
  let cairnData = null;
  function drawCairns() {   // stacked river stones: one cairn per hour
    const el = $("ltBars"); if (!cairnData || !el) return;
    const { counts, active } = cairnData, W = el.clientWidth, H = el.clientHeight;
    if (!W || !H) return;
    const sig = JSON.stringify([counts, active, W, H]);
    if (el.dataset.sig === sig) return;
    const n = counts.length, mx = Math.max(1, Math.max.apply(null, counts)), cw = W / n, MAXS = 6;
    const sh = (H - 3) / MAXS, sw = Math.min(cw * 0.8, sh * 1.5);
    let s = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-label="strikes per hour, last ${n} hours">`;
    s += `<path class="cairn-ground" d="M0 ${H - 1.5} H${W}"/>`;
    counts.forEach((c, i) => {
      if (!c) return;
      const k = Math.max(1, Math.round(Math.sqrt(c / mx) * MAXS)), now = i === n - 1 && active;
      let g = `<g class="cairn${now ? " now" : ""}"><title>${c} strikes</title>`;
      for (let j = 0; j < k; j++) {
        const x = (i + 0.5) * cw - sw / 2, y = H - 3 - (j + 1) * sh + 0.8, bh = sh - 1.6;
        const ww = sw * (0.82 + ((i * 7 + j * 3) % 5) * 0.045), xx = (i + 0.5) * cw - ww / 2;
        g += `<rect class="st${(i + j) % 3}" x="${f1(xx)}" y="${f1(y)}" width="${f1(ww)}" height="${f1(bh)}" rx="${f1(Math.min(ww / 2, bh * 0.5))}"/>` +
          `<path class="blk-hl" d="M${f1(xx + ww * 0.25)} ${f1(y + bh * 0.3)} H${f1(xx + ww * 0.6)}"/>`;
      }
      s += g + `</g>`;
    });
    el.innerHTML = s + `</svg>`; el.dataset.sig = sig;
  }
  function renderLightning(L, U) {
    const dist = U.distance || "mi", has = isNum(L.last_epoch), active = lightningActive(L), red = active && strikeRecentRed(L);
    $("ltCard").classList.toggle("active", active);
    $("ltCard").classList.toggle("near", red);
    setLamp($("ltLamp"), active ? (red ? "red" : "amber") : "", active);
    const near = isNum(L.nearest_30m) ? L.nearest_30m : L.last_distance;
    body.classList.toggle("lt-storm", red && isNum(L.last_distance) && L.last_distance <= (dist === "km" ? 16 : 10));   // storm over the grove + sky flash when a strike is close and recent
    const noData = !has && !isNum(L.count_1h) && !isNum(L.count_3h) && !isNum(L.count_today);
    setText("ltStatusText", active ? `Active \u00b7 ${fi(near)} ${dist}` : noData ? "No data" : "No strikes nearby");
    setText("ltDist", has && isNum(L.last_distance) ? fi(L.last_distance) : "--");
    setText("ltUnit", dist);
    setText("ltAgo", has ? ago(L.last_epoch) : noData ? "--" : "No strikes detected");
    setText("ltWhen", has ? strikeWhen(L.last_epoch) : "\u00a0");
    [["ltC1", L.count_1h], ["ltC3", L.count_3h], ["ltCT", L.count_today], ["ltCM", L.count_month]].forEach(([id, v]) => { setText(id, fi(v)); $(id).classList.toggle("zero", fi(v) === "0"); });
    const hrs = Array.isArray(L.hourly) ? L.hourly : null;
    if (!hrs || !hrs.length) { cairnData = null; setHTML("ltBars", `<div class="lt-none">Hourly history unavailable</div>`); $("ltBars").dataset.sig = ""; setText("ltPeak", ""); $("ltAxis").classList.add("hidden"); return; }
    $("ltAxis").classList.remove("hidden");
    const counts = hrs.map((b) => (isNum(b.count) ? b.count : 0)), total = counts.reduce((a, b) => a + b, 0);
    setText("ltPeak", total ? `${total} in ${hrs.length}h` : `None in ${hrs.length}h`);
    $("ltAxis").children[0].textContent = hrs.length + "h ago"; $("ltAxis").children[1].textContent = Math.round(hrs.length / 2) + "h";
    cairnData = { counts, active }; drawCairns();
  }

  /* ---------------- small text fitting helpers ---------------- */
  function fitOne(el, minK) {
    if (!el) return;
    const key = el.textContent + "|" + el.clientWidth; if (el.dataset.fit === key) return; el.dataset.fit = key;
    el.style.fontSize = ""; el.classList.remove("two");
    const base = parseFloat(getComputedStyle(el).fontSize);
    for (let f = base; el.scrollWidth > el.clientWidth + 0.5 && f > base * minK; ) { f *= 0.95; el.style.fontSize = f + "px"; }
    if (el.scrollWidth > el.clientWidth + 0.5) { el.style.fontSize = ""; el.classList.add("two"); }
  }
  const FIT = ["heroCond", "fcUntil", "moonName", "fcTmCond", "baroTendency"];
  function fitAll() { FIT.forEach((id) => fitOne($(id), 0.72)); document.querySelectorAll(".card-head .tag").forEach((t) => fitOne(t, 0.72)); fitBigTemp(); }
  window.addEventListener("resize", () => { FIT.forEach((id) => { const e = $(id); if (e) e.dataset.fit = ""; }); document.querySelectorAll(".card-head .tag").forEach((t) => { t.dataset.fit = ""; }); fitAll(); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { FIT.forEach((id) => { const e = $(id); if (e) e.dataset.fit = ""; }); fitAll(); if ($("hours")) $("hours").dataset.sig = ""; drawDunes(); });


  /* ---------------- animation layer ----------------
     Rain streak tiles are generated once as SVG data-URIs and painted as CSS backgrounds on HTML layers;
     CSS keyframes move those layers one tile per loop with transform only (seamless), inside a wrapper
     rotated by the live wind. Fog is a static seamless WebP drifted with translateX. No JS per frame.
     Hidden page -> animations paused. */
  const REDUCED = !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);
  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const uri = (svg) => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
  function rainTex(n, size, Lmin, Lmax, wmin, wmax, omin, omax) {   // seamless vertical tile of rain streaks
    let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8eeec" stop-opacity="0"/><stop offset=".75" stop-color="#eef3f1" stop-opacity=".75"/><stop offset="1" stop-color="#ffffff"/></linearGradient></defs>`;
    for (let i = 0; i < n; i++) { const x = rnd() * size, y = rnd() * size, L = Lmin + rnd() * (Lmax - Lmin), w = wmin + rnd() * (wmax - wmin), o = (omin + rnd() * (omax - omin)).toFixed(2);
      [0, -size].forEach((dy) => { const yy = y + dy; if (yy + L < 0 || yy > size) return;
        s += `<rect x="${f1(x)}" y="${f1(yy)}" width="${w.toFixed(2)}" height="${f1(L)}" rx="${(w / 2).toFixed(2)}" fill="url(#g)" opacity="${o}"/>`; }); }
    return uri(s + `</svg>`);
  }
  function driftTex(n) {   // horizontal wind-blown rain streaks for the speed rule, tiles seamlessly in x
    let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 100" preserveAspectRatio="none">`;
    for (let i = 0; i < n; i++) { const x = rnd() * 400, y = 8 + rnd() * 84, L = 18 + rnd() * 50, w = 1 + rnd() * 1.4, o = (0.3 + rnd() * 0.45).toFixed(2);
      [0, -400, 400].forEach((dx) => { const x0 = x + dx; if (x0 > 400 || x0 + L < 0) return;
        s += `<path d="M${f1(x0)} ${f1(y)} h${f1(L)}" stroke="#eef3f1" stroke-width="${w.toFixed(2)}" stroke-linecap="round" opacity="${o}"/>`; }); }
    return uri(s + `</svg>`);
  }
  (function buildAnimLayers() {
    const css = [];
    seed = 101; css.push(`.rain.r1{background-image:${rainTex(70, 400, 16, 34, 0.9, 1.3, 0.35, 0.7)}}`);
    seed = 202; css.push(`.rain.r2{background-image:${rainTex(30, 400, 34, 66, 1.2, 1.8, 0.45, 0.8)}}`);
    seed = 303; css.push(`.rain.r3{background-image:${rainTex(11, 400, 70, 120, 1.8, 2.6, 0.5, 0.85)}}`);
    seed = 909; css.push(`.drift-strip{background-image:${driftTex(22)}}`);
    css.push(`.hs-storm{background-image:${uri(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 440" preserveAspectRatio="xMidYMax slice"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d1012" stop-opacity=".78"/><stop offset=".55" stop-color="#1b2124" stop-opacity=".35"/><stop offset="1" stop-color="#1b2124" stop-opacity="0"/></linearGradient></defs><rect width="900" height="300" fill="url(#g)"/></svg>`)}}`);
    css.push(`.hs-flash{background-image:${uri(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 440" preserveAspectRatio="xMidYMax slice"><g fill="none" stroke-linejoin="round" stroke-linecap="round">` +
      `<path d="M168 0 L156 40 L170 46 L148 98 L162 102 L140 164" stroke="#cfd8e6" stroke-width="16" opacity=".35"/><path d="M168 0 L156 40 L170 46 L148 98 L162 102 L140 164" stroke="#ffffff" stroke-width="4.5"/><path d="M156 40 L138 58 M148 98 L130 110" stroke="#fff" stroke-width="2" opacity=".85"/>` +
      `<path d="M792 0 L782 34 L794 38 L776 84" stroke="#cfd8e6" stroke-width="12" opacity=".3"/><path d="M792 0 L782 34 L794 38 L776 84" stroke="#ffffff" stroke-width="3.2"/></g></svg>`)}, radial-gradient(ellipse 70% 70% at 30% 0%, rgba(236, 240, 246, .8), rgba(210, 220, 232, .28) 45%, rgba(210, 220, 232, 0) 75%)}`);   // bolt + glow share one flash layer
    const st = document.createElement("style"); st.textContent = css.join("\n"); document.head.appendChild(st);
    const fl = document.createElement("div"); fl.className = "flash hs-flash"; $("tWrap").insertBefore(fl, $("tScene"));
  })();
  document.addEventListener("visibilitychange", () => body.classList.toggle("paused", document.hidden));
  if (MOCK && params.get("still") === "1") body.classList.add("still");   // mock-only: freeze motion for static screenshots
  if (MOCK && params.get("flash") === "1") body.classList.add("flash-peak");   // mock-only: freeze the storm animation at its flash peak (preview)

  /* ---------------- clock ---------------- */
  let lastDateMin = -1;
  function tickClock() {
    const d = new Date(nowMs());
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", second: "2-digit", hour12: !h24 }).formatToParts(d);
    let h = "", m = "", sec = "", ap = "";
    parts.forEach((p) => { if (p.type === "hour") h = p.value; else if (p.type === "minute") m = p.value; else if (p.type === "second") sec = p.value; else if (p.type === "dayPeriod") ap = p.value; });
    if (h24 && h === "24") h = "00";
    setText("clock", h + ":" + m); setText("clockSec", ":" + sec); setText("ampm", ap);
    const minKey = Math.floor(d.getTime() / 60000);
    if (minKey !== lastDateMin) { lastDateMin = minKey; setText("date", new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric" }).format(d)); }
  }
  function clockLoop() { tickClock(); setTimeout(clockLoop, 1000 - (Date.now() % 1000) + 15); }

  /* ---------------- mock-only test values (same as Industrial) ---------------- */
  function applyMockOverrides(d) {
    if (!MOCK || !d) return d;
    d = JSON.parse(JSON.stringify(d));
    const F = d.forecast || {}, N = F.now || {};
    if (params.has("fc_until")) N.until = params.get("fc_until");
    if (params.has("fc_temp")) N.temp = parseFloat(params.get("fc_temp"));
    if (params.has("fc_wind")) N.wind = parseFloat(params.get("fc_wind"));
    if (params.has("fc_dir")) N.wind_dir = params.get("fc_dir");
    if (params.has("fc_icon")) N.icon = params.get("fc_icon");
    const M = (d.astro && d.astro.moon) || {};
    if (params.has("moon_illum")) M.illumination = parseFloat(params.get("moon_illum"));
    if (params.has("moon_waxing")) M.waxing = params.get("moon_waxing") === "1";
    if (params.has("moon_name")) M.name = params.get("moon_name");
    if (params.has("moon_set")) M.set = null;
    if (params.has("rain_rate") && d.rain) { const rr = parseFloat(params.get("rain_rate")); d.rain.rate = rr; d.rain.rate_text = rr >= 0.3 ? "Heavy rain" : rr >= 0.1 ? "Moderate rain" : rr > 0 ? "Light rain" : "Currently Dry"; if (rr > 0 && !(d.rain.today > 0)) d.rain.today = 0.42; }
    if (params.has("temp") && d.temp) {
      const raw = params.get("temp"), v = raw === "none" || raw === "" ? null : parseFloat(raw);
      d.temp.now = isNum(v) ? v : null;
      if (isNum(v)) { d.temp.feels = v; d.temp.high = Object.assign({}, d.temp.high, { value: Math.max(v, (d.temp.high || {}).value ?? v) }); d.temp.low = Object.assign({}, d.temp.low, { value: Math.min(v, (d.temp.low || {}).value ?? v) }); }
    }
    if (params.get("tunit") === "c" && d.temp) {
      const c = (f) => (isNum(f) ? Math.round((f - 32) / 1.8 * 10) / 10 : f), t = d.temp;
      t.now = c(t.now); t.feels = c(t.feels); t.dew = c(t.dew);
      if (t.high) t.high.value = c(t.high.value); if (t.low) t.low.value = c(t.low.value);
      d.units = Object.assign({}, d.units, { temp: "\u00B0C" });
    }
    if (MOCK_TIME) {   // shift the demo data to the overridden clock
      const off = OFFSET / 1000, A = d.astro || {}, now = nowS();
      const isDay = (t) => isNum(A.sunrise) && isNum(A.sunset) ? t >= A.sunrise && t < A.sunset : true;
      const dn = (ic, t) => String(ic || "").replace(isDay(t) ? "-night" : "-day", isDay(t) ? "-day" : "-night");
      ["obs_time", "server_time"].forEach((k) => { if (isNum(d[k])) d[k] += off; });
      const L = d.lightning || {};
      if (isNum(L.last_epoch)) L.last_epoch += off;
      if (Array.isArray(L.hourly)) L.hourly.forEach((b) => { if (isNum(b.time)) b.time += off; });
      const start = Math.ceil(now / 3600) * 3600;
      (F.hourly || []).forEach((h, i) => { h.time = start + i * 3600; h.icon = dn(h.icon, h.time); });
      if (N.icon) N.icon = dn(N.icon, now);
      A.is_day = isDay(now);
    }
    return d;
  }

  /* background rain intensity: always present; heavier when the gauge reports a rain rate */
  let rainLvl = null;
  function setRainLevel(rate, pu) {
    const heavy = pu === "mm" ? 2.5 : 0.1, lvl = !isNum(rate) || rate <= 0 ? "dry" : rate >= heavy ? "heavy" : "light";
    if (lvl !== rainLvl) { if (rainLvl) body.classList.remove("rain-" + rainLvl); rainLvl = lvl; body.classList.add("rain-" + lvl); }
  }

  /* ---------------- render ---------------- */
  let DEMO_RAW = false;   // mock-only hook used by the animation recording: window.__wxdemo(fn) re-renders with edited data
  if (MOCK) window.__wxdemo = (fn) => { const d = JSON.parse(JSON.stringify(DATA)); fn(d); DEMO_RAW = true; render(d); };
  function render(d) {
    d = DEMO_RAW ? d : applyMockOverrides(d); DEMO_RAW = false;
    DATA = d;
    tz = (d.station && d.station.tz) || tz;
    updateNight();   // apply night mode in the station time zone as soon as it is known (not a minute later)
    h24 = d.station && d.station.time_format === "24";
    const U = d.units || {};
    const T = d.temp || {}, W = d.wind || {}, P = d.pressure || {}, R = d.rain || {}, H = d.humidity || {};
    const F = d.forecast || {}, FN = F.now || {}, FT = F.today || {}, A = d.astro || {}, M = A.moon || {};
    const hasData = isNum(d.obs_time);
    setText("stationName", (d.station && d.station.name) || "Weather Station");
    document.title = ((d.station && d.station.name) || "Weather") + " \u2014 " + fx(T.now) + "°";
    updateStatus();

    // hero
    const heroIcon = FN.icon || (hasData ? (A.is_day === false ? "clear-night" : "clear-day") : "cloudy");
    if ($("heroIcon").dataset.icon !== heroIcon) { $("heroIcon").innerHTML = wicon(heroIcon); $("heroIcon").dataset.icon = heroIcon; }
    setText("heroCond", FN.conditions || (hasData ? "Observed" : "--"));
    setText("comfort", T.comfort || "--"); $("comfort").classList.toggle("hidden", !T.comfort);
    setArrow("trendArrow", T.trend); setText("trendVal", isNum(T.trend) ? signed(T.trend) + "°" : "--");
    setArrow("diffArrow", T.diff24, 0.5); setText("diffVal", isNum(T.diff24) ? signed(T.diff24) + "°" : "--");
    setText("feels", isNum(T.feels) ? fx(T.feels) + "°" : "--");
    setText("dewHero", isNum(T.dew) ? fx(T.dew) + "°" : "--");
    setText("humHero", isNum(H.now) ? fi(H.now) + "%" : "--");
    renderHero(T, U);

    // wind
    setText("windDesc", W.description || (W.calm ? "Calm" : "--"));
    setWind(W.speed, W.dir, W.dir_cardinal || (W.calm ? null : W.cardinal), W.cardinal, !!W.calm, U.wind || "mph", W.gust);
    setHTML("windAvg", isNum(W.avg_today) ? `${fx(W.avg_today)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setHTML("windGust", isNum(W.gust_max) ? `${fx(W.gust_max)}<span class="unit">${esc(U.wind)}</span>` : "--");
    setText("gustNow", isNum(W.gust) ? fx(W.gust) : "--");

    // barometer
    setText("baroVal", isNum(P.slp) ? fx(P.slp, U.pressure === "inHg" ? 2 : 1) : "--");
    setText("baroUnit", U.pressure || "mb");
    setText("baroTrendText", P.trend_text || "--");
    setArrow("baroArrow", P.trend, 0.3);
    setText("baroTrend", isNum(P.trend) ? `${signed(P.trend)} ${U.pressure}/hr` : "--");
    setText("baroTendency", P.tendency || "--");
    setText("baroLow", P.low && isNum(P.low.value) ? fx(P.low.value) : "--");
    setText("baroHigh", P.high && isNum(P.high.value) ? fx(P.high.value) : "--");
    setText("baroLowT", P.low ? fmtTime(P.low.time) : "");
    setText("baroHighT", P.high ? fmtTime(P.high.time) : "");
    setBaro(P);

    // moon & sun
    const moonSig = `${M.illumination}|${M.waxing}`;
    if ($("moonSvg").dataset.sig !== moonSig) { $("moonSvg").innerHTML = moonArt(M.illumination, M.waxing); $("moonSvg").dataset.sig = moonSig; }
    setText("moonName", M.name || "--");
    setText("moonIllum", isNum(M.illumination) ? M.illumination + "% lit" : "--");
    setText("moonRise", fmtTime(M.rise)); setText("moonSet", fmtTime(M.set));
    setText("nextNew", fmtDay(M.next_new)); setText("nextFull", fmtDay(M.next_full));
    setText("sunRise", fmtTime(A.sunrise)); setText("sunSet", fmtTime(A.sunset));

    // humidity / uv / solar
    setText("humVal", fi(H.now));
    humK = isNum(H.now) ? clamp01(H.now / 100) : 0; placeHum();
    $("humPin").style.opacity = isNum(H.now) ? "1" : "0";
    setText("humDesc", humText(H.now, T.dew, U.temp));
    const uv = d.solar && d.solar.uv;
    setHTML("uv", isNum(uv) ? `${fx(uv)} <span class="unit">${uvText(uv)}</span>` : "--");
    const lit = isNum(uv) ? Math.max(1, Math.min(11, Math.round(uv))) : 0;
    document.querySelectorAll("#uvGlyphs .uvg").forEach((g) => g.classList.toggle("on", +g.dataset.i < lit));
    const rad = d.solar && d.solar.radiation;
    setHTML("solar", isNum(rad) ? `${fi(rad)}<span class="unit">W/m²</span>` : "--");

    // rain: glass rain gauges
    const pu = U.precip || "in", dec = pu === "mm" ? 1 : 2;
    const scales = pu === "mm" ? { today: 25, yesterday: 25, month: 125, year: 600 } : { today: 1, yesterday: 1, month: 5, year: 25 };
    document.querySelectorAll("#rainBars .pot").forEach((el) => {
      const k = el.dataset.k, v = R[k];
      const txt = isNum(v) ? (k === "year" && pu === "in" ? v.toFixed(1) : v.toFixed(dec)) : "--";
      const rv = el.querySelector(".rv");
      if (rv.dataset.v !== txt) { rv.dataset.v = txt; rv.innerHTML = esc(txt) + (isNum(v) ? `<span class="ru">${pu === "in" ? "\u2033" : " mm"}</span>` : ""); }
      const pct = isNum(v) ? Math.min(1, v / Math.max(scales[k], v)) : 0;
      const lev = v > 0 ? Math.max(0.05, pct) : 0;
      el.querySelector(".water").style.transform = `scaleY(${lev.toFixed(3)})`;
      const men = el.querySelector(".menis");   // meniscus highlight rides the water surface (water spans y 24-104)
      men.style.transform = `translateY(${f1((1 - lev) * 80)}px)`; men.style.opacity = lev > 0 ? "1" : "0";
    });
    setText("rainText", R.rate_text || "--");
    setRainLevel(R.rate, pu);
    setText("rainRate", isNum(R.rate) ? `${fx(R.rate, dec)} ${U.rate || "in/hr"}` : "--");

    // forecast
    setText("fcUntil", FN.until || FN.conditions || "--");
    const fci = FN.icon || "cloudy";
    if ($("fcIcon").dataset.icon !== fci) { $("fcIcon").innerHTML = wicon(fci); $("fcIcon").dataset.icon = fci; }
    setText("fcTemp", isNum(FN.temp) ? fi(FN.temp) + "°" : "--");
    setText("fcLow", isNum(FT.low) ? fi(FT.low) + "°" : "--");
    setText("fcHigh", isNum(FT.high) ? fi(FT.high) + "°" : "--");
    const rainPct = isNum(FT.precip) ? FT.precip : FN.precip;
    setText("fcRainPill", isNum(rainPct) ? `\u{1F4A7} ${fi(rainPct)}%` : "--");
    setText("fcWind", isNum(FN.wind) ? `${fi(FN.wind)} ${U.wind} ${FN.wind_dir || ""}`.trim() : "--");
    const DL = Array.isArray(F.daily) ? F.daily : [];
    const tmKey = dayKey(nowS() + 86400);
    const TM = DL.find((x) => x && isNum(x.time) && dayKey(x.time + 3600) === tmKey) || DL.find((x) => x && isNum(x.time) && x.time > nowS()) || null;
    $("fcTm").classList.toggle("empty", !TM);
    if (TM) {
      const tmi = String(TM.icon || "cloudy").replace("-night", "-day");
      if ($("fcTmIcon").dataset.icon !== tmi) { $("fcTmIcon").innerHTML = wicon(tmi); $("fcTmIcon").dataset.icon = tmi; }
      setText("fcTmDay", "Tomorrow \u00b7 " + new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(new Date((TM.time + 3600) * 1000)));
      setText("fcTmCond", TM.conditions || "--");
      setText("fcTmHigh", isNum(TM.high) ? fi(TM.high) + "°" : "--");
      setText("fcTmLow", isNum(TM.low) ? fi(TM.low) + "°" : "--");
      setText("fcTmRain", isNum(TM.precip) ? `\u{1F4A7} ${fi(TM.precip)}%` : "");
    } else {
      setText("fcTmDay", "Tomorrow"); setText("fcTmCond", "Forecast unavailable");
      setText("fcTmHigh", "--"); setText("fcTmLow", "--"); setText("fcTmRain", "");
      $("fcTmIcon").innerHTML = ""; $("fcTmIcon").dataset.icon = "";
    }

    fitAll();
    renderHourly(F.hourly || []);
    renderLightning(d.lightning || {}, U);
    updateStrikeBadge();
    if (openPanel) showPanel(openPanel, true);
  }

  /* ---------------- status / live / strike badge ---------------- */
  function updateStatus() {
    const d = DATA, pill = $("statusPill");
    let cls = "loading", txt = "Connecting…";
    if (serverDown) { cls = "error"; txt = "Dashboard server unreachable" + (lastFetchOk ? " · showing data from " + ago(lastFetchOk / 1000 + OFFSET / 1000) : ""); }
    else if (d) {
      if (d.mock) { cls = "mock"; txt = "Demo data"; }
      else if (d.status === "ok") { cls = "ok"; txt = "Live · updated " + ago(d.obs_time); }
      else if (d.status === "stale") { cls = "stale"; txt = "Stale · last obs " + ago(d.obs_time) + (d.error ? " · " + d.error : ""); }
      else if (d.status === "loading") { cls = "loading"; txt = d.error || "Loading…"; }
      else { cls = "error"; txt = "Offline · " + (d.error || "no data"); }
    }
    pill.className = "status " + cls; setText("statusText", txt);
    const noData = !d || !isNum(d.obs_time), showErr = noData && (serverDown || (d && d.status === "error"));
    $("errorState").classList.toggle("hidden", !showErr);
    body.classList.toggle("has-error", cls === "error" || cls === "stale");
    if (showErr) setText("errorMsg", serverDown ? "The wxdash server on this Pi is not responding." : (d && d.error) || "Unknown error");
  }
  function updateStrikeBadge() {
    const L = (DATA && DATA.lightning) || {}, b = $("strikeBadge");
    const recent = lightningActive(L), red = recent && strikeRecentRed(L);
    b.classList.toggle("on", recent); b.classList.toggle("near", red);
    setLamp(b.querySelector(".lamp"), recent ? (red ? "red" : "amber") : "", recent);
    if (DATA) renderLightningTick();
    setText("strikeText", recent ? `\u26A1 ${fi(L.last_distance)} ${(DATA.units && DATA.units.distance) || "mi"} \u00b7 ${ago(L.last_epoch)}` : "No strikes");
  }
  function renderLightningTick() {
    const L = (DATA && DATA.lightning) || {}, active = lightningActive(L);
    if ($("ltCard").classList.contains("active") !== active || $("ltCard").classList.contains("near") !== (active && strikeRecentRed(L))) renderLightning(L, DATA.units || {});
    else if (isNum(L.last_epoch)) { setText("ltAgo", ago(L.last_epoch)); setText("ltWhen", strikeWhen(L.last_epoch)); }
  }
  function updateLive() {
    const el = $("livePill");
    let cls = "off", txt = "Polling", title = "Live stream not connected; refreshing every 15 s";
    if (sseOpen && (wsState === "connected" || demoLive)) { cls = "on"; txt = "Live"; title = demoLive ? "Simulated live feed (demo)" : "WeatherFlow live feed connected"; }
    else if (sseOpen && wsState === "connecting") { cls = "wait"; txt = "Reconnecting"; title = "WeatherFlow live feed reconnecting; using REST updates"; }
    el.className = "ind live " + cls;
    setLamp(el.querySelector(".lamp"), cls === "on" ? "green" : cls === "wait" ? "amber" : "", cls === "wait");
    el.title = title; setText("liveText", txt);
  }

  /* ---------------- theme picker (saved on the Pi via POST /api/settings) ---------------- */
  const THEME = "redwoods";
  const THEMES = [["classic", "Classic"], ["industrial", "Industrial"], ["desert", "Desert"], ["arctic", "Arctic"], ["redwoods", "Redwoods"]];
  let themeMsg = "";
  function themeHTML() {
    return `<div class="theme-pick"><div class="label">Theme</div><div class="theme-btns">` +
      THEMES.map(([k, n]) => `<button data-act="theme" data-theme="${k}" class="${k === THEME ? "on" : ""}" aria-pressed="${k === THEME}">` +
        `<span class="tn">${n}</span><span class="cur">${k === THEME ? "\u2713 Current" : "Tap to switch"}</span></button>`).join("") +
      `</div>${themeMsg ? `<div class="theme-msg">${esc(themeMsg)}</div>` : ""}</div>`;
  }
  function urlWithoutTheme() { const u = new URL(location.href); u.searchParams.delete("theme"); u.searchParams.delete("panel"); return u.toString(); }
  async function setTheme(t) {
    if (!t || t === THEME) { closePanel(); return; }
    themeMsg = "Switching\u2026"; showPanel("menu", true);
    try {
      const r = await fetch("/api/settings", { method: "POST", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ theme: t }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      location.replace(urlWithoutTheme());
    } catch (e) { themeMsg = "Couldn't switch theme: " + (e.message || e); showPanel("menu", true); }
  }
  // Another screen switched the theme: follow it (not for ?theme= previews).
  function onSettings(s) { if (s && s.theme && s.theme !== THEME && !params.get("theme")) location.replace(urlWithoutTheme()); }
  fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()).then((s) => {
    if (s && s.saved === false) themeMsg = "Theme not saved on the Pi (run install.sh once); it resets when wxdash restarts.";
  }).catch(() => {});

  /* ---------------- overlays ---------------- */
  function showPanel(name, refresh) {
    const d = DATA || {}, U = d.units || {};
    let html = "";
    if (name === "sager") {
      const S = d.sager, P = d.pressure || {};
      html = `<h3>Sager-style outlook</h3><div class="lead">Barometric forecast for the next 12–24 hours</div>
        <div class="big">${esc(S ? S.outlook : "Not enough pressure history yet")}</div>
        <div class="grid3"><div><div class="label">Sea-level pressure</div><div class="v">${fx(P.slp)} <small>${esc(U.pressure)}</small></div></div>
        <div><div class="label">3-hour trend</div><div class="v">${signed(P.trend)} <small>${esc(U.pressure)}/hr</small></div></div>
        <div><div class="label">Tendency</div><div class="v sm">${esc(P.trend_text || "--")}</div></div></div>
        <div class="note">Computed on this Pi with the Zambretti barometer method (pressure, 3-hour trend and season).${P.tendency ? " Barometer tendency: " + esc(P.tendency) + "." : ""}</div>`;
    } else if (name === "menu") {
      const s = d.station || {};
      html = `<h3>${esc(s.name || "Weather Station")}</h3><div class="lead">Station ${esc(s.id || "--")} · Tempest ${esc(s.device || "--")} · ${isNum(s.lat) ? s.lat.toFixed(4) + ", " + s.lon.toFixed(4) : ""}</div>
        <div class="grid3"><div><div class="label">Data</div><div class="v sm">${esc(d.mock ? "Demo" : d.status || "--")}</div></div>
        <div><div class="label">Last observation</div><div class="v sm">${esc(fmtTime(d.obs_time))}</div></div>
        <div><div class="label">Version</div><div class="v sm">wxdash ${esc(d.version || "")}</div></div></div>
        ${d.error ? `<div class="note">${esc(d.error)}</div>` : ""}
        ${themeHTML()}
        <div class="rowbtn"><button data-act="refresh">Refresh now</button><button data-act="reload">Reload page</button>
        <button data-act="lite">${body.classList.contains("lite") ? "Lite mode: on" : "Lite mode: off"}</button>
        <button data-act="cursor">${body.classList.contains("show-cursor") ? "Hide cursor" : "Show cursor"}</button></div>`;
    }
    if (!html) return;
    if (refresh && $("overlayBody").dataset.panel === name && $("overlayBody").innerHTML === html) return;
    $("overlayBody").innerHTML = html; $("overlayBody").dataset.panel = name;
    $("overlay").classList.remove("hidden"); openPanel = name;
    if (!refresh) { clearTimeout(overlayTimer); overlayTimer = setTimeout(closePanel, 45000); }
  }
  function closePanel() { $("overlay").classList.add("hidden"); openPanel = null; clearTimeout(overlayTimer); }
  document.querySelectorAll("[data-panel]").forEach((b) => b.addEventListener("click", () => showPanel(b.dataset.panel)));
  $("strikeBadge").addEventListener("click", () => { const c = $("ltCard"); c.classList.remove("flash"); void c.offsetWidth; c.classList.add("flash"); });
  $("overlayClose").addEventListener("click", closePanel);
  $("overlay").addEventListener("click", (e) => { if (e.target === $("overlay")) closePanel(); });
  $("overlayBody").addEventListener("click", (e) => {
    const btn = e.target && e.target.closest ? e.target.closest("[data-act]") : null, act = btn && btn.dataset.act;
    if (act === "theme") setTheme(btn.dataset.theme);
    else if (act === "refresh") { load(); closePanel(); }
    else if (act === "reload") location.reload();
    else if (act === "lite") { body.classList.toggle("lite"); localStorage.setItem("wxdash-lite", body.classList.contains("lite") ? "1" : "0"); showPanel("menu", true); }
    else if (act === "cursor") { body.classList.toggle("show-cursor"); localStorage.setItem("wxdash-cursor", body.classList.contains("show-cursor") ? "1" : "0"); showPanel("menu", true); }
  });

  /* ---------------- polling / live stream ---------------- */
  function dataQuery() {
    const q = new URLSearchParams();
    if (MOCK) q.set("mock", "1");
    if (params.get("lightning")) q.set("lightning", params.get("lightning"));
    const qs = q.toString(); return qs ? "?" + qs : "";
  }
  function startStream() {
    if (!window.EventSource || params.get("stream") === "0") return;
    try { sse = new EventSource("/api/stream" + dataQuery()); } catch (e) { return; }
    const ok = () => { if (!sseOpen) { sseOpen = true; updateLive(); } };
    const parse = (ev, fn) => { try { fn(JSON.parse(ev.data)); ok(); } catch (e) { /* ignore bad event */ } };
    sse.addEventListener("open", ok);
    sse.addEventListener("error", () => { sseOpen = false; updateLive(); });
    sse.addEventListener("data", (ev) => parse(ev, (d) => { serverDown = false; lastFetchOk = Date.now(); render(d); }));
    sse.addEventListener("wind", (ev) => parse(ev, onRapidWind));
    sse.addEventListener("strike", (ev) => parse(ev, onStrike));
    sse.addEventListener("settings", (ev) => parse(ev, onSettings));
    sse.addEventListener("live", (ev) => parse(ev, (l) => { wsState = l.ws || "off"; demoLive = !!l.demo; updateLive(); }));
  }
  async function load() {
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 10000);
      const r = await fetch("/api/data" + dataQuery(), { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const d = await r.json();
      serverDown = false; lastFetchOk = Date.now();
      if (d.live) { wsState = d.live.ws || "off"; demoLive = !!d.live.demo; }
      render(d); updateLive();
    } catch (e) { serverDown = true; updateStatus(); }
  }

  /* ---------------- night mode (8 PM - 6 AM): moonlit fog in the grove ---------------- */
  const NIGHT_FORCE = MOCK && params.has("night") ? params.get("night") === "1" : null;
  function localHour() {
    try { return +new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hourCycle: "h23" }).format(new Date(nowMs())) % 24; }
    catch (e) { return new Date(nowMs()).getHours(); }
  }
  function isNightHour() { if (NIGHT_FORCE !== null) return NIGHT_FORCE; const h = localHour(); return h >= 20 || h < 6; }
  function updateNight() { body.classList.toggle("night", isNightHour()); }
  updateNight();
  setInterval(updateNight, 60000);
  clockLoop();
  setInterval(() => { updateStatus(); if (DATA) updateStrikeBadge(); }, 5000);
  load().then(() => { const p = params.get("panel"); if (p) showPanel(p); startStream(); });
  setInterval(() => { if (!sseOpen || Date.now() - lastFetchOk > 60000) load(); }, POLL_MS);
  let loadedVersion = null;
  async function checkVersion() {
    try {
      const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 8000);
      const r = await fetch("/api/health", { cache: "no-store", signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) return;
      const h = await r.json();
      if (!h || !h.ok || typeof h.version !== "string" || !h.version) return;
      if (loadedVersion === null) loadedVersion = h.version;
      else if (h.version !== loadedVersion) location.reload();
      else if (h.theme && h.theme !== THEME) onSettings({ theme: h.theme });   // backup if the SSE event was missed
    } catch (e) { /* server restarting or down */ }
  }
  checkVersion();
  setInterval(checkVersion, 60000);
  setInterval(() => { const h = new Date().getHours(), m = new Date().getMinutes(); if (h === 3 && m === 30) location.reload(); }, 60000);
})();
