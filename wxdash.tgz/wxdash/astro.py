"""Pure-Python astronomy helpers (no third-party dependencies).

Sun and Moon positions use Paul Schlyter's low-precision orbital elements
(accurate to roughly 1-2 arc-minutes, i.e. rise/set times to ~1-2 minutes).
Next new/full moon times use Jean Meeus, "Astronomical Algorithms", ch. 49.
"""
import math
from datetime import datetime, timedelta, timezone

RAD = math.pi / 180.0
DEG = 180.0 / math.pi


def _rev(x):
    return x % 360.0


def jd_from_unix(ts):
    return ts / 86400.0 + 2440587.5


def unix_from_jd(jd):
    return (jd - 2440587.5) * 86400.0


def _sun_elements(d):
    w = 282.9404 + 4.70935e-5 * d
    e = 0.016709 - 1.151e-9 * d
    M = _rev(356.0470 + 0.9856002585 * d)
    return w, e, M


def sun_ecliptic(d):
    """Return (longitude deg, distance AU) of the Sun for day number d."""
    w, e, M = _sun_elements(d)
    E = M + e * DEG * math.sin(M * RAD) * (1 + e * math.cos(M * RAD))
    xv = math.cos(E * RAD) - e
    yv = math.sqrt(1 - e * e) * math.sin(E * RAD)
    v = math.atan2(yv, xv) * DEG
    r = math.hypot(xv, yv)
    return _rev(v + w), r


def moon_ecliptic(d):
    """Return (longitude deg, latitude deg, distance in Earth radii)."""
    N = _rev(125.1228 - 0.0529538083 * d)
    i = 5.1454
    w = _rev(318.0634 + 0.1643573223 * d)
    a = 60.2666
    e = 0.054900
    M = _rev(115.3654 + 13.0649929509 * d)
    E = M + e * DEG * math.sin(M * RAD) * (1 + e * math.cos(M * RAD))
    for _ in range(6):
        E = E - (E - e * DEG * math.sin(E * RAD) - M) / (1 - e * math.cos(E * RAD))
    xv = a * (math.cos(E * RAD) - e)
    yv = a * math.sqrt(1 - e * e) * math.sin(E * RAD)
    v = math.atan2(yv, xv) * DEG
    r = math.hypot(xv, yv)
    vw = (v + w) * RAD
    xh = r * (math.cos(N * RAD) * math.cos(vw) - math.sin(N * RAD) * math.sin(vw) * math.cos(i * RAD))
    yh = r * (math.sin(N * RAD) * math.cos(vw) + math.cos(N * RAD) * math.sin(vw) * math.cos(i * RAD))
    zh = r * math.sin(vw) * math.sin(i * RAD)
    lon = math.atan2(yh, xh) * DEG
    lat = math.atan2(zh, math.hypot(xh, yh)) * DEG

    ws, _, Ms = _sun_elements(d)
    Ls = Ms + ws
    Lm = M + w + N
    D = Lm - Ls
    F = Lm - N
    s = lambda x: math.sin(x * RAD)
    c = lambda x: math.cos(x * RAD)
    lon += (-1.274 * s(M - 2 * D) + 0.658 * s(2 * D) - 0.186 * s(Ms)
            - 0.059 * s(2 * M - 2 * D) - 0.057 * s(M - 2 * D + Ms)
            + 0.053 * s(M + 2 * D) + 0.046 * s(2 * D - Ms) + 0.041 * s(M - Ms)
            - 0.035 * s(D) - 0.031 * s(M + Ms) - 0.015 * s(2 * F - 2 * D)
            + 0.011 * s(M - 4 * D))
    lat += (-0.173 * s(F - 2 * D) - 0.055 * s(M - F - 2 * D)
            - 0.046 * s(M + F - 2 * D) + 0.033 * s(F + 2 * D) + 0.017 * s(2 * M + F))
    r += -0.58 * c(M - 2 * D) - 0.46 * c(2 * D)
    return _rev(lon), lat, r


def _ecl_to_eq(lon, lat, d):
    ecl = (23.4393 - 3.563e-7 * d) * RAD
    lon *= RAD
    lat *= RAD
    xe = math.cos(lon) * math.cos(lat)
    ye = math.sin(lon) * math.cos(lat) * math.cos(ecl) - math.sin(lat) * math.sin(ecl)
    ze = math.sin(lon) * math.cos(lat) * math.sin(ecl) + math.sin(lat) * math.cos(ecl)
    ra = math.atan2(ye, xe) * DEG
    dec = math.atan2(ze, math.hypot(xe, ye)) * DEG
    return _rev(ra), dec


def _altitude(ra, dec, jd, lat, lon):
    gmst = _rev(280.46061837 + 360.98564736629 * (jd - 2451545.0))
    ha = (gmst + lon - ra) * RAD
    s = (math.sin(lat * RAD) * math.sin(dec * RAD)
         + math.cos(lat * RAD) * math.cos(dec * RAD) * math.cos(ha))
    return math.asin(max(-1.0, min(1.0, s))) * DEG


def sun_altitude(ts, lat, lon):
    jd = jd_from_unix(ts)
    d = jd - 2451543.5
    slon, _ = sun_ecliptic(d)
    ra, dec = _ecl_to_eq(slon, 0.0, d)
    return _altitude(ra, dec, jd, lat, lon)


def moon_altitude(ts, lat, lon):
    """Topocentric altitude of the Moon's centre (parallax applied)."""
    jd = jd_from_unix(ts)
    d = jd - 2451543.5
    mlon, mlat, r = moon_ecliptic(d)
    ra, dec = _ecl_to_eq(mlon, mlat, d)
    alt = _altitude(ra, dec, jd, lat, lon)
    par = math.asin(1.0 / r) * DEG
    return alt - par * math.cos(alt * RAD)


def _crossings(func, start_ts, end_ts, h0, step=600):
    """Find rise/set times of func(ts) through h0 in [start, end)."""
    rise = sett = None
    t0 = start_ts
    a0 = func(t0) - h0
    while t0 < end_ts:
        t1 = min(t0 + step, end_ts)
        a1 = func(t1) - h0
        if a0 <= 0 < a1 or a0 > 0 >= a1:
            # refine with bisection
            lo, hi, alo = t0, t1, a0
            for _ in range(20):
                mid = (lo + hi) / 2
                am = func(mid) - h0
                if (alo <= 0) == (am <= 0):
                    lo, alo = mid, am
                else:
                    hi = mid
            t = (lo + hi) / 2
            if a0 <= 0 < a1:
                if rise is None:
                    rise = t
            else:
                if sett is None:
                    sett = t
        t0, a0 = t1, a1
    return rise, sett


def local_day_bounds(now_ts, tz):
    dt = datetime.fromtimestamp(now_ts, tz)
    start = dt.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1)
    # handle DST by re-localising
    start = start.replace(tzinfo=None)
    end = end.replace(tzinfo=None)
    return (datetime(start.year, start.month, start.day, tzinfo=tz).timestamp(),
            datetime(end.year, end.month, end.day, tzinfo=tz).timestamp())


def sun_times(now_ts, lat, lon, tz):
    s, e = local_day_bounds(now_ts, tz)
    return _crossings(lambda t: sun_altitude(t, lat, lon), s, e, -0.833)


def moon_times(now_ts, lat, lon, tz):
    s, e = local_day_bounds(now_ts, tz)
    return _crossings(lambda t: moon_altitude(t, lat, lon), s, e, -0.833)


def moon_phase(ts):
    """Return dict with phase fraction (0=new,0.5=full), illumination 0..1, name."""
    d = jd_from_unix(ts) - 2451543.5
    slon, _ = sun_ecliptic(d)
    mlon, mlat, _ = moon_ecliptic(d)
    elong_lon = _rev(mlon - slon)
    phase = elong_lon / 360.0
    cos_e = math.cos(mlat * RAD) * math.cos(elong_lon * RAD)
    illum = (1 - cos_e) / 2.0
    return {"phase": phase, "illumination": illum, "name": phase_name(phase, illum),
            "waxing": phase < 0.5}


def phase_name(phase, illum):
    if illum < 0.02:
        return "New Moon"
    if illum > 0.985:
        return "Full Moon"
    if abs(illum - 0.5) < 0.03:
        return "First Quarter" if phase < 0.5 else "Last Quarter"
    if phase < 0.5:
        return "Waxing Crescent" if illum < 0.5 else "Waxing Gibbous"
    return "Waning Gibbous" if illum > 0.5 else "Waning Crescent"


_NEW = [(-0.40720, 0, 0, 1, 0), (0.17241, 1, 1, 0, 0), (0.01608, 0, 0, 2, 0),
        (0.01039, 0, 0, 0, 2), (0.00739, 1, -1, 1, 0), (-0.00514, 1, 1, 1, 0),
        (0.00208, 2, 2, 0, 0), (-0.00111, 0, 0, 1, -2), (-0.00057, 0, 0, 1, 2),
        (0.00056, 1, 1, 2, 0), (-0.00042, 0, 0, 3, 0), (0.00042, 1, 1, 0, 2),
        (0.00038, 1, 1, 0, -2), (-0.00024, 1, -1, 2, 0), (-0.00007, 0, 2, 1, 0),
        (0.00004, 0, 0, 2, -2), (0.00004, 0, 3, 0, 0), (0.00003, 0, 1, 1, -2),
        (0.00003, 0, 0, 2, 2), (-0.00003, 0, 1, 1, 2), (0.00003, 0, -1, 1, 2),
        (-0.00002, 0, -1, 1, -2), (-0.00002, 0, 1, 3, 0), (0.00002, 0, 0, 4, 0)]
_FULL = [(-0.40614, 0, 0, 1, 0), (0.17302, 1, 1, 0, 0), (0.01614, 0, 0, 2, 0),
         (0.01043, 0, 0, 0, 2), (0.00734, 1, -1, 1, 0), (-0.00515, 1, 1, 1, 0),
         (0.00209, 2, 2, 0, 0), (-0.00111, 0, 0, 1, -2), (-0.00057, 0, 0, 1, 2),
         (0.00056, 1, 1, 2, 0), (-0.00042, 0, 0, 3, 0), (0.00042, 1, 1, 0, 2),
         (0.00038, 1, 1, 0, -2), (-0.00024, 1, -1, 2, 0), (-0.00007, 0, 2, 1, 0),
         (0.00004, 0, 0, 2, -2), (0.00004, 0, 3, 0, 0), (0.00003, 0, 1, 1, -2),
         (0.00003, 0, 0, 2, 2), (-0.00003, 0, 1, 1, 2), (0.00003, 0, -1, 1, 2),
         (-0.00002, 0, -1, 1, -2), (-0.00002, 0, 1, 3, 0), (0.00002, 0, 0, 4, 0)]


def _meeus_phase_jde(k, full):
    T = k / 1236.85
    jde = (2451550.09766 + 29.530588861 * k + 0.00015437 * T ** 2
           - 0.000000150 * T ** 3 + 0.00000000073 * T ** 4)
    E = 1 - 0.002516 * T - 0.0000074 * T ** 2
    M = (2.5534 + 29.10535670 * k - 0.0000014 * T ** 2 - 0.00000011 * T ** 3) * RAD
    Mp = (201.5643 + 385.81693528 * k + 0.0107582 * T ** 2 + 0.00001238 * T ** 3
          - 0.000000058 * T ** 4) * RAD
    F = (160.7108 + 390.67050284 * k - 0.0016118 * T ** 2 - 0.00000227 * T ** 3
         + 0.000000011 * T ** 4) * RAD
    Om = (124.7746 - 1.56375588 * k + 0.0020672 * T ** 2 + 0.00000215 * T ** 3) * RAD
    corr = 0.0
    for coef, epow, m, mp, f in (_FULL if full else _NEW):
        corr += coef * (E ** epow) * math.sin(m * M + mp * Mp + f * F)
    corr += -0.00017 * math.sin(Om)
    return jde + corr


def next_phase(ts, full):
    """Unix time of the next new (full=False) or full (full=True) moon at/after ts.

    "Next" includes a phase that happened earlier the same day so that
    the display can say "New moon today", matching PiConsole behaviour.
    """
    year = datetime.fromtimestamp(ts, timezone.utc)
    yf = year.year + (year.timetuple().tm_yday - 1) / 365.25
    k = math.floor((yf - 2000) * 12.3685) - 1
    for i in range(6):
        kk = k + i + (0.5 if full else 0.0)
        t = unix_from_jd(_meeus_phase_jde(kk, full)) - 69.0  # TT -> UT
        if t >= ts - 86400:
            return t
    return None
