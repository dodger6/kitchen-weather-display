#!/usr/bin/env bash
# Launch the wxdash dashboard full-screen in Chromium.
# Usage:  ./kiosk.sh            full-screen kiosk
#         WINDOWED=1 ./kiosk.sh normal window (handy while PiConsole is still running)
#         URL=http://localhost:8090/?lite=1 ./kiosk.sh   (disable glass blur if the Pi struggles)
set -u
URL="${URL:-http://localhost:8090}"
PROFILE="${HOME}/.config/wxdash-chromium"   # separate profile; never touches your normal browser
BROWSER="$(command -v chromium-browser || command -v chromium || true)"
if [ -z "$BROWSER" ]; then echo "Chromium not found" >&2; exit 1; fi
export DISPLAY="${DISPLAY:-:0}"

# Wait (up to ~60 s) for the wxdash server to come up.
for _ in $(seq 1 60); do
  if command -v curl >/dev/null && curl -fs -o /dev/null "${URL%%\?*}/api/health"; then break; fi
  sleep 1
done

# Clear any "Chromium didn't shut down correctly" flag from a power cut.
sed -i 's/"exited_cleanly":false/"exited_cleanly":true/; s/"exit_type":"Crashed"/"exit_type":"Normal"/' \
  "$PROFILE/Default/Preferences" 2>/dev/null || true

COMMON=(--user-data-dir="$PROFILE" --noerrdialogs --disable-infobars --no-first-run
        --disable-session-crashed-bubble --disable-features=Translate --password-store=basic
        --check-for-update-interval=31536000 --ozone-platform-hint=auto --overscroll-history-navigation=0)

if [ "${WINDOWED:-0}" = "1" ]; then
  exec "$BROWSER" "${COMMON[@]}" --app="$URL" --window-size=1600,900
else
  exec "$BROWSER" "${COMMON[@]}" --kiosk --app="$URL"
fi
