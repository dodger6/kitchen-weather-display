#!/usr/bin/env bash
# Launch the wxdash dashboard full-screen in Chromium.
# Usage:  ./kiosk.sh            full-screen kiosk
#         WINDOWED=1 ./kiosk.sh normal window (handy while PiConsole is still running)
#         URL=http://localhost:8090/?glass=1 ./kiosk.sh  (frosted-glass blur; smooth mode is the default)
#         KIOSK_OZONE=x11 ./kiosk.sh  force Xwayland/X11 (default: native Wayland when available)
set -u
URL="${URL:-http://localhost:8090}"
PROFILE="${HOME}/.config/wxdash-chromium"   # separate profile; never touches your normal browser
BROWSER="${KIOSK_BROWSER:-}"; [ -n "$BROWSER" ] || BROWSER="$(command -v chromium-browser || command -v chromium || true)"
if [ -z "$BROWSER" ]; then echo "Chromium not found" >&2; exit 1; fi

# Pick the display backend. The Pi's labwc session is Wayland; running Chromium through
# Xwayland (ozone x11) costs a lot of GPU-process CPU, so use native Wayland whenever a
# Wayland socket exists and fall back to X11 only when it doesn't.
# KIOSK_OZONE=wayland|x11 forces one (for troubleshooting).
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
if [ -z "${WAYLAND_DISPLAY:-}" ]; then
  for w in wayland-0 wayland-1; do
    if [ -S "$XDG_RUNTIME_DIR/$w" ]; then export WAYLAND_DISPLAY="$w"; break; fi
  done
fi
OZONE="${KIOSK_OZONE:-}"
if [ -z "$OZONE" ]; then
  if [ -n "${WAYLAND_DISPLAY:-}" ] && { [ -S "$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY" ] || [ -S "$WAYLAND_DISPLAY" ]; }; then
    OZONE=wayland
  else
    OZONE=x11
  fi
fi
if [ "$OZONE" = "wayland" ]; then
  export WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-wayland-0}"
else
  export DISPLAY="${DISPLAY:-:0}"
fi
[ -n "${KIOSK_DEBUG:-}" ] && echo "kiosk: ozone=$OZONE WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-} DISPLAY=${DISPLAY:-} XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR" >&2

# Wait (up to ~60 s) for the wxdash server to come up.
[ -n "${KIOSK_DRYRUN:-}" ] || for _ in $(seq 1 60); do
  if command -v curl >/dev/null && curl -fs -o /dev/null "${URL%%\?*}/api/health"; then break; fi
  sleep 1
done

# Clear any "Chromium didn't shut down correctly" flag from a power cut.
sed -i 's/"exited_cleanly":false/"exited_cleanly":true/; s/"exit_type":"Crashed"/"exit_type":"Normal"/' \
  "$PROFILE/Default/Preferences" 2>/dev/null || true

COMMON=(--user-data-dir="$PROFILE" --noerrdialogs --disable-infobars --no-first-run
        --disable-session-crashed-bubble --disable-features=Translate --password-store=basic
        --check-for-update-interval=31536000 --overscroll-history-navigation=0
        --ozone-platform="$OZONE" --enable-gpu-rasterization)
[ -n "${KIOSK_DRYRUN:-}" ] && { printf '%s\n' "$BROWSER" "${COMMON[@]}"; exit 0; }   # tests only

if [ "${WINDOWED:-0}" = "1" ]; then
  exec "$BROWSER" "${COMMON[@]}" --app="$URL" --window-size=1600,900
else
  exec "$BROWSER" "${COMMON[@]}" --kiosk --app="$URL"
fi
