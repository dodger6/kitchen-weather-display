#!/usr/bin/env python3
"""wxdash self-updater (Python 3 standard library only).

Runs as root from wxdash-update.service (triggered by wxdash-update.timer):

  1. fetch latest.json  {"version": "x.y.z", "sha256": "<hex>"}
  2. if that version is newer than <install dir>/VERSION, download wxdash.tgz
     and verify its sha256 (abort on mismatch)
  3. validate the archive (no absolute paths, no "..", only regular files and
     directories, everything under wxdash/) and unpack it to a private temp dir
  4. back up the current install to <install dir>.prev, build the new tree
     (current files + archive files on top, so local files that aren't in the
     archive are preserved), swap it in, chown it to the service user
  5. restart wxdash and wait for /api/health to report ok with the new version;
     if that doesn't happen within 30 s, roll back to .prev and restart again

It never reads or writes the PiConsole ini (or anything outside the install
dir, its .prev backup and its own root-owned copy of this script).
Logs go to stdout/stderr, which systemd sends to the journal
(journalctl -u wxdash-update).

Environment overrides (for testing; defaults are the production values):
  WXDASH_UPDATE_BASE   base URL holding latest.json  (raw.githubusercontent.com/.../main)
  WXDASH_TARBALL_URL   tarball URL (default: github.com/.../raw/main/wxdash.tgz,
                       or <WXDASH_UPDATE_BASE>/wxdash.tgz when only the base is overridden)
  WXDASH_INSTALL_DIR   install dir                   (/home/kitchen/wxdash)
  WXDASH_OWNER         user:group to chown to        (kitchen:kitchen; "-" = don't chown)
  WXDASH_SERVICE       systemd unit to restart       (wxdash)
  WXDASH_RESTART_CMD   command used instead of "systemctl restart <service>"
  WXDASH_HEALTH_URL    health endpoint               (http://127.0.0.1:8090/api/health)
  WXDASH_HEALTH_TIMEOUT seconds to wait for health   (30)
  WXDASH_SELF_PATH     root-owned copy of this script to refresh after a good update
                       (/usr/local/lib/wxdash/updater.py; "-" = don't)
  WXDASH_LOCK          lock file                     (/run/wxdash-update/lock)
  WXDASH_STATE_DIR     where a failed version is remembered (/var/lib/wxdash-update)
"""
import argparse
import errno
import fcntl
import hashlib
import json
import os
import pwd
import grp
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request

REPO_RAW = "https://raw.githubusercontent.com/dodger6/kitchen-weather-display/main"
REPO_TGZ = "https://github.com/dodger6/kitchen-weather-display/raw/main/wxdash.tgz"

_BASE_OVERRIDE = os.environ.get("WXDASH_UPDATE_BASE", "").rstrip("/")
BASE = _BASE_OVERRIDE or REPO_RAW
LATEST_URL = BASE + "/latest.json"
TARBALL_URL = os.environ.get("WXDASH_TARBALL_URL") or (
    _BASE_OVERRIDE + "/wxdash.tgz" if _BASE_OVERRIDE else REPO_TGZ)
INSTALL_DIR = os.path.abspath(os.environ.get("WXDASH_INSTALL_DIR", "/home/kitchen/wxdash"))
OWNER = os.environ.get("WXDASH_OWNER", "kitchen:kitchen")
SERVICE = os.environ.get("WXDASH_SERVICE", "wxdash")
RESTART_CMD = os.environ.get("WXDASH_RESTART_CMD", "")
HEALTH_URL = os.environ.get("WXDASH_HEALTH_URL", "http://127.0.0.1:8090/api/health")
HEALTH_TIMEOUT = float(os.environ.get("WXDASH_HEALTH_TIMEOUT", "30"))
SELF_PATH = os.environ.get("WXDASH_SELF_PATH", "/usr/local/lib/wxdash/updater.py")
LOCK_PATH = os.environ.get("WXDASH_LOCK", "/run/wxdash-update/lock")
# Remembers a version that failed its health check so the timer doesn't retry it
# (and blank the screen) every 10 minutes. Cleared by a newer release or --force.
STATE_DIR = os.environ.get("WXDASH_STATE_DIR", "/var/lib/wxdash-update")

PREFIX = "wxdash"
MAX_JSON = 64 * 1024
MAX_TGZ = 50 * 1024 * 1024        # compressed download
MAX_UNPACKED = 200 * 1024 * 1024  # total unpacked size
MAX_MEMBERS = 5000
# Never written by the updater, even if an archive contained them.
PROTECTED_NAMES = {"wfpiconsole.ini"}
UA = "wxdash-updater"


class UpdateError(Exception):
    pass


def log(msg, level="info"):
    # sd-daemon priority prefixes so journald records the right level.
    prio = {"error": "<3>", "warning": "<4>", "info": "<6>"}.get(level, "<6>")
    stream = sys.stderr if level in ("error", "warning") else sys.stdout
    if not stream.isatty():
        msg = prio + msg
    print(msg, file=stream, flush=True)


# ---------------------------------------------------------------- versions
def parse_version(v):
    v = (v or "").strip()
    if not re.fullmatch(r"\d+(\.\d+){0,3}", v):
        raise UpdateError(f"bad version string {v!r}")
    parts = [int(x) for x in v.split(".")]
    return tuple(parts + [0] * (4 - len(parts)))


def installed_version():
    try:
        with open(os.path.join(INSTALL_DIR, "VERSION"), encoding="utf-8") as fh:
            return fh.read().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def failed_version():
    try:
        with open(os.path.join(STATE_DIR, "failed_version"), encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def set_failed_version(v):
    try:
        os.makedirs(STATE_DIR, mode=0o755, exist_ok=True)
        p = os.path.join(STATE_DIR, "failed_version")
        if v:
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(v + "\n")
        elif os.path.exists(p):
            os.unlink(p)
    except OSError as e:
        log(f"cannot write {STATE_DIR}: {e}", "warning")


# ---------------------------------------------------------------- network
def fetch(url, limit, dest=None):
    if not (url.startswith("https://") or url.startswith("http://127.0.0.1")
            or url.startswith("http://localhost") or _BASE_OVERRIDE):
        raise UpdateError("refusing non-https URL")
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            total = 0
            chunks = []
            out = open(dest, "wb") if dest else None
            try:
                while True:
                    b = r.read(65536)
                    if not b:
                        break
                    total += len(b)
                    if total > limit:
                        raise UpdateError(f"download larger than {limit} bytes")
                    if out:
                        out.write(b)
                    else:
                        chunks.append(b)
            finally:
                if out:
                    out.close()
            return None if dest else b"".join(chunks)
    except urllib.error.HTTPError as e:
        raise UpdateError(f"HTTP {e.code} fetching {url}")
    except (urllib.error.URLError, OSError) as e:
        raise UpdateError(f"network error fetching {url}: {getattr(e, 'reason', e)}")


def get_latest():
    raw = fetch(LATEST_URL, MAX_JSON)
    try:
        meta = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise UpdateError("latest.json is not valid JSON")
    if not isinstance(meta, dict):
        raise UpdateError("latest.json is not an object")
    version = str(meta.get("version", ""))
    sha = str(meta.get("sha256", "")).lower()
    parse_version(version)
    if not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise UpdateError("latest.json has no valid sha256")
    return version, sha


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(65536), b""):
            h.update(b)
    return h.hexdigest()


# ---------------------------------------------------------------- archive
def safe_members(tf):
    """Validate every member; return the list of (relative path, member)."""
    out = []
    total = 0
    members = tf.getmembers()
    if len(members) > MAX_MEMBERS:
        raise UpdateError("archive has too many members")
    for m in members:
        name = m.name
        if name.startswith("/") or name.startswith("\\") or re.match(r"^[A-Za-z]:", name):
            raise UpdateError(f"archive member has an absolute path: {name!r}")
        parts = [p for p in name.replace("\\", "/").split("/") if p not in ("", ".")]
        if ".." in parts:
            raise UpdateError(f"archive member contains '..': {name!r}")
        if not parts or parts[0] != PREFIX:
            raise UpdateError(f"archive member outside {PREFIX}/: {name!r}")
        if "\x00" in name:
            raise UpdateError("archive member name contains NUL")
        if not (m.isfile() or m.isdir()):
            raise UpdateError(f"archive member is not a regular file or directory: {name!r}")
        total += max(m.size, 0)
        if total > MAX_UNPACKED:
            raise UpdateError("archive unpacks too large")
        rel = "/".join(parts[1:])
        if rel and os.path.basename(rel) in PROTECTED_NAMES:
            log(f"skipping protected file in archive: {rel}", "warning")
            continue
        out.append((rel, m))
    if not any(rel == "server.py" for rel, m in out if m.isfile()):
        raise UpdateError("archive has no wxdash/server.py")
    if not any(rel == "VERSION" for rel, m in out if m.isfile()):
        raise UpdateError("archive has no wxdash/VERSION")
    return out


def extract_archive(tgz, dest):
    """Extract into dest/ (a fresh private dir) without trusting tarfile's own path handling."""
    try:
        tf = tarfile.open(tgz, "r:gz")
    except (tarfile.TarError, OSError) as e:
        raise UpdateError(f"cannot open archive: {e}")
    with tf:
        members = safe_members(tf)
        for rel, m in members:
            target = os.path.join(dest, rel) if rel else dest
            if m.isdir():
                os.makedirs(target, mode=0o755, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), mode=0o755, exist_ok=True)
            src = tf.extractfile(m)
            if src is None:
                raise UpdateError(f"cannot read {m.name!r}")
            mode = 0o755 if (m.mode & 0o111) else 0o644
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
            with os.fdopen(fd, "wb") as out, src:
                shutil.copyfileobj(src, out)
            os.chmod(target, mode)
    return dest


# ---------------------------------------------------------------- filesystem
def remove_path(p):
    if os.path.islink(p) or (os.path.exists(p) and not os.path.isdir(p)):
        os.unlink(p)
    elif os.path.isdir(p):
        shutil.rmtree(p)


def copy_tree(src, dst):
    """Copy a tree preserving symlinks as symlinks (never follows them)."""
    shutil.copytree(src, dst, symlinks=True)


def overlay(src_root, dst_root):
    """Copy every file under src_root onto dst_root, replacing what's there.

    Any symlink or wrong-type entry in the way is removed first, so a link left
    in the install dir can't redirect a root write somewhere else."""
    for dirpath, dirnames, filenames in os.walk(src_root):
        rel_dir = os.path.relpath(dirpath, src_root)
        dst_dir = dst_root if rel_dir == "." else os.path.join(dst_root, rel_dir)
        if os.path.islink(dst_dir) or (os.path.exists(dst_dir) and not os.path.isdir(dst_dir)):
            os.unlink(dst_dir)
        os.makedirs(dst_dir, mode=0o755, exist_ok=True)
        for fn in filenames:
            s = os.path.join(dirpath, fn)
            d = os.path.join(dst_dir, fn)
            if os.path.lexists(d):
                remove_path(d)
            mode = stat.S_IMODE(os.stat(s).st_mode)
            fd = os.open(d, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
            with os.fdopen(fd, "wb") as out, open(s, "rb") as inp:
                shutil.copyfileobj(inp, out)
            os.chmod(d, mode)


def chown_tree(root):
    if OWNER in ("", "-"):
        return
    user, _, group = OWNER.partition(":")
    uid = pwd.getpwnam(user).pw_uid
    gid = grp.getgrnam(group or user).gr_gid
    os.lchown(root, uid, gid)
    for dirpath, dirnames, filenames in os.walk(root):
        for n in dirnames + filenames:
            os.lchown(os.path.join(dirpath, n), uid, gid)


# ---------------------------------------------------------------- service
def restart_service():
    cmd = shlex.split(RESTART_CMD) if RESTART_CMD else ["systemctl", "restart", SERVICE]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=60)
    if r.returncode != 0:
        log(f"restart command failed ({r.returncode}): {r.stdout.strip()[:300]}", "warning")
        return False
    return True


def wait_healthy(expect_version, timeout=None):
    timeout = HEALTH_TIMEOUT if timeout is None else timeout
    deadline = time.monotonic() + timeout
    last = "no response"
    while time.monotonic() < deadline:
        try:
            req = urllib.request.Request(HEALTH_URL, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=3) as r:
                h = json.loads(r.read(MAX_JSON).decode("utf-8"))
            if h.get("ok") is True and (expect_version is None or h.get("version") == expect_version):
                return True
            last = f"ok={h.get('ok')!r} version={h.get('version')!r}"
        except Exception as e:  # noqa: BLE001 - any failure just means "not yet"
            last = type(e).__name__
        time.sleep(1)
    log(f"health check did not pass within {timeout:.0f}s (last: {last})", "warning")
    return False


# ---------------------------------------------------------------- update
def install_tree(new_files, version):
    """Back up, swap in new_files (overlaid on the current tree), restart, verify, roll back."""
    parent = os.path.dirname(INSTALL_DIR)
    prev = INSTALL_DIR + ".prev"
    have_current = os.path.isdir(INSTALL_DIR) and not os.path.islink(INSTALL_DIR)
    old_version = installed_version()

    if os.path.lexists(prev):
        remove_path(prev)
    if have_current:
        copy_tree(INSTALL_DIR, prev)
        log(f"backed up {INSTALL_DIR} ({old_version}) to {prev}")
    elif os.path.lexists(INSTALL_DIR):
        raise UpdateError(f"{INSTALL_DIR} exists but is not a directory")

    staging = tempfile.mkdtemp(prefix=".wxdash.new-", dir=parent)
    try:
        os.rmdir(staging)
        if have_current:
            copy_tree(INSTALL_DIR, staging)   # keeps local files the archive doesn't have
        else:
            os.makedirs(staging, mode=0o755)
        overlay(new_files, staging)
        os.chmod(staging, 0o755)
        chown_tree(staging)
        swapout = None
        if have_current:
            swapout = tempfile.mkdtemp(prefix=".wxdash.old-", dir=parent)
            os.rmdir(swapout)
            os.rename(INSTALL_DIR, swapout)
        os.rename(staging, INSTALL_DIR)
        staging = None
        if swapout:
            shutil.rmtree(swapout, ignore_errors=True)
    finally:
        if staging and os.path.lexists(staging):
            shutil.rmtree(staging, ignore_errors=True)
    log(f"installed {version} into {INSTALL_DIR}")

    restart_service()
    if wait_healthy(version):
        log(f"wxdash {version} is healthy")
        return True

    if not have_current:
        log("new install is not healthy and there is no previous version to roll back to", "error")
        return False

    log(f"rolling back to {old_version} from {prev}", "error")
    failed = INSTALL_DIR + ".failed"
    if os.path.lexists(failed):
        remove_path(failed)
    os.rename(INSTALL_DIR, failed)
    copy_tree(prev, INSTALL_DIR)
    chown_tree(INSTALL_DIR)
    restart_service()
    if wait_healthy(None):
        log(f"rollback complete; wxdash {old_version} is running again (failed tree kept at {failed})", "error")
    else:
        log("rollback done but wxdash is still not healthy; check journalctl -u wxdash", "error")
    return False


def refresh_self(new_files):
    """After a good update, refresh the root-owned copy of this updater from the verified archive."""
    if SELF_PATH in ("", "-"):
        return
    src = os.path.join(new_files, "updater.py")
    if not os.path.isfile(src):
        return
    try:
        with open(src, "rb") as a:
            new = a.read()
        try:
            with open(SELF_PATH, "rb") as b:
                if b.read() == new:
                    return
        except OSError:
            pass
        os.makedirs(os.path.dirname(SELF_PATH), mode=0o755, exist_ok=True)
        tmp = SELF_PATH + ".tmp"
        if os.path.lexists(tmp):
            os.unlink(tmp)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o755)
        with os.fdopen(fd, "wb") as out:
            out.write(new)
        os.replace(tmp, SELF_PATH)
        log(f"updated {SELF_PATH}")
    except OSError as e:
        log(f"could not refresh {SELF_PATH}: {e}", "warning")


def run(args):
    if args.tarball:
        # Local install (used by install.sh): tarball already downloaded and its sha checked
        # by the caller, but check it again here so this path is safe on its own.
        if not (args.sha256 and args.version):
            raise UpdateError("--tarball needs --sha256 and --version")
        version, sha = args.version, args.sha256.lower()
        parse_version(version)
    else:
        version, sha = get_latest()
    current = installed_version()
    log(f"installed {current}, latest {version}")

    if not args.force and parse_version(version) <= parse_version(current):
        log("up to date")
        return 0
    if not args.force and version == failed_version():
        log(f"skipping {version}: it failed its health check before and was rolled back "
            "(publish a newer version, or run with --force)", "warning")
        return 0
    if args.check:
        log(f"update available: {current} -> {version}")
        return 0

    with tempfile.TemporaryDirectory(prefix="wxdash-update-") as tmp:
        tgz = os.path.join(tmp, "wxdash.tgz")
        if args.tarball:
            shutil.copyfile(args.tarball, tgz)
        else:
            log(f"downloading {TARBALL_URL}")
            fetch(TARBALL_URL, MAX_TGZ, dest=tgz)
        got = sha256_file(tgz)
        if got != sha:
            raise UpdateError(f"sha256 mismatch (expected {sha}, got {got}); not installing")
        log("sha256 verified")
        unpack = os.path.join(tmp, "unpack")
        os.mkdir(unpack, 0o700)
        extract_archive(tgz, unpack)
        with open(os.path.join(unpack, "VERSION"), encoding="utf-8") as fh:
            arch_ver = fh.read().strip()
        if arch_ver != version:
            raise UpdateError(f"archive VERSION {arch_ver!r} doesn't match latest.json {version!r}")
        ok = install_tree(unpack, version)
        if ok:
            set_failed_version("")
            refresh_self(unpack)
        else:
            set_failed_version(version)
        return 0 if ok else 2


def main():
    ap = argparse.ArgumentParser(description="wxdash self-updater")
    ap.add_argument("--check", action="store_true", help="only report whether an update is available")
    ap.add_argument("--force", action="store_true", help="install even if the version isn't newer")
    ap.add_argument("--tarball", help="install this local wxdash.tgz instead of downloading")
    ap.add_argument("--sha256", help="expected sha256 of --tarball")
    ap.add_argument("--version", help="version contained in --tarball")
    args = ap.parse_args()

    lock_fh = None
    try:
        os.makedirs(os.path.dirname(LOCK_PATH), exist_ok=True)
        lock_fh = open(LOCK_PATH, "w")
        fcntl.flock(lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as e:
        if e.errno in (errno.EWOULDBLOCK, errno.EAGAIN):
            log("another update is already running")
            return 0
        log(f"cannot take lock {LOCK_PATH}: {e}", "warning")
    try:
        return run(args)
    except UpdateError as e:
        log(f"update aborted: {e}", "error")
        return 1
    finally:
        if lock_fh:
            lock_fh.close()


if __name__ == "__main__":
    sys.exit(main())
